// CHandles.hpp
// RAII ownership of the opaque C data-structure handles.
//
// Each C module exposes create/destroy functions. Wrapping the raw pointer in
// std::unique_ptr with a deleter that calls the matching *_destroy function
// means the C memory is released exactly once, automatically, when the owning
// C++ object is destroyed (no leaks, no double free, exception safe).
#ifndef CHANDLES_HPP
#define CHANDLES_HPP

#include <memory>
#include <new>

#include "ds/bst.h"
#include "ds/graph.h"
#include "ds/hash_table.h"
#include "ds/linked_list.h"
#include "ds/queue.h"
#include "ds/stack.h"

namespace academic {

struct LinkedListDeleter { void operator()(LinkedList* p) const noexcept { ll_destroy(p); } };
struct HashTableDeleter  { void operator()(HashTable* p) const noexcept { ht_destroy(p); } };
struct AVLTreeDeleter    { void operator()(AVLTree* p) const noexcept { avl_destroy(p); } };
struct GraphDeleter      { void operator()(Graph* p) const noexcept { graph_destroy(p); } };
struct QueueDeleter      { void operator()(Queue* p) const noexcept { queue_destroy(p); } };
struct StackDeleter      { void operator()(Stack* p) const noexcept { stack_destroy(p); } };

using LinkedListHandle = std::unique_ptr<LinkedList, LinkedListDeleter>;
using HashTableHandle  = std::unique_ptr<HashTable, HashTableDeleter>;
using AVLTreeHandle    = std::unique_ptr<AVLTree, AVLTreeDeleter>;
using GraphHandle      = std::unique_ptr<Graph, GraphDeleter>;
using QueueHandle      = std::unique_ptr<Queue, QueueDeleter>;
using StackHandle      = std::unique_ptr<Stack, StackDeleter>;

// Takes ownership of a freshly created C handle; a NULL from the C side
// (allocation failure) becomes std::bad_alloc on the C++ side.
template <typename Handle, typename Raw>
Handle adoptHandle(Raw* raw) {
    if (raw == nullptr) {
        throw std::bad_alloc();
    }
    return Handle(raw);
}

}  // namespace academic

#endif  // CHANDLES_HPP
