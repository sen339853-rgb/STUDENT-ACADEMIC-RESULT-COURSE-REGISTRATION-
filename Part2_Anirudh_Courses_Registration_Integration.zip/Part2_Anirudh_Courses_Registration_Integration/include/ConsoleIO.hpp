// ConsoleIO.hpp
// Line-based, validated console input for the menu-driven CLI.
//
// Every read uses std::getline, so a bad entry never leaves the stream in a
// failed state. End of input (Ctrl+Z / Ctrl+D, or the end of a piped demo
// script) throws InputClosed, which main() catches to save and exit cleanly.
#ifndef CONSOLE_IO_HPP
#define CONSOLE_IO_HPP

#include <stdexcept>
#include <string>

namespace io {

class InputClosed : public std::runtime_error {
public:
    InputClosed() : std::runtime_error("standard input closed") {}
};

// When input is piped from a file, echo each answer so the transcript is
// readable. Detected automatically by main().
void setEchoInput(bool echo);
bool stdinIsTerminal();

std::string readLine(const std::string& prompt);       // may be empty
std::string readRequired(const std::string& prompt);   // re-asks until non-empty
int readInt(const std::string& prompt, int min, int max);
int readOptionalInt(const std::string& prompt, int min, int max);  // blank -> 0
double readDouble(const std::string& prompt, double min, double max);
bool readYesNo(const std::string& prompt);

void printTitle(const std::string& title);
void printRule(char c = '-', int width = 78);

}  // namespace io

#endif  // CONSOLE_IO_HPP
