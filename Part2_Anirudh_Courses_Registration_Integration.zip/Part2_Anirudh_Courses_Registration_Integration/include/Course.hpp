// Course.hpp
// A course in the catalogue, with its roster and its waiting list.
//
// The roster is a C linked list (enrolment order) and the waiting list is a
// C FIFO queue. Both are owned through RAII handles, so a Course cleans up
// its C memory automatically. Course enforces its own invariants:
//   enrolled <= capacity, no duplicate enrolment, and a student is never on
//   the roster and the waiting list at the same time.
#ifndef COURSE_HPP
#define COURSE_HPP

#include <cstddef>
#include <string>
#include <vector>

#include "CHandles.hpp"

namespace academic {

class Course {
public:
    Course(std::string code, std::string title, int credits, int capacity);

    // Move-only: copying would mean two objects owning one C list.
    Course(const Course&) = delete;
    Course& operator=(const Course&) = delete;
    Course(Course&&) = default;
    Course& operator=(Course&&) = default;

    const std::string& code() const { return code_; }
    const std::string& title() const { return title_; }
    int credits() const { return credits_; }
    int capacity() const { return capacity_; }

    // ---- seats ----
    std::size_t enrolledCount() const { return ll_size(roster_.get()); }
    int availableSeats() const { return capacity_ - static_cast<int>(enrolledCount()); }
    bool isFull() const { return availableSeats() <= 0; }
    bool isEnrolled(const std::string& studentId) const;
    std::vector<std::string> enrolledIds() const;      // enrolment order

    // ---- waiting list ----
    std::size_t waitlistSize() const { return queue_size(waitlist_.get()); }
    bool isWaitlisted(const std::string& studentId) const;
    std::size_t waitlistPosition(const std::string& studentId) const;  // 0 = absent
    std::vector<std::string> waitlistIds() const;      // front -> rear

    // ---- mutators (called by AcademicManager / RegistrationManager) ----
    void setTitle(const std::string& title);
    void setCredits(int credits);
    void setCapacity(int capacity);         // never below enrolledCount()
    bool enroll(const std::string& studentId);           // false if full/duplicate
    bool drop(const std::string& studentId);
    bool joinWaitlist(const std::string& studentId);     // false if already in either
    bool leaveWaitlist(const std::string& studentId);
    bool popWaitlistFront(std::string& studentId);       // FIFO dequeue

private:
    std::string code_;
    std::string title_;
    int credits_;
    int capacity_;
    LinkedListHandle roster_;
    QueueHandle waitlist_;
};

}  // namespace academic

#endif  // COURSE_HPP
