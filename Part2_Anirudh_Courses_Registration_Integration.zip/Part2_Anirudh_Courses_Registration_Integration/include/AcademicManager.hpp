// AcademicManager.hpp
// Facade: the single entry point the CLI (and the tests) use.
//
//   CLI  --->  AcademicManager  --->  Student / Course / Result objects (C++)
//                    |                RegistrationManager (rules)
//                    |                C data structures via extern "C":
//                    |                  hash tables  : ID -> record slot
//                    |                  AVL tree     : CGPA ranking
//                    |                  graph + DFS  : prerequisites
//                    |                  stack        : marks undo
//                    |                  list/queue   : rosters/waitlists (in Course)
//                    +------------->  Snapshot  <--->  FileManager (binary .dat)
//
// Ownership: the C++ vectors own the Student/Course objects ("slots"); the C
// structures hold only IDs and slot numbers, never pointers to C++ objects.
// Callers receive const pointers, so every change goes through a method here,
// which keeps all indexes consistent.
#ifndef ACADEMIC_MANAGER_HPP
#define ACADEMIC_MANAGER_HPP

#include <cstddef>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "CHandles.hpp"
#include "Course.hpp"
#include "RegistrationManager.hpp"
#include "Snapshot.hpp"
#include "Student.hpp"

namespace academic {

struct OpResult {
    bool ok = false;
    std::string message;
};

struct RankingEntry {
    int rank = 0;              // competition rank: equal CGPA -> equal rank
    std::string studentId;
    std::string name;
    std::string category;
    double cgpa = 0.0;
};

struct SearchDemo {            // linear vs binary vs hash lookup on live data
    std::size_t records = 0;
    long linearIndex = -1;
    std::size_t linearComparisons = 0;
    long binaryIndex = -1;
    std::size_t binaryComparisons = 0;
    bool hashFound = false;
    std::size_t hashBucket = 0;
    std::size_t hashLongestChain = 0;  // worst chain anywhere in the table
};

struct SystemStats {
    std::size_t students = 0, courses = 0, results = 0, prerequisites = 0;
    std::size_t enrollments = 0, waitlisted = 0, undoDepth = 0;
    std::size_t studentBuckets = 0, studentLongestChain = 0, studentCollidingBuckets = 0;
    double studentLoadFactor = 0.0;
    std::size_t courseBuckets = 0, courseLongestChain = 0;
    double courseLoadFactor = 0.0;
    std::size_t rankedStudents = 0;
    int rankingTreeHeight = 0;
};

enum class StudentSortKey { Id, Name, CgpaHighFirst };
enum class CourseSortKey { Code, Title, EnrolledHighFirst };

class AcademicManager {
public:
    AcademicManager();
    ~AcademicManager();
    AcademicManager(const AcademicManager&) = delete;
    AcademicManager& operator=(const AcademicManager&) = delete;
    AcademicManager(AcademicManager&&) noexcept;
    AcademicManager& operator=(AcademicManager&&) noexcept;

    // ----- Module A: student records -----
    OpResult addStudent(StudentCategory category, const std::string& id, const std::string& name,
                        const std::string& program, int semester);
    // Empty strings / 0 mean "keep the current value".
    OpResult updateStudent(const std::string& id, const std::string& name, const std::string& program,
                           int semester);
    OpResult deleteStudent(const std::string& id);
    const Student* findStudent(const std::string& id) const;          // hash table
    std::vector<const Student*> students() const;
    std::vector<const Student*> searchStudentsByName(const std::string& fragment) const;
    std::vector<const Student*> sortedStudents(StudentSortKey key) const;  // C merge sort
    std::vector<std::string> registrationsOf(const std::string& studentId) const;
    std::vector<std::pair<std::string, std::size_t>> waitlistsOf(const std::string& studentId) const;

    // ----- Module B: courses and prerequisites -----
    OpResult addCourse(const std::string& code, const std::string& title, int credits, int capacity);
    OpResult updateCourse(const std::string& code, const std::string& title, int credits, int capacity);
    OpResult removeCourse(const std::string& code);
    const Course* findCourse(const std::string& code) const;          // hash table
    std::vector<const Course*> courses() const;
    std::vector<const Course*> sortedCourses(CourseSortKey key) const;
    OpResult addPrerequisite(const std::string& courseCode, const std::string& prereqCode);
    OpResult removePrerequisite(const std::string& courseCode, const std::string& prereqCode);
    std::vector<std::string> directPrerequisites(const std::string& courseCode) const;
    std::vector<std::string> allPrerequisites(const std::string& courseCode) const;
    std::vector<std::string> directDependents(const std::string& courseCode) const;
    std::vector<std::string> studyOrder() const;                       // topological order

    // ----- Module C: results, ranking, undo -----
    OpResult recordMarks(const std::string& studentId, const std::string& courseCode, double marks);
    OpResult undoLastMarksEntry();
    std::size_t undoDepth() const;
    bool peekUndo(MarksChange& out) const;
    void clearUndoHistory();
    std::vector<RankingEntry> ranking() const;                  // reverse inorder: best first
    std::vector<RankingEntry> rankingLowestFirst() const;       // inorder
    std::vector<RankingEntry> rankingAtLeast(double minCgpa) const;
    int rankOf(const std::string& studentId) const;             // 0 = not ranked

    // ----- Module D: registration -----
    bool checkPrerequisites(const std::string& studentId, const std::string& courseCode,
                            PrerequisiteReport& report, std::string& error) const;
    RegistrationOutcome registerForCourse(const std::string& studentId, const std::string& courseCode);
    OpResult cancelRegistration(const std::string& studentId, const std::string& courseCode);
    OpResult processWaitlist(const std::string& courseCode);

    // ----- persistence -----
    Snapshot exportSnapshot() const;
    OpResult importSnapshot(const Snapshot& snapshot);  // all-or-nothing
    void clear();

    // ----- analytics -----
    SystemStats stats() const;
    SearchDemo searchDemo(const std::string& studentId) const;
    bool isEmpty() const;

private:
    int studentSlot(const std::string& id) const;
    int courseSlot(const std::string& code) const;
    Student* studentAt(int slot) const;
    Course* courseAt(int slot) const;
    static int rankingScore(const Student& student);
    void removeFromRanking(const Student& student);
    void addToRanking(const Student& student);
    std::vector<RankingEntry> toRankingEntries(const std::vector<AVLEntry>& entries) const;
    std::string enrolledCourseRequiring(const Student& student, const std::string& courseCode) const;
    bool anyResultFor(const std::string& courseCode) const;
    std::string describePromotions(const std::vector<PromotionEvent>& events) const;
    RegistrationManager::StudentLookup studentLookup() const;
    OpResult restoreResult(const ResultRecord& record);

    std::vector<std::unique_ptr<Student>> students_;  // slot -> student (nullptr after delete)
    std::vector<std::unique_ptr<Course>> courses_;    // slot -> course  (nullptr after delete)
    HashTableHandle studentIndex_;                    // student ID  -> slot
    HashTableHandle courseIndex_;                     // course code -> slot (= graph vertex id)
    GraphHandle prerequisites_;
    AVLTreeHandle ranking_;
    StackHandle undo_;
    RegistrationManager registration_;                // must follow the handles it views
};

}  // namespace academic

#endif  // ACADEMIC_MANAGER_HPP
