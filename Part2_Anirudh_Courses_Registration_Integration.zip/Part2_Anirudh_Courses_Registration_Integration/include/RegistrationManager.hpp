// RegistrationManager.hpp
// Course-registration rules: prerequisite validation (C graph + DFS),
// capacity checks, FIFO waiting list and waitlist promotion.
//
// RegistrationManager owns no records. The AcademicManager facade looks up the
// Student and Course (through the C hash tables) and passes them in, so every
// rule lives here while all state stays in one place.
#ifndef REGISTRATION_MANAGER_HPP
#define REGISTRATION_MANAGER_HPP

#include <cstddef>
#include <functional>
#include <string>
#include <vector>

#include "Course.hpp"
#include "Student.hpp"
#include "ds/graph.h"
#include "ds/hash_table.h"

namespace academic {

enum class RegistrationStatus {
    Enrolled,
    Waitlisted,
    AlreadyEnrolled,
    AlreadyWaitlisted,
    AlreadyPassed,
    MissingPrerequisites,
    StudentNotFound,
    CourseNotFound,
    Failed
};

struct RegistrationOutcome {
    RegistrationStatus status = RegistrationStatus::Failed;
    std::string message;
    std::vector<std::string> missingPrerequisites;  // foundational first
    std::size_t waitlistPosition = 0;               // when Waitlisted
    bool ok() const {
        return status == RegistrationStatus::Enrolled || status == RegistrationStatus::Waitlisted;
    }
};

struct PrerequisiteReport {
    std::vector<std::string> required;  // all direct + transitive prerequisites
    std::vector<std::string> missing;   // required but not passed
    bool eligible() const { return missing.empty(); }
};

struct PromotionEvent {
    std::string studentId;
    bool promoted = false;   // false = removed from the waitlist instead
    std::string reason;
};

class RegistrationManager {
public:
    using StudentLookup = std::function<const Student*(const std::string&)>;

    // Non-owning views of the facade's prerequisite graph and course index.
    RegistrationManager(const Graph* prerequisites, const HashTable* courseIndex);

    // DFS over the prerequisite graph against the courses this student PASSED.
    PrerequisiteReport checkPrerequisites(const Student& student, int courseSlot) const;

    // Full workflow: duplicate check -> prerequisites -> capacity ->
    // enrol or join the FIFO waitlist. Nothing changes unless it succeeds.
    RegistrationOutcome requestRegistration(const Student& student, Course& course, int courseSlot) const;

    // Fill free seats from the front of the waitlist. Each candidate is
    // re-checked; students who are no longer eligible are removed with a reason
    // and the next student in FIFO order is considered.
    std::vector<PromotionEvent> fillVacancies(Course& course, int courseSlot,
                                              const StudentLookup& findStudent) const;

private:
    const Graph* graph_;
    const HashTable* courseIndex_;
};

}  // namespace academic

#endif  // REGISTRATION_MANAGER_HPP
