# Architecture

## 1. Layers

```
+--------------------------------------------------------------+
|  CLI (src/main.cpp, src/ConsoleIO.cpp)                       |
|  Student / Administrator / Academic Staff / DSA menus        |
+-------------------------------+------------------------------+
                                | const Student*, const Course*, OpResult
+-------------------------------v------------------------------+
|  AcademicManager  (Facade, src/AcademicManager_*.cpp, one file per module)          |
|   - owns all Student and Course objects ("slots")            |
|   - owns every C index through RAII handles                  |
|   - RegistrationManager: registration rules                  |
+------+-----------------------+-------------------------------+
       | extern "C" calls       | Snapshot (plain data)
+------v-----------------------+    +--------------------------+
|  C layer (src/ds/*.c)        |    | FileManager              |
|  hash_table  linked_list     |    | binary .dat, CRC-32,     |
|  bst (AVL)   graph (DFS)     |    | temp file + swap         |
|  queue       stack           |    +--------------------------+
|  searching_sorting           |
+------------------------------+
```

| Layer | Responsibility | Must NOT do |
|---|---|---|
| C (`src/ds`) | memory allocation (`malloc/calloc/realloc/free`), nodes, pointers, algorithms | know about students or courses as C++ objects |
| C++ domain (`Student`, `Course`, `Result`) | data, validation, polymorphic grading | expose raw C nodes |
| `RegistrationManager` | prerequisite check, capacity, waitlist promotion rules | own any data |
| `AcademicManager` | single public API; keeps all indexes consistent | print anything |
| `FileManager` | Snapshot ↔ bytes ↔ file | know the C structures |
| CLI | menus, input validation, display | modify records directly |

## 2. How `extern "C"` connects the layers

Every C header is wrapped like this (e.g. `include/ds/hash_table.h`):

```c
#ifdef __cplusplus
extern "C" {
#endif
HashTable *ht_create(size_t initial_buckets);
int ht_find(const HashTable *table, const char *key, int *out_value);
...
#ifdef __cplusplus
}
#endif
```

- `gcc -std=c11` compiles the `.c` files as C. The `#ifdef __cplusplus` lines vanish there.
- When a `.cpp` file includes the header, `extern "C"` tells g++ to use C linkage.
  The symbol is then plain `ht_find`, not a mangled C++ name such as `_Z7ht_findPK9HashTablePKcPi`,
  so the linker can match the C++ call to the C object file.
- Only C-compatible types cross the boundary: `int`, `size_t`, `const char*`, plain structs
  (`AVLEntry`, `MarksChange`, `SortRecord`) and **opaque handles** (`HashTable*`, `Graph*`, ...).
  The structs behind the handles are defined only inside the `.c` files, so C++ cannot touch
  the nodes. No `std::string`, `std::vector`, class objects or exceptions ever cross.
- C functions report errors through `DSStatus` codes (`include/ds/ds_common.h`). C++ turns
  those codes into messages and never needs C to understand exceptions.

## 3. Data ownership (who frees what)

| Data | Owner | Freed by |
|---|---|---|
| `Student` objects (UG/PG) | `AcademicManager::students_` (`vector<unique_ptr<Student>>`) | `unique_ptr`, via the virtual destructor |
| `Course` objects | `AcademicManager::courses_` | `unique_ptr` |
| Results | inside each `Student` (`vector<Result>`) | the `Student` |
| Course roster (C linked list) and waitlist (C queue) | each `Course`, through `LinkedListHandle` / `QueueHandle` | `ll_destroy` / `queue_destroy` called by the RAII deleter |
| Student and course hash tables, prerequisite graph, AVL ranking, undo stack | `AcademicManager`, through RAII handles (`include/CHandles.hpp`) | `ht_destroy`, `graph_destroy`, `avl_destroy`, `stack_destroy` |
| Temporary DFS/sort buffers | the C function that allocated them | the same function, before it returns |

**Rule:** the C structures store only IDs and slot numbers, never pointers to C++ objects.

- `studentIndex_`: student ID → slot in `students_`
- `courseIndex_`: course code → slot in `courses_`. The same slot number is the
  course's vertex id in the prerequisite graph.
- AVL node: `(CGPA×100, student ID)`
- Roster node and queue node: student ID
- Undo record: student ID, course code, previous marks and credits

A deleted record leaves an empty slot (`nullptr`), so no other slot number changes and every
index stays valid. A save followed by a load compacts the slots.

**Copies vs. authority.** Each fact is stored once. The roster is the only record of
"who is enrolled". A student's registrations are *derived* by asking each course
(`AcademicManager::registrationsOf`), not stored again. The sorting module works on a temporary
`SortRecord` array built on demand; that array is a view, not a second copy of the records.

## 4. Keeping indexes consistent

Every public mutator in `AcademicManager` follows **look up → validate everything → mutate everything**:

| Operation | Structures updated together |
|---|---|
| `addStudent` | student vector + student hash table |
| `deleteStudent` | refused while enrolled/waitlisted; otherwise AVL ranking + hash table + slot; undo history cleared |
| `addCourse` | course vector + graph vertex + course hash table (graph vertex rolled back if hashing fails) |
| `removeCourse` | refused if students/results/dependents exist; otherwise graph vertex (and its edges) + hash table + slot |
| `addPrerequisite` | graph edge (DFS cycle check first) |
| `recordMarks` | undo stack push **first** (if it fails, nothing changes), then remove old AVL key → update result → insert new AVL key |
| `undoLastMarksEntry` | peek → validate → restore result + AVL key → **then** pop |
| `registerForCourse` | either roster *or* waitlist, never both, only after all checks pass |
| `cancelRegistration` | roster removal → FIFO promotion loop (rechecks eligibility) |
| `importSnapshot` | builds a whole new `AcademicManager` and swaps it in only if every record is valid |

Two cross-module safety rules:

- A marks change or undo that turns a **pass into a fail** is refused if the student is currently
  enrolled in a course that needs that pass (`enrolledCourseRequiring`). Otherwise the registration
  would no longer be justified.
- Course **credits** cannot change once results record them, because each `Result` keeps its credits
  like a transcript line. **Capacity** cannot drop below current enrolment, and raising it promotes
  students from the waitlist.

## 5. Control flow of the main workflow (registration)

```
CLI: Student Portal -> 5. Register
  -> AcademicManager::registerForCourse(studentId, courseCode)
       ht_find(studentIndex_)            1. identify student     (C hash table)
       ht_find(courseIndex_)             2. identify course      (C hash table)
  -> RegistrationManager::requestRegistration(student, course, slot)
       Course::isEnrolled / isWaitlisted 3. duplicate checks     (C list / C queue)
       Student::hasPassed (virtual)      4. already passed?
       checkPrerequisites:               5. DFS on C graph
           passed[] from results (UG/PG pass mark via virtual evaluate())
           graph_all_prereqs + graph_check_prereqs
       not full -> Course::enroll        6a. ll_push_back
       full     -> Course::joinWaitlist  6b. queue_enqueue
  -> CLI prints the outcome, then FileManager::save (state saved)
```

## 6. How the four modules interact

- **A → C:** a student's results drive their CGPA and their AVL ranking key.
- **C → D:** registration eligibility reads *passed* results through the polymorphic `evaluate()`.
- **B → D:** the prerequisite graph and course capacity decide enrolment or waitlisting.
- **D → C:** an active enrolment blocks a marks change that would remove its prerequisite basis.
- **B → C:** credits recorded on results stop later credit edits.
- **All → persistence:** `exportSnapshot` walks students (with results), then courses
  (with prerequisites, roster order and FIFO waitlist order).

## 7. Team module allocation

The Phase-I PPT gives general roles. The Phase-II report gives specific pending tasks.
The file mapping below is a **suggested** split based on the Phase-II tasks.
The team should adjust it to match who actually builds and presents each part.

General roles (Phase-I PPT):

| Member | Role | Contribution |
|---|---|---|
| Anirudh | Lead | planning, C/C++ architecture, DSA/OOP design, core development, integration |
| Anjali | Developer | development support, module implementation, documentation, content organisation |
| Pratham | DB/Testing | data handling, testing and validation |
| Bishesh | Developer/Docs | development support, documentation, presentation |

Phase-II tasks → files:

| Phase-II task | Member | Files to own and explain |
|---|---|---|
| Student record management and data structures | Pratham | `Student.hpp/.cpp`, `Validation.*`, `AcademicManager_Students.cpp`; `linked_list.c`, `hash_table.c`, `bst.c`, `ds_common.c` |
| Course management and registration modules | Anirudh | `Course.hpp/.cpp`, `RegistrationManager::requestRegistration`, `AcademicManager_Courses.cpp`, `AcademicManager_Registration.cpp`, `CHandles.hpp`, `Makefile` (integration) |
| Searching, sorting and file handling | Anjali | `searching_sorting.c`, `sortedStudents/sortedCourses/searchStudentsByName/searchDemo`, `FileManager.*`, `Snapshot.hpp`, `Benchmark.*` |
| Result processing, prerequisite checks, waiting list | Bishesh | `Result.*`, `AcademicManager_Results.cpp` (marks, ranking, undo), `graph.c`, `queue.c`, `stack.c`, `RegistrationManager::checkPrerequisites/fillVacancies` |
| Integration, testing, final report and presentation | All | `tests/*`, `examples/*`, `docs/*` |

Note: the Phase-I documents spell the fourth member's surname "Shah" and the Phase-II report spells it
"Saha". Confirm the correct spelling before final submission.
