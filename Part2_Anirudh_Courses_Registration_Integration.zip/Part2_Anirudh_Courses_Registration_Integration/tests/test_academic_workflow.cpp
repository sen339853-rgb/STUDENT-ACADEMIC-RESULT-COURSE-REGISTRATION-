// test_academic_workflow.cpp
// Tests of the four modules through the AcademicManager facade.
#include <cmath>
#include <limits>
#include <string>

#include "AcademicManager.hpp"
#include "test_framework.hpp"

using namespace academic;

namespace {

bool near(double a, double b) { return std::fabs(a - b) < 1e-9; }

// PF101 <- DSA201 <- ADV301 (chain), MATH101 standalone; DSA201 has 2 seats.
void buildCatalogue(AcademicManager& m) {
    m.addCourse("PF101", "Programming Fundamentals", 4, 30);
    m.addCourse("MATH101", "Mathematics I", 4, 30);
    m.addCourse("DSA201", "Data Structures", 4, 2);
    m.addCourse("ADV301", "Advanced Algorithms", 3, 10);
    m.addPrerequisite("DSA201", "PF101");
    m.addPrerequisite("ADV301", "DSA201");
}

}  // namespace

// ---------------------------------------------------------------------------
// Module A - student records
// ---------------------------------------------------------------------------
TEST(student_add_lookup_duplicate_and_validation) {
    AcademicManager m;
    CHECK(m.addStudent(StudentCategory::UG, "ug001", "Test Student", "B.Tech CSE", 3).ok);
    const Student* s = m.findStudent("UG001");  // IDs are normalised to upper case
    CHECK(s != nullptr);
    CHECK_EQ(s->name(), std::string("Test Student"));
    CHECK(m.findStudent(" ug001 ") == s);
    CHECK(m.findStudent("UG999") == nullptr);                                              // missing
    CHECK(!m.addStudent(StudentCategory::PG, "UG001", "Other", "M.Tech", 1).ok);           // duplicate ID
    CHECK(!m.addStudent(StudentCategory::UG, "A", "Short Id", "B.Tech", 1).ok);            // ID too short
    CHECK(!m.addStudent(StudentCategory::UG, "BAD ID", "Space", "B.Tech", 1).ok);          // invalid char
    CHECK(!m.addStudent(StudentCategory::UG, "UG002", "", "B.Tech", 1).ok);                // empty name
    CHECK(!m.addStudent(StudentCategory::PG, "PG001", "Too Late", "M.Tech", 5).ok);        // PG max 4 sems
    CHECK(m.addStudent(StudentCategory::UG, "UG003", "Eighth Sem", "B.Tech", 8).ok);       // UG max 8
    CHECK_EQ(m.students().size(), 2u);
}

TEST(student_update_and_search) {
    AcademicManager m;
    m.addStudent(StudentCategory::UG, "UG001", "Asha Example", "B.Tech CSE", 3);
    m.addStudent(StudentCategory::PG, "PG001", "Ravi Sample", "M.Tech CSE", 1);
    CHECK(m.updateStudent("UG001", "Asha Updated", "", 4).ok);
    CHECK_EQ(m.findStudent("UG001")->name(), std::string("Asha Updated"));
    CHECK_EQ(m.findStudent("UG001")->program(), std::string("B.Tech CSE"));  // blank keeps value
    CHECK_EQ(m.findStudent("UG001")->semester(), 4);
    CHECK(!m.updateStudent("PG001", "", "", 6).ok);                          // invalid semester
    CHECK_EQ(m.findStudent("PG001")->semester(), 1);                         // unchanged
    CHECK(!m.updateStudent("NOPE", "X", "", 0).ok);
    CHECK_EQ(m.searchStudentsByName("sample").size(), 1u);                   // case-insensitive
    CHECK_EQ(m.searchStudentsByName("a").size(), 2u);
    const auto byName = m.sortedStudents(StudentSortKey::Name);
    CHECK(byName.size() == 2 && byName[0]->id() == "UG001");
}

TEST(student_delete_respects_enrolment_constraint) {
    AcademicManager m;
    buildCatalogue(m);
    m.addStudent(StudentCategory::UG, "UG001", "Asha Example", "B.Tech", 3);
    CHECK(m.registerForCourse("UG001", "PF101").ok());
    CHECK(!m.deleteStudent("UG001").ok);                 // enrolled: refused
    CHECK(m.findStudent("UG001") != nullptr);
    CHECK(m.cancelRegistration("UG001", "PF101").ok);
    m.recordMarks("UG001", "MATH101", 75);
    CHECK(m.ranking().size() == 1);
    CHECK(m.deleteStudent("UG001").ok);
    CHECK(m.findStudent("UG001") == nullptr);
    CHECK(m.ranking().empty());                          // removed from the AVL ranking too
    CHECK_EQ(m.undoDepth(), 0u);                         // history referring to it cleared
    CHECK(m.addStudent(StudentCategory::UG, "UG001", "Reused Id", "B.Tech", 1).ok);
}

// ---------------------------------------------------------------------------
// Module B - courses
// ---------------------------------------------------------------------------
TEST(course_add_update_remove_rules) {
    AcademicManager m;
    buildCatalogue(m);
    CHECK(!m.addCourse("PF101", "Duplicate", 4, 10).ok);
    CHECK(!m.addCourse("X1", "Bad credits", 9, 10).ok);
    CHECK(!m.addCourse("X2", "Bad capacity", 3, 0).ok);
    CHECK(!m.addPrerequisite("PF101", "ADV301").ok);      // would create a cycle
    CHECK(!m.addPrerequisite("PF101", "PF101").ok);       // self dependency
    CHECK(!m.addPrerequisite("DSA201", "PF101").ok);      // duplicate edge
    CHECK(!m.addPrerequisite("DSA201", "NOPE").ok);       // unknown course
    CHECK(!m.removeCourse("PF101").ok);                   // DSA201 depends on it
    CHECK(m.removeCourse("MATH101").ok);
    CHECK(m.findCourse("MATH101") == nullptr);
    CHECK(m.updateCourse("ADV301", "Advanced Algorithms II", 0, 0).ok);
    CHECK_EQ(m.findCourse("ADV301")->title(), std::string("Advanced Algorithms II"));
    const auto chain = m.allPrerequisites("ADV301");
    CHECK(chain.size() == 2 && chain[0] == "PF101" && chain[1] == "DSA201");
    const auto order = m.studyOrder();
    CHECK(order.size() == 3 && order[0] == "PF101" && order[2] == "ADV301");
}

// ---------------------------------------------------------------------------
// Module C - results, UG vs PG polymorphism, ranking, undo
// ---------------------------------------------------------------------------
TEST(ug_and_pg_grading_differ_through_base_pointer) {
    AcademicManager m;
    m.addStudent(StudentCategory::UG, "UG001", "Under Grad", "B.Tech", 3);
    m.addStudent(StudentCategory::PG, "PG001", "Post Grad", "M.Tech", 1);
    const Student* ug = m.findStudent("UG001");  // base-class pointers
    const Student* pg = m.findStudent("PG001");
    const GradeInfo u = ug->evaluate(4500);       // 45 marks
    const GradeInfo p = pg->evaluate(4500);
    CHECK(u.passed && u.letter == "C" && u.gradePoint == 5);
    CHECK(!p.passed && p.letter == "F" && p.gradePoint == 0);
    CHECK(ug->evaluate(9000).letter == "O" && pg->evaluate(9000).letter == "O");
    CHECK(!ug->evaluate(3999).passed);
    CHECK(pg->evaluate(5000).passed);
    CHECK_EQ(ug->categoryName(), std::string("UG"));
    CHECK_EQ(pg->maxSemester(), 4);
}

TEST(marks_validation_and_cgpa) {
    AcademicManager m;
    buildCatalogue(m);
    m.addStudent(StudentCategory::UG, "UG001", "Asha Example", "B.Tech", 3);
    CHECK(!m.recordMarks("UG001", "PF101", -1).ok);
    CHECK(!m.recordMarks("UG001", "PF101", 100.5).ok);
    CHECK(!m.recordMarks("UG001", "PF101", std::numeric_limits<double>::quiet_NaN()).ok);
    CHECK(!m.recordMarks("UG001", "NOPE", 50).ok);
    CHECK(!m.recordMarks("NOPE", "PF101", 50).ok);
    CHECK_EQ(m.undoDepth(), 0u);                       // rejected entries leave no history
    CHECK(m.recordMarks("UG001", "PF101", 86).ok);     // A+ = 9, 4 credits
    CHECK(m.recordMarks("UG001", "ADV301", 78).ok);    // A  = 8, 3 credits
    const Student* s = m.findStudent("UG001");
    CHECK(near(s->cgpa(), (9.0 * 4 + 8.0 * 3) / 7.0));
    CHECK_EQ(s->creditsEarned(), 7);
    CHECK(m.recordMarks("UG001", "ADV301", 30).ok);    // update to a fail
    CHECK(near(s->cgpa(), (9.0 * 4) / 7.0));
    CHECK_EQ(s->creditsEarned(), 4);
    CHECK_EQ(s->findResult("ADV301")->centiMarks(), 3000);
}

TEST(ranking_updates_after_marks_change) {
    AcademicManager m;
    buildCatalogue(m);
    m.addStudent(StudentCategory::UG, "UG001", "A Student", "B.Tech", 3);
    m.addStudent(StudentCategory::UG, "UG002", "B Student", "B.Tech", 3);
    m.addStudent(StudentCategory::PG, "PG001", "C Student", "M.Tech", 1);
    m.recordMarks("UG001", "PF101", 70);  // 8
    m.recordMarks("UG002", "PF101", 92);  // 10
    m.recordMarks("PG001", "PF101", 70);  // 8 (tie with UG001)
    auto r = m.ranking();
    CHECK(r.size() == 3 && r[0].studentId == "UG002" && r[0].rank == 1);
    CHECK(r[1].studentId == "PG001" && r[1].rank == 2);  // tie: listed by ID
    CHECK(r[2].studentId == "UG001" && r[2].rank == 2);  // tie: same competition rank
    CHECK(m.recordMarks("UG001", "PF101", 95).ok);
    r = m.ranking();
    CHECK(r[0].studentId == "UG001" && r[0].rank == 1);
    CHECK_EQ(m.rankOf("PG001"), 3);
    CHECK_EQ(m.rankingAtLeast(9.0).size(), 2u);
    CHECK(m.rankingLowestFirst().front().studentId == "PG001");
    CHECK_EQ(m.stats().rankedStudents, 3u);
}

TEST(undo_restores_marks_and_ranking) {
    AcademicManager m;
    buildCatalogue(m);
    m.addStudent(StudentCategory::UG, "UG001", "A Student", "B.Tech", 3);
    m.addStudent(StudentCategory::UG, "UG002", "B Student", "B.Tech", 3);
    CHECK(!m.undoLastMarksEntry().ok);                 // empty stack
    m.recordMarks("UG001", "PF101", 60);
    m.recordMarks("UG002", "PF101", 80);
    CHECK_EQ(m.rankOf("UG002"), 1);
    m.recordMarks("UG001", "PF101", 95);               // update: UG001 now first
    CHECK_EQ(m.rankOf("UG001"), 1);
    CHECK_EQ(m.undoDepth(), 3u);
    CHECK(m.undoLastMarksEntry().ok);                  // undo the update
    CHECK_EQ(m.findStudent("UG001")->findResult("PF101")->centiMarks(), 6000);
    CHECK_EQ(m.rankOf("UG002"), 1);                    // ranking restored too
    CHECK(m.undoLastMarksEntry().ok);                  // undo UG002's new entry
    CHECK(m.findStudent("UG002")->findResult("PF101") == nullptr);
    CHECK_EQ(m.rankOf("UG002"), 0);                    // left the ranking
    CHECK(m.undoLastMarksEntry().ok);
    CHECK(!m.findStudent("UG001")->hasResults());
    CHECK(!m.undoLastMarksEntry().ok);
    CHECK(m.ranking().empty());
}

TEST(marks_change_cannot_invalidate_an_enrolment) {
    AcademicManager m;
    buildCatalogue(m);
    m.addStudent(StudentCategory::UG, "UG001", "A Student", "B.Tech", 3);
    m.recordMarks("UG001", "PF101", 70);
    CHECK(m.registerForCourse("UG001", "DSA201").ok());
    CHECK(!m.recordMarks("UG001", "PF101", 20).ok);    // pass -> fail blocked
    CHECK(m.recordMarks("UG001", "PF101", 55).ok);     // pass -> pass is fine
    CHECK(m.undoLastMarksEntry().ok);                  // back to 70
    CHECK(!m.undoLastMarksEntry().ok);                 // undoing the entry would drop the pass
    CHECK_EQ(m.undoDepth(), 1u);                       // blocked undo keeps the record
    CHECK(m.cancelRegistration("UG001", "DSA201").ok);
    CHECK(m.undoLastMarksEntry().ok);                  // now allowed
}

// ---------------------------------------------------------------------------
// Module D - registration
// ---------------------------------------------------------------------------
TEST(registration_prerequisites_use_passed_results) {
    AcademicManager m;
    buildCatalogue(m);
    m.addStudent(StudentCategory::UG, "UG001", "New Student", "B.Tech", 1);
    RegistrationOutcome o = m.registerForCourse("UG001", "DSA201");
    CHECK(o.status == RegistrationStatus::MissingPrerequisites);  // new student: nothing passed
    CHECK(o.missingPrerequisites.size() == 1 && o.missingPrerequisites[0] == "PF101");
    CHECK_EQ(m.findCourse("DSA201")->enrolledCount(), 0u);        // no partial change
    CHECK(m.registerForCourse("UG001", "PF101").ok());             // no prerequisites
    CHECK(m.registerForCourse("UG001", "PF101").status == RegistrationStatus::AlreadyEnrolled);
    m.cancelRegistration("UG001", "PF101");
    m.recordMarks("UG001", "PF101", 35);                           // UG fail
    CHECK(m.registerForCourse("UG001", "DSA201").status == RegistrationStatus::MissingPrerequisites);
    m.recordMarks("UG001", "PF101", 65);
    CHECK(m.registerForCourse("UG001", "PF101").status == RegistrationStatus::AlreadyPassed);
    CHECK(m.registerForCourse("UG001", "DSA201").status == RegistrationStatus::Enrolled);
    CHECK(m.registerForCourse("NOPE", "DSA201").status == RegistrationStatus::StudentNotFound);
    CHECK(m.registerForCourse("UG001", "NOPE").status == RegistrationStatus::CourseNotFound);
}

TEST(registration_transitive_prerequisites) {
    AcademicManager m;
    buildCatalogue(m);
    m.addStudent(StudentCategory::UG, "UG001", "A Student", "B.Tech", 3);
    m.recordMarks("UG001", "DSA201", 80);                          // DSA passed, PF never taken
    PrerequisiteReport rep;
    std::string err;
    CHECK(m.checkPrerequisites("UG001", "ADV301", rep, err));
    CHECK(rep.required.size() == 2 && rep.missing.size() == 1 && rep.missing[0] == "PF101");
    CHECK(m.registerForCourse("UG001", "ADV301").status == RegistrationStatus::MissingPrerequisites);
    m.recordMarks("UG001", "PF101", 80);
    CHECK(m.registerForCourse("UG001", "ADV301").ok());
}

TEST(full_course_waitlist_and_fifo_promotion) {
    AcademicManager m;
    buildCatalogue(m);
    for (const char* id : {"UG001", "UG002", "UG003", "UG004", "UG005"}) {
        m.addStudent(StudentCategory::UG, id, "Student Name", "B.Tech", 3);
        m.recordMarks(id, "PF101", 75);
    }
    CHECK(m.registerForCourse("UG001", "DSA201").status == RegistrationStatus::Enrolled);
    CHECK(m.registerForCourse("UG002", "DSA201").status == RegistrationStatus::Enrolled);
    RegistrationOutcome o = m.registerForCourse("UG003", "DSA201");  // capacity 2: full
    CHECK(o.status == RegistrationStatus::Waitlisted && o.waitlistPosition == 1);
    o = m.registerForCourse("UG004", "DSA201");
    CHECK(o.status == RegistrationStatus::Waitlisted && o.waitlistPosition == 2);
    m.registerForCourse("UG005", "DSA201");
    CHECK(m.registerForCourse("UG003", "DSA201").status == RegistrationStatus::AlreadyWaitlisted);
    const Course* c = m.findCourse("DSA201");
    CHECK_EQ(c->enrolledCount(), 2u);
    CHECK_EQ(c->availableSeats(), 0);
    CHECK_EQ(c->waitlistSize(), 3u);

    // UG003 (front) loses eligibility while waiting; UG004 should be promoted.
    CHECK(m.recordMarks("UG003", "PF101", 20).ok);   // allowed: UG003 is only waitlisted
    CHECK(m.cancelRegistration("UG001", "DSA201").ok);
    CHECK(c->isEnrolled("UG004"));
    CHECK(!c->isEnrolled("UG003") && !c->isWaitlisted("UG003"));
    CHECK_EQ(c->enrolledCount(), 2u);                // never above capacity
    CHECK_EQ(c->waitlistPosition("UG005"), 1u);      // order of the rest preserved

    CHECK(m.cancelRegistration("UG005", "DSA201").ok);  // leaving the waitlist
    CHECK_EQ(c->waitlistSize(), 0u);
    CHECK(!m.cancelRegistration("UG005", "DSA201").ok);
    CHECK(!m.updateCourse("DSA201", "", 0, 1).ok);      // capacity below enrolment refused
}

TEST(capacity_increase_promotes_waitlist) {
    AcademicManager m;
    buildCatalogue(m);
    for (const char* id : {"UG001", "UG002", "UG003"}) {
        m.addStudent(StudentCategory::UG, id, "Student Name", "B.Tech", 3);
        m.recordMarks(id, "PF101", 75);
        m.registerForCourse(id, "DSA201");
    }
    const Course* c = m.findCourse("DSA201");
    CHECK_EQ(c->waitlistSize(), 1u);
    CHECK(m.updateCourse("DSA201", "", 0, 3).ok);
    CHECK(c->isEnrolled("UG003"));
    CHECK_EQ(c->waitlistSize(), 0u);
    CHECK(!m.updateCourse("PF101", "", 3, 0).ok);    // credits fixed once results exist
}

TEST(snapshot_round_trip_in_memory) {
    AcademicManager m;
    buildCatalogue(m);
    for (const char* id : {"UG001", "UG002", "UG003"}) {
        m.addStudent(StudentCategory::UG, id, "Student Name", "B.Tech", 3);
        m.recordMarks(id, "PF101", 75);
        m.registerForCourse(id, "DSA201");
    }
    m.addStudent(StudentCategory::PG, "PG001", "Post Grad", "M.Tech", 2);
    AcademicManager copy;
    CHECK(copy.importSnapshot(m.exportSnapshot()).ok);
    CHECK_EQ(copy.stats().students, 4u);
    CHECK_EQ(copy.findCourse("DSA201")->enrolledCount(), 2u);
    CHECK_EQ(copy.findCourse("DSA201")->waitlistPosition("UG003"), 1u);
    CHECK_EQ(copy.allPrerequisites("ADV301").size(), 2u);
    CHECK_EQ(copy.ranking().size(), 3u);
    CHECK(copy.findStudent("PG001")->category() == StudentCategory::PG);
    CHECK_EQ(copy.undoDepth(), 0u);  // undo history is per session
}

int main() {
    return testing::runAllTests("Academic workflow (AcademicManager facade)");
}
