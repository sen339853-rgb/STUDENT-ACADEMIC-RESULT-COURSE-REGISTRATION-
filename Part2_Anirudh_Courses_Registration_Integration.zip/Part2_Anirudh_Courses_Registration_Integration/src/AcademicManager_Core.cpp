// AcademicManager_Core.cpp
// Constructor, lookups, persistence (snapshot export/import) and analytics.
#include "AcademicManager.hpp"

#include <cmath>
#include <cstdio>
#include <stdexcept>

#include "AcademicManagerInternal.hpp"
#include "Validation.hpp"
#include "ds/searching_sorting.h"

namespace academic {

using detail::success;
using detail::failure;
using detail::twoDecimals;
using detail::copyField;

AcademicManager::AcademicManager()
    : studentIndex_(adoptHandle<HashTableHandle>(ht_create(16))),
      courseIndex_(adoptHandle<HashTableHandle>(ht_create(16))),
      prerequisites_(adoptHandle<GraphHandle>(graph_create(16))),
      ranking_(adoptHandle<AVLTreeHandle>(avl_create())),
      undo_(adoptHandle<StackHandle>(stack_create())),
      registration_(prerequisites_.get(), courseIndex_.get()) {}

// The C memory is released by the RAII handles; the moves just transfer them.
// RegistrationManager holds pointers to the graph and hash table themselves,
// which do not move in memory when their owning handles are moved.
AcademicManager::~AcademicManager() = default;
AcademicManager::AcademicManager(AcademicManager&&) noexcept = default;
AcademicManager& AcademicManager::operator=(AcademicManager&&) noexcept = default;

// ===========================================================================
// Lookups (C hash tables)
// ===========================================================================
int AcademicManager::studentSlot(const std::string& id) const {
    int slot = -1;
    return ht_find(studentIndex_.get(), id.c_str(), &slot) == DS_OK ? slot : -1;
}

int AcademicManager::courseSlot(const std::string& code) const {
    int slot = -1;
    return ht_find(courseIndex_.get(), code.c_str(), &slot) == DS_OK ? slot : -1;
}

Student* AcademicManager::studentAt(int slot) const {
    return slot < 0 ? nullptr : students_[static_cast<std::size_t>(slot)].get();
}

Course* AcademicManager::courseAt(int slot) const {
    return slot < 0 ? nullptr : courses_[static_cast<std::size_t>(slot)].get();
}

const Student* AcademicManager::findStudent(const std::string& id) const {
    return studentAt(studentSlot(normalizeId(id)));
}

const Course* AcademicManager::findCourse(const std::string& code) const {
    return courseAt(courseSlot(normalizeId(code)));
}

RegistrationManager::StudentLookup AcademicManager::studentLookup() const {
    return [this](const std::string& id) -> const Student* { return findStudent(id); };
}

bool AcademicManager::isEmpty() const {
    return ht_size(studentIndex_.get()) == 0 && ht_size(courseIndex_.get()) == 0;
}

// ===========================================================================
// Persistence: Snapshot export / import
// ===========================================================================
Snapshot AcademicManager::exportSnapshot() const {
    Snapshot snap;
    for (const Student* s : students()) {
        snap.students.push_back({s->id(), s->name(), s->program(), static_cast<int>(s->category()), s->semester()});
        for (const Result& r : s->results()) {
            snap.results.push_back({s->id(), r.courseCode(), r.centiMarks(), r.credits()});
        }
    }
    for (const Course* c : courses()) {
        snap.courses.push_back({c->code(), c->title(), c->credits(), c->capacity()});
        for (const std::string& p : directPrerequisites(c->code())) {
            snap.prerequisites.push_back({c->code(), p});
        }
        for (const std::string& id : c->enrolledIds()) snap.enrollments.push_back({c->code(), id});
        for (const std::string& id : c->waitlistIds()) snap.waitlists.push_back({c->code(), id});
    }
    return snap;
}

OpResult AcademicManager::restoreResult(const ResultRecord& r) {
    Student* s = studentAt(studentSlot(r.studentId));
    if (s == nullptr || courseSlot(r.courseCode) < 0) {
        return failure("result refers to an unknown student or course (" + r.studentId + ", " + r.courseCode + ")");
    }
    if (!Result::isValidCentiMarks(r.centiMarks) || r.credits < kMinCredits || r.credits > kMaxCredits) {
        return failure("result has invalid marks or credits (" + r.studentId + ", " + r.courseCode + ")");
    }
    if (s->findResult(r.courseCode) != nullptr) {
        return failure("duplicate result (" + r.studentId + ", " + r.courseCode + ")");
    }
    removeFromRanking(*s);
    s->upsertResult(r.courseCode, r.centiMarks, r.credits);
    addToRanking(*s);
    return success("");
}

OpResult AcademicManager::importSnapshot(const Snapshot& snap) {
    // Build a complete new state on the side. If any record is invalid we
    // return early and `fresh` is destroyed (RAII frees its C structures);
    // the current state is never half-replaced.
    AcademicManager fresh;
    for (const StudentRecord& r : snap.students) {
        if (r.category != static_cast<int>(StudentCategory::UG) && r.category != static_cast<int>(StudentCategory::PG)) {
            return failure("Load failed: student " + r.id + " has an unknown category.");
        }
        OpResult res = fresh.addStudent(static_cast<StudentCategory>(r.category), r.id, r.name, r.program, r.semester);
        if (!res.ok) return failure("Load failed: " + res.message);
    }
    for (const CourseRecord& r : snap.courses) {
        OpResult res = fresh.addCourse(r.code, r.title, r.credits, r.capacity);
        if (!res.ok) return failure("Load failed: " + res.message);
    }
    for (const PrerequisiteRecord& r : snap.prerequisites) {
        OpResult res = fresh.addPrerequisite(r.courseCode, r.prereqCode);  // rejects cycles
        if (!res.ok) return failure("Load failed: " + res.message);
    }
    if (graph_has_cycle(fresh.prerequisites_.get())) {
        return failure("Load failed: prerequisite graph contains a cycle.");
    }
    for (const ResultRecord& r : snap.results) {
        OpResult res = fresh.restoreResult(r);
        if (!res.ok) return failure("Load failed: " + res.message + ".");
    }
    for (const EnrollmentRecord& e : snap.enrollments) {
        Course* c = fresh.courseAt(fresh.courseSlot(e.courseCode));
        if (c == nullptr || fresh.findStudent(e.studentId) == nullptr || !c->enroll(e.studentId)) {
            return failure("Load failed: invalid enrolment (" + e.courseCode + ", " + e.studentId + ").");
        }
    }
    for (const EnrollmentRecord& e : snap.waitlists) {  // file order = FIFO order
        Course* c = fresh.courseAt(fresh.courseSlot(e.courseCode));
        if (c == nullptr || fresh.findStudent(e.studentId) == nullptr || !c->joinWaitlist(e.studentId)) {
            return failure("Load failed: invalid waitlist entry (" + e.courseCode + ", " + e.studentId + ").");
        }
    }
    *this = std::move(fresh);
    return success("Loaded " + std::to_string(snap.students.size()) + " students, " +
                   std::to_string(snap.courses.size()) + " courses, " + std::to_string(snap.results.size()) +
                   " results, " + std::to_string(snap.enrollments.size()) + " enrolments, " +
                   std::to_string(snap.waitlists.size()) + " waitlist entries.");
}

void AcademicManager::clear() {
    *this = AcademicManager();
}

// ===========================================================================
// Analytics
// ===========================================================================
SystemStats AcademicManager::stats() const {
    SystemStats st;
    st.students = ht_size(studentIndex_.get());
    st.courses = ht_size(courseIndex_.get());
    for (const Student* s : students()) st.results += s->results().size();
    for (const Course* c : courses()) {
        st.enrollments += c->enrolledCount();
        st.waitlisted += c->waitlistSize();
    }
    st.prerequisites = graph_edge_count(prerequisites_.get());
    st.undoDepth = stack_size(undo_.get());
    st.studentBuckets = ht_bucket_count(studentIndex_.get());
    st.studentLoadFactor = ht_load_factor(studentIndex_.get());
    st.studentLongestChain = ht_longest_chain(studentIndex_.get());
    st.studentCollidingBuckets = ht_colliding_buckets(studentIndex_.get());
    st.courseBuckets = ht_bucket_count(courseIndex_.get());
    st.courseLoadFactor = ht_load_factor(courseIndex_.get());
    st.courseLongestChain = ht_longest_chain(courseIndex_.get());
    st.rankedStudents = avl_size(ranking_.get());
    st.rankingTreeHeight = avl_height(ranking_.get());
    return st;
}

SearchDemo AcademicManager::searchDemo(const std::string& studentId) const {
    SearchDemo demo;
    const std::string id = normalizeId(studentId);
    std::vector<const Student*> all = students();
    std::vector<SortRecord> records(all.size());
    for (std::size_t i = 0; i < all.size(); ++i) {
        copyField(records[i].key, DS_KEY_LEN, all[i]->id());
        copyField(records[i].name, DS_NAME_LEN, all[i]->name());
        records[i].score = 0;
    }
    demo.records = records.size();
    // linear search on the unsorted (insertion-order) array
    demo.linearIndex = ss_linear_search_key(records.data(), records.size(), id.c_str(), &demo.linearComparisons);
    // binary search needs sorted input: merge sort by ID first
    ss_merge_sort(records.data(), records.size(), SORT_BY_KEY);
    demo.binaryIndex = ss_binary_search_key(records.data(), records.size(), id.c_str(), &demo.binaryComparisons);
    // hash lookup: one bucket, then a short chain
    demo.hashFound = ht_contains(studentIndex_.get(), id.c_str()) != 0;
    demo.hashBucket = ht_bucket_index(studentIndex_.get(), id.c_str());
    demo.hashLongestChain = ht_longest_chain(studentIndex_.get());
    return demo;
}

}  // namespace academic
