// main.cpp
// Menu-driven command-line interface.
//
// The CLI only talks to the AcademicManager facade (and the FileManager for
// saving/loading). It never touches C nodes, hash buckets or graph pointers.
// Choosing a portal is a role-specific menu for this prototype, NOT a login:
// there is no authentication or identity verification.
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "AcademicManager.hpp"
#include "Benchmark.hpp"
#include "ConsoleIO.hpp"
#include "DemoData.hpp"
#include "FileManager.hpp"
#include "Validation.hpp"

using namespace academic;

namespace {

// ===========================================================================
// Small output helpers
// ===========================================================================
std::string fixed2(double v) {
    char buffer[32];
    std::snprintf(buffer, sizeof buffer, "%.2f", v);
    return buffer;
}

void report(const OpResult& r) {
    std::cout << (r.ok ? "  [OK] " : "  [ERROR] ") << r.message << '\n';
}

std::string askId(const std::string& prompt) {
    return normalizeId(io::readRequired(prompt));
}

std::string joinList(const std::vector<std::string>& items, const std::string& empty = "none") {
    if (items.empty()) return empty;
    std::string out;
    for (std::size_t i = 0; i < items.size(); ++i) out += (i ? ", " : "") + items[i];
    return out;
}

bool saveRecords(const AcademicManager& m, const FileManager& files) {
    std::string error;
    if (!files.save(m.exportSnapshot(), error)) {
        std::cout << "  [ERROR] Save failed: " << error << '\n';
        return false;
    }
    std::cout << "  [SAVED] Records written to " << files.dataFile() << '\n';
    return true;
}

// ===========================================================================
// Display functions (read-only views of the facade)
// ===========================================================================
void printStudentTable(const AcademicManager& m, const std::vector<const Student*>& list) {
    if (list.empty()) {
        std::cout << "  (no students)\n";
        return;
    }
    std::cout << std::left << "  " << std::setw(10) << "ID" << std::setw(24) << "Name" << std::setw(5) << "Cat"
              << std::setw(14) << "Program" << std::setw(5) << "Sem" << std::setw(8) << "CGPA" << "Rank\n";
    for (const Student* s : list) {
        const int rank = m.rankOf(s->id());
        std::cout << "  " << std::setw(10) << s->id() << std::setw(24) << s->name().substr(0, 23) << std::setw(5)
                  << s->categoryName() << std::setw(14) << s->program().substr(0, 13) << std::setw(5)
                  << s->semester() << std::setw(8) << (s->hasResults() ? fixed2(s->cgpa()) : "-")
                  << (rank > 0 ? std::to_string(rank) : "-") << '\n';
    }
    std::cout << std::right;
}

void printProfile(const AcademicManager& m, const Student& s) {
    io::printRule();
    std::cout << "  Student ID   : " << s.id() << "\n"
              << "  Name         : " << s.name() << "\n"
              << "  Category     : " << s.categoryName() << " (" << s.gradingPolicy().name << ")\n"
              << "  Program      : " << s.program() << "\n"
              << "  Semester     : " << s.semester() << " of " << s.maxSemester() << "\n"
              << "  CGPA         : " << (s.hasResults() ? fixed2(s.cgpa()) : "-") << "\n"
              << "  Rank         : " << (m.rankOf(s.id()) > 0 ? std::to_string(m.rankOf(s.id())) : "-") << "\n"
              << "  Credits      : " << s.creditsEarned() << " earned / " << s.creditsAttempted() << " attempted\n"
              << "  Standing     : " << s.academicStanding(s.cgpa()) << "\n"
              << "  Registered   : " << joinList(m.registrationsOf(s.id())) << "\n";
    const auto waits = m.waitlistsOf(s.id());
    std::cout << "  Waitlisted   : ";
    if (waits.empty()) std::cout << "none";
    for (std::size_t i = 0; i < waits.size(); ++i) {
        std::cout << (i ? ", " : "") << waits[i].first << " (#" << waits[i].second << ")";
    }
    std::cout << '\n';
    io::printRule();
}

void printResults(const AcademicManager& m, const Student& s) {
    std::cout << "\n  Results for " << s.id() << " - " << s.name() << " [" << s.categoryName() << "]\n";
    if (!s.hasResults()) {
        std::cout << "  (no results recorded)\n";
        return;
    }
    std::cout << std::left << "  " << std::setw(9) << "Course" << std::setw(36) << "Title" << std::setw(5) << "Cr"
              << std::setw(8) << "Marks" << std::setw(6) << "Grade" << std::setw(7) << "Points" << "Status\n";
    for (const Result& r : s.results()) {
        const GradeInfo g = s.evaluate(r.centiMarks());  // runtime polymorphism
        const Course* c = m.findCourse(r.courseCode());
        std::cout << "  " << std::setw(9) << r.courseCode() << std::setw(36)
                  << (c ? c->title().substr(0, 35) : "(removed)") << std::setw(5) << r.credits() << std::setw(8)
                  << Result::formatMarks(r.centiMarks()) << std::setw(6) << g.letter << std::setw(7) << g.gradePoint
                  << (g.passed ? "PASS" : "FAIL") << '\n';
    }
    std::cout << std::right << "  CGPA " << fixed2(s.cgpa()) << " | credits earned " << s.creditsEarned() << "/"
              << s.creditsAttempted() << " | " << s.academicStanding(s.cgpa()) << '\n';
}

void printCourseTable(const AcademicManager& m, const std::vector<const Course*>& list) {
    if (list.empty()) {
        std::cout << "  (no courses)\n";
        return;
    }
    std::cout << std::left << "  " << std::setw(8) << "Code" << std::setw(36) << "Title" << std::setw(4) << "Cr"
              << std::setw(10) << "Enrolled" << std::setw(6) << "Free" << std::setw(6) << "Wait" << "Prerequisites\n";
    for (const Course* c : list) {
        std::cout << "  " << std::setw(8) << c->code() << std::setw(36) << c->title().substr(0, 35) << std::setw(4)
                  << c->credits() << std::setw(10)
                  << (std::to_string(c->enrolledCount()) + "/" + std::to_string(c->capacity())) << std::setw(6)
                  << c->availableSeats() << std::setw(6) << c->waitlistSize()
                  << joinList(m.directPrerequisites(c->code()), "-") << '\n';
    }
    std::cout << std::right;
}

void printCourseDetails(const AcademicManager& m, const Course& c) {
    io::printRule();
    std::cout << "  Course        : " << c.code() << " - " << c.title() << "\n"
              << "  Credits       : " << c.credits() << "\n"
              << "  Seats         : " << c.enrolledCount() << " occupied / " << c.capacity() << " capacity, "
              << c.availableSeats() << " available\n"
              << "  Prerequisites : " << joinList(m.directPrerequisites(c.code())) << " (direct)\n"
              << "  Full chain    : " << joinList(m.allPrerequisites(c.code())) << " (DFS, foundational first)\n"
              << "  Required by   : " << joinList(m.directDependents(c.code())) << "\n"
              << "  Roster        : " << joinList(c.enrolledIds()) << "\n"
              << "  Waiting list  : ";
    const auto wait = c.waitlistIds();
    if (wait.empty()) std::cout << "empty";
    for (std::size_t i = 0; i < wait.size(); ++i) std::cout << (i ? "  " : "") << i + 1 << "." << wait[i];
    std::cout << '\n';
    io::printRule();
}

void printRanking(const std::vector<RankingEntry>& rows, const std::string& heading) {
    std::cout << "\n  " << heading << '\n';
    if (rows.empty()) {
        std::cout << "  (no students with results)\n";
        return;
    }
    std::cout << std::left << "  " << std::setw(6) << "Rank" << std::setw(10) << "ID" << std::setw(24) << "Name"
              << std::setw(5) << "Cat" << "CGPA\n";
    for (const RankingEntry& r : rows) {
        std::cout << "  " << std::setw(6) << r.rank << std::setw(10) << r.studentId << std::setw(24)
                  << r.name.substr(0, 23) << std::setw(5) << r.category << fixed2(r.cgpa) << '\n';
    }
    std::cout << std::right << "  (equal CGPA -> equal rank; ties listed by student ID)\n";
}

void printOutcome(const RegistrationOutcome& o) {
    std::cout << (o.ok() ? "  [OK] " : "  [REJECTED] ") << o.message << '\n';
}

void printPolicies() {
    for (const GradingPolicy* p : {&undergraduatePolicy(), &postgraduatePolicy()}) {
        std::cout << "\n  " << p->name << ": pass mark " << Result::formatMarks(p->passCentiMarks)
                  << ", good standing CGPA >= " << fixed2(p->goodStandingCgpa) << ", " << p->maxSemester
                  << " semesters\n   ";
        for (const GradeBand& b : p->bands) {
            std::cout << " " << b.letter << ">=" << b.minCentiMarks / 100 << "(" << b.gradePoint << ")";
        }
        std::cout << '\n';
    }
    std::cout << "\n  These are demonstration defaults for this project, not the university's\n"
                 "  official grading scheme. They are defined in src/Student.cpp.\n";
}

// ===========================================================================
// Shared actions used by more than one portal
// ===========================================================================
void actViewResults(const AcademicManager& m) {
    const Student* s = m.findStudent(askId("Student ID: "));
    if (s == nullptr) {
        std::cout << "  [ERROR] Student not found.\n";
        return;
    }
    printResults(m, *s);
}

void actEnterMarks(AcademicManager& m) {
    const std::string sid = askId("Student ID: ");
    const std::string code = askId("Course code: ");
    const double marks = io::readDouble("Marks (0-100): ", 0.0, 100.0);
    report(m.recordMarks(sid, code, marks));
}

void actUndo(AcademicManager& m) {
    MarksChange top{};
    if (m.peekUndo(top)) {
        std::cout << "  Last change: " << top.student_id << " / " << top.course_code << " ("
                  << (top.action == MARKS_ENTERED ? "new entry" : "updated from " + Result::formatMarks(top.previous_centi))
                  << " -> " << Result::formatMarks(top.new_centi) << ")\n";
    }
    report(m.undoLastMarksEntry());
}

void actRoster(const AcademicManager& m) {
    const Course* c = m.findCourse(askId("Course code: "));
    if (c == nullptr) {
        std::cout << "  [ERROR] Course not found.\n";
        return;
    }
    printCourseDetails(m, *c);
}

void actRegister(AcademicManager& m, const FileManager& files, const std::string& studentId) {
    const RegistrationOutcome o = m.registerForCourse(studentId, askId("Course code to register for: "));
    printOutcome(o);
    if (o.ok()) saveRecords(m, files);  // registration workflow ends by saving state
}

void actCancel(AcademicManager& m, const FileManager& files, const std::string& studentId) {
    const OpResult r = m.cancelRegistration(studentId, askId("Course code to cancel: "));
    report(r);
    if (r.ok) saveRecords(m, files);
}

void actCheckPrereqs(const AcademicManager& m, const std::string& studentId) {
    PrerequisiteReport rep;
    std::string error;
    const std::string code = askId("Course code: ");
    if (!m.checkPrerequisites(studentId, code, rep, error)) {
        std::cout << "  [ERROR] " << error << '\n';
        return;
    }
    std::cout << "  Required (direct + transitive, via DFS): " << joinList(rep.required) << '\n'
              << "  Not yet passed: " << joinList(rep.missing) << '\n'
              << (rep.eligible() ? "  -> ELIGIBLE for " : "  -> NOT eligible for ") << code << '\n';
}

// ===========================================================================
// Student portal
// ===========================================================================
void studentPortal(AcademicManager& m, const FileManager& files) {
    io::printTitle("STUDENT PORTAL");
    std::cout << "  (Selecting a student ID is not a login - this prototype has no authentication.)\n";
    const std::string sid = askId("Enter your student ID: ");
    if (m.findStudent(sid) == nullptr) {  // located through the C hash table
        std::cout << "  [ERROR] No student with ID " << sid << ".\n";
        return;
    }
    for (;;) {
        const Student* s = m.findStudent(sid);
        if (s == nullptr) return;
        io::printTitle("STUDENT PORTAL - " + s->id() + " " + s->name());
        std::cout << "  1. View Student Profile\n  2. View Academic Results\n  3. View Available Courses\n"
                     "  4. Check Course Prerequisites\n  5. Register for a Course\n  6. View Current Registrations\n"
                     "  7. View Waitlist Status\n  8. Cancel Registration / Leave Waitlist\n  0. Back\n";
        switch (io::readInt("Enter your choice: ", 0, 8)) {
        case 0: return;
        case 1: printProfile(m, *s); break;
        case 2: printResults(m, *s); break;
        case 3: {
            printCourseTable(m, m.sortedCourses(CourseSortKey::Code));
            std::cout << "\n  Your status per course:\n";
            for (const Course* c : m.sortedCourses(CourseSortKey::Code)) {
                PrerequisiteReport rep;
                std::string err;
                m.checkPrerequisites(sid, c->code(), rep, err);
                std::string status;
                if (c->isEnrolled(sid)) status = "ENROLLED";
                else if (c->isWaitlisted(sid)) status = "WAITLISTED #" + std::to_string(c->waitlistPosition(sid));
                else if (s->hasPassed(c->code())) status = "already passed";
                else if (!rep.eligible()) status = "missing " + joinList(rep.missing);
                else status = c->isFull() ? "eligible (full - would be waitlisted)" : "eligible";
                std::cout << "    " << std::left << std::setw(8) << c->code() << std::right << status << '\n';
            }
            break;
        }
        case 4: actCheckPrereqs(m, sid); break;
        case 5: actRegister(m, files, sid); break;
        case 6: std::cout << "  Current registrations: " << joinList(m.registrationsOf(sid)) << '\n'; break;
        case 7: {
            const auto waits = m.waitlistsOf(sid);
            if (waits.empty()) std::cout << "  You are not on any waiting list.\n";
            for (const auto& w : waits) {
                const Course* c = m.findCourse(w.first);
                std::cout << "  " << w.first << ": position " << w.second << " of " << c->waitlistSize()
                          << " (seats " << c->enrolledCount() << "/" << c->capacity() << ")\n";
            }
            break;
        }
        case 8: actCancel(m, files, sid); break;
        }
    }
}

// ===========================================================================
// Administrator portal
// ===========================================================================
void adminStudents(AcademicManager& m) {
    for (;;) {
        io::printTitle("ADMIN - STUDENT RECORDS");
        std::cout << "  1. Add Student\n  2. View Student by ID (hash table)\n  3. Search Students by Name\n"
                     "  4. Update Student\n  5. Delete Student\n  6. List All Students\n"
                     "  7. Sort Students (merge sort)\n  0. Back\n";
        switch (io::readInt("Enter your choice: ", 0, 7)) {
        case 0: return;
        case 1: {
            const int cat = io::readInt("Category (1 = UG, 2 = PG): ", 1, 2);
            const std::string id = askId("Student ID: ");
            const std::string name = io::readRequired("Full name: ");
            const std::string program = io::readRequired("Program (e.g. B.Tech CSE): ");
            const int maxSem = cat == 1 ? undergraduatePolicy().maxSemester : postgraduatePolicy().maxSemester;
            const int sem = io::readInt("Semester (1-" + std::to_string(maxSem) + "): ", 1, maxSem);
            report(m.addStudent(cat == 1 ? StudentCategory::UG : StudentCategory::PG, id, name, program, sem));
            break;
        }
        case 2: {
            const Student* s = m.findStudent(askId("Student ID: "));
            if (s) printProfile(m, *s);
            else std::cout << "  [ERROR] Student not found.\n";
            break;
        }
        case 3: printStudentTable(m, m.searchStudentsByName(io::readRequired("Name contains: "))); break;
        case 4: {
            const std::string id = askId("Student ID: ");
            const Student* s = m.findStudent(id);
            if (!s) {
                std::cout << "  [ERROR] Student not found.\n";
                break;
            }
            std::cout << "  Leave a field blank to keep its current value.\n";
            const std::string name = io::readLine("New name [" + s->name() + "]: ");
            const std::string program = io::readLine("New program [" + s->program() + "]: ");
            const int sem = io::readOptionalInt("New semester [" + std::to_string(s->semester()) + "]: ", 1,
                                                s->maxSemester());
            report(m.updateStudent(id, name, program, sem));
            break;
        }
        case 5: {
            const std::string id = askId("Student ID to delete: ");
            if (io::readYesNo("Delete " + id + " and all of their results?")) report(m.deleteStudent(id));
            break;
        }
        case 6: printStudentTable(m, m.students()); break;
        case 7: {
            const int k = io::readInt("Sort by 1 = ID, 2 = Name, 3 = CGPA (high first): ", 1, 3);
            const StudentSortKey key = k == 1 ? StudentSortKey::Id : k == 2 ? StudentSortKey::Name : StudentSortKey::CgpaHighFirst;
            printStudentTable(m, m.sortedStudents(key));
            break;
        }
        }
    }
}

void adminCourses(AcademicManager& m) {
    for (;;) {
        io::printTitle("ADMIN - COURSE MANAGEMENT");
        std::cout << "  1. Add Course\n  2. View Course Details\n  3. Update Course\n  4. Remove Course\n"
                     "  5. List All Courses / Seat Availability\n  6. Sort Courses (merge sort)\n"
                     "  7. Add Prerequisite\n  8. Remove Prerequisite\n  9. View Prerequisite Chain\n"
                     " 10. Recommended Study Order (topological sort)\n  0. Back\n";
        switch (io::readInt("Enter your choice: ", 0, 10)) {
        case 0: return;
        case 1: {
            const std::string code = askId("Course code: ");
            const std::string title = io::readRequired("Course title: ");
            const int credits = io::readInt("Credits (1-6): ", kMinCredits, kMaxCredits);
            const int capacity = io::readInt("Seat capacity (1-500): ", kMinCapacity, kMaxCapacity);
            report(m.addCourse(code, title, credits, capacity));
            break;
        }
        case 2: actRoster(m); break;
        case 3: {
            const std::string code = askId("Course code: ");
            const Course* c = m.findCourse(code);
            if (!c) {
                std::cout << "  [ERROR] Course not found.\n";
                break;
            }
            std::cout << "  Leave a field blank to keep its current value.\n";
            const std::string title = io::readLine("New title [" + c->title() + "]: ");
            const int credits = io::readOptionalInt("New credits [" + std::to_string(c->credits()) + "]: ", kMinCredits, kMaxCredits);
            const int capacity = io::readOptionalInt("New capacity [" + std::to_string(c->capacity()) + "]: ", kMinCapacity, kMaxCapacity);
            report(m.updateCourse(code, title, credits, capacity));
            break;
        }
        case 4: {
            const std::string code = askId("Course code to remove: ");
            if (io::readYesNo("Remove course " + code + "?")) report(m.removeCourse(code));
            break;
        }
        case 5: printCourseTable(m, m.courses()); break;
        case 6: {
            const int k = io::readInt("Sort by 1 = Code, 2 = Title, 3 = Enrolment (high first): ", 1, 3);
            const CourseSortKey key = k == 1 ? CourseSortKey::Code : k == 2 ? CourseSortKey::Title : CourseSortKey::EnrolledHighFirst;
            printCourseTable(m, m.sortedCourses(key));
            break;
        }
        case 7: {
            const std::string course = askId("Course code: ");
            const std::string prereq = askId("Required prerequisite course code: ");
            report(m.addPrerequisite(course, prereq));
            break;
        }
        case 8: {
            const std::string course = askId("Course code: ");
            const std::string prereq = askId("Prerequisite to remove: ");
            report(m.removePrerequisite(course, prereq));
            break;
        }
        case 9: {
            const std::string code = askId("Course code: ");
            if (!m.findCourse(code)) {
                std::cout << "  [ERROR] Course not found.\n";
                break;
            }
            std::cout << "  Direct prerequisites : " << joinList(m.directPrerequisites(code)) << '\n'
                      << "  Full chain (DFS)     : " << joinList(m.allPrerequisites(code)) << '\n'
                      << "  Direct dependents    : " << joinList(m.directDependents(code)) << '\n';
            break;
        }
        case 10: std::cout << "  Study order: " << joinList(m.studyOrder()) << '\n'; break;
        }
    }
}

void adminResults(AcademicManager& m) {
    for (;;) {
        io::printTitle("ADMIN - RESULT MANAGEMENT");
        std::cout << "  1. Enter / Update Marks\n  2. View Student Results\n  3. Undo Last Marks Entry\n"
                     "  4. Student Ranking (AVL tree)\n  5. Sort Students by CGPA (merge sort)\n"
                     "  6. Grading Policies (UG vs PG)\n  0. Back\n";
        switch (io::readInt("Enter your choice: ", 0, 6)) {
        case 0: return;
        case 1: actEnterMarks(m); break;
        case 2: actViewResults(m); break;
        case 3: actUndo(m); break;
        case 4: printRanking(m.ranking(), "Ranking by CGPA (reverse inorder of the AVL tree)"); break;
        case 5: printStudentTable(m, m.sortedStudents(StudentSortKey::CgpaHighFirst)); break;
        case 6: printPolicies(); break;
        }
    }
}

void adminRegistrations(AcademicManager& m, const FileManager& files) {
    for (;;) {
        io::printTitle("ADMIN - REGISTRATION MANAGEMENT");
        std::cout << "  1. Register Student for Course\n  2. Cancel Registration / Waitlist Entry\n"
                     "  3. View Course Roster and Waitlist\n  4. Process Waitlist for a Course\n"
                     "  5. Check Prerequisites for a Student\n  0. Back\n";
        switch (io::readInt("Enter your choice: ", 0, 5)) {
        case 0: return;
        case 1: actRegister(m, files, askId("Student ID: ")); break;
        case 2: actCancel(m, files, askId("Student ID: ")); break;
        case 3: actRoster(m); break;
        case 4: {
            const OpResult r = m.processWaitlist(askId("Course code: "));
            report(r);
            if (r.ok) saveRecords(m, files);
            break;
        }
        case 5: actCheckPrereqs(m, askId("Student ID: ")); break;
        }
    }
}

void adminPortal(AcademicManager& m, const FileManager& files) {
    for (;;) {
        io::printTitle("ADMINISTRATOR PORTAL");
        std::cout << "  1. Student Records\n  2. Course Management\n  3. Result Management\n"
                     "  4. Registration Management\n  5. Load Sample Dataset (empty system only)\n  0. Back\n";
        switch (io::readInt("Enter your choice: ", 0, 5)) {
        case 0: return;
        case 1: adminStudents(m); break;
        case 2: adminCourses(m); break;
        case 3: adminResults(m); break;
        case 4: adminRegistrations(m, files); break;
        case 5: report(loadSampleData(m)); break;
        }
    }
}

// ===========================================================================
// Academic staff portal
// ===========================================================================
void staffPortal(AcademicManager& m) {
    for (;;) {
        io::printTitle("ACADEMIC STAFF PORTAL");
        std::cout << "  1. View Student Results\n  2. Enter / Update Marks\n  3. Undo Last Marks Entry\n"
                     "  4. Student Ranking\n  5. Top Performers (CGPA at least X)\n"
                     "  6. Monitor Course Enrollments\n  7. View Course Roster and Waitlist\n  0. Back\n";
        switch (io::readInt("Enter your choice: ", 0, 7)) {
        case 0: return;
        case 1: actViewResults(m); break;
        case 2: actEnterMarks(m); break;
        case 3: actUndo(m); break;
        case 4: printRanking(m.ranking(), "Ranking by CGPA (reverse inorder of the AVL tree)"); break;
        case 5: {
            const double min = io::readDouble("Minimum CGPA (0-10): ", 0.0, 10.0);
            printRanking(m.rankingAtLeast(min), "Students with CGPA >= " + fixed2(min) + " (pruned AVL walk)");
            break;
        }
        case 6: printCourseTable(m, m.sortedCourses(CourseSortKey::EnrolledHighFirst)); break;
        case 7: actRoster(m); break;
        }
    }
}

// ===========================================================================
// DSA & performance demonstration
// ===========================================================================
void dsaPortal(AcademicManager& m) {
    for (;;) {
        io::printTitle("DSA & PERFORMANCE DEMONSTRATION");
        std::cout << "  1. System Statistics (hash tables, AVL tree, graph, stack)\n"
                     "  2. Search Comparison: Linear vs Binary vs Hash\n"
                     "  3. Ranking Traversals: Reverse Inorder vs Inorder\n"
                     "  4. Prerequisite Graph: Adjacency Lists + Topological Order\n"
                     "  5. Waiting Lists (FIFO Queues)\n  6. Undo Stack (LIFO)\n"
                     "  7. Sorting Demonstration (merge sort)\n  8. Run Performance Benchmark\n  0. Back\n";
        switch (io::readInt("Enter your choice: ", 0, 8)) {
        case 0: return;
        case 1: {
            const SystemStats st = m.stats();
            std::cout << "  Students " << st.students << ", courses " << st.courses << ", results " << st.results
                      << ", enrolments " << st.enrollments << ", waitlisted " << st.waitlisted << "\n"
                      << "  Student hash table: " << st.studentBuckets << " buckets, load factor "
                      << fixed2(st.studentLoadFactor) << ", longest chain " << st.studentLongestChain
                      << ", buckets with collisions " << st.studentCollidingBuckets << "\n"
                      << "  Course hash table : " << st.courseBuckets << " buckets, load factor "
                      << fixed2(st.courseLoadFactor) << ", longest chain " << st.courseLongestChain << "\n"
                      << "  Ranking AVL tree  : " << st.rankedStudents << " nodes, height " << st.rankingTreeHeight;
            if (st.rankedStudents > 0) {
                const double n = static_cast<double>(st.rankedStudents);
                std::cout << " (best possible " << std::ceil(std::log2(n + 1.0)) << ", AVL worst-case bound "
                          << fixed2(1.44 * std::log2(n + 2.0)) << ")";
            }
            std::cout << "\n  Prerequisite graph: " << st.courses << " vertices, " << st.prerequisites << " edges\n"
                      << "  Undo stack depth  : " << st.undoDepth << '\n';
            break;
        }
        case 2: {
            const std::string id = askId("Student ID to search for: ");
            const SearchDemo d = m.searchDemo(id);
            std::cout << "  Records searched: " << d.records << "\n"
                      << "  Linear search (unsorted array) : " << (d.linearIndex >= 0 ? "found" : "not found")
                      << " after " << d.linearComparisons << " comparisons\n"
                      << "  Binary search (after merge sort): " << (d.binaryIndex >= 0 ? "found" : "not found")
                      << " after " << d.binaryComparisons << " comparisons\n"
                      << "  Hash table lookup               : " << (d.hashFound ? "found" : "not found")
                      << " in bucket " << d.hashBucket << " (longest chain in table: " << d.hashLongestChain << ")\n";
            break;
        }
        case 3:
            printRanking(m.ranking(), "Reverse inorder (right-node-left): highest CGPA first");
            printRanking(m.rankingLowestFirst(), "Inorder (left-node-right): lowest CGPA first");
            break;
        case 4: {
            std::cout << "  Adjacency lists (course -> its direct prerequisites):\n";
            for (const Course* c : m.sortedCourses(CourseSortKey::Code)) {
                std::cout << "    " << std::left << std::setw(8) << c->code() << std::right << "-> "
                          << joinList(m.directPrerequisites(c->code()), "(none)") << '\n';
            }
            std::cout << "  Topological study order (DFS post-order): " << joinList(m.studyOrder()) << '\n';
            break;
        }
        case 5: {
            bool any = false;
            for (const Course* c : m.sortedCourses(CourseSortKey::Code)) {
                if (c->waitlistSize() == 0) continue;
                any = true;
                std::cout << "  " << c->code() << " (" << c->enrolledCount() << "/" << c->capacity()
                          << ") front -> rear: " << joinList(c->waitlistIds()) << '\n';
            }
            if (!any) std::cout << "  All waiting lists are empty.\n";
            break;
        }
        case 6: {
            MarksChange top{};
            std::cout << "  Undo stack depth: " << m.undoDepth() << '\n';
            if (m.peekUndo(top)) {
                std::cout << "  Top (next undo): " << top.student_id << " / " << top.course_code << ", "
                          << (top.action == MARKS_ENTERED ? "new entry" : "update from " + Result::formatMarks(top.previous_centi))
                          << " -> " << Result::formatMarks(top.new_centi) << '\n';
            }
            break;
        }
        case 7: {
            std::cout << "\n  Students by ID:\n";
            printStudentTable(m, m.sortedStudents(StudentSortKey::Id));
            std::cout << "\n  Students by name:\n";
            printStudentTable(m, m.sortedStudents(StudentSortKey::Name));
            std::cout << "\n  Students by CGPA (no results last):\n";
            printStudentTable(m, m.sortedStudents(StudentSortKey::CgpaHighFirst));
            std::cout << "\n  Courses by enrolment:\n";
            printCourseTable(m, m.sortedCourses(CourseSortKey::EnrolledHighFirst));
            break;
        }
        case 8: {
            const int n = io::readInt("Synthetic records (1000-200000, e.g. 20000): ", 1000, 200000);
            std::cout << "  Running...\n";
            const auto rows = runBenchmarks(static_cast<std::size_t>(n));
            printBenchmarks(std::cout, rows, static_cast<std::size_t>(n));
            break;
        }
        }
    }
}

// ===========================================================================
// Startup / reload
// ===========================================================================
void loadAtStartup(AcademicManager& m, const FileManager& files) {
    Snapshot snap;
    std::string error;
    switch (files.load(snap, error)) {
    case LoadStatus::Missing:
        std::cout << "  No saved records at " << files.dataFile() << " - starting with an empty system.\n"
                  << "  (Administrator Portal -> 5 loads a fictional sample dataset.)\n";
        return;
    case LoadStatus::Corrupt:
        break;
    case LoadStatus::Loaded: {
        const OpResult r = m.importSnapshot(snap);
        if (r.ok) {
            std::cout << "  " << r.message << '\n';
            return;
        }
        error = r.message;
        break;
    }
    }
    std::string moved;
    files.quarantine(moved);
    std::cout << "  [WARNING] Saved records could not be used: " << error << "\n"
              << "  The file was kept as " << moved << ". Starting with an empty system.\n";
}

void reloadRecords(AcademicManager& m, const FileManager& files) {
    if (!io::readYesNo("Reload from disk and discard unsaved changes?")) return;
    Snapshot snap;
    std::string error;
    const LoadStatus st = files.load(snap, error);
    if (st == LoadStatus::Missing) {
        std::cout << "  [ERROR] No saved file found; current data kept.\n";
        return;
    }
    if (st == LoadStatus::Corrupt) {
        std::cout << "  [ERROR] Saved file is corrupted (" << error << "); current data kept.\n";
        return;
    }
    report(m.importSnapshot(snap));  // all-or-nothing: failure keeps the current data
}

void printUsage() {
    std::cout << "Usage: academic_system [--data-dir DIR]\n"
                 "  --data-dir DIR   folder for academic_records.dat (default: data)\n";
}

}  // namespace

int main(int argc, char** argv) {
    std::string dataDir = "data";
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--data-dir" && i + 1 < argc) {
            dataDir = argv[++i];
        } else if (arg == "--help" || arg == "-h") {
            printUsage();
            return 0;
        } else {
            printUsage();
            return 1;
        }
    }
    io::setEchoInput(!io::stdinIsTerminal());

    AcademicManager manager;
    const FileManager files(dataDir);

    io::printTitle("STUDENT ACADEMIC RESULT & COURSE REGISTRATION\n          HYBRID C/C++ MANAGEMENT SYSTEM");
    loadAtStartup(manager, files);

    try {
        for (;;) {
            io::printTitle("MAIN MENU");
            std::cout << "  1. Student Portal\n  2. Administrator Portal\n  3. Academic Staff Portal\n"
                         "  4. DSA & Performance Demonstration\n  5. Save Records\n  6. Reload Records\n  0. Exit\n";
            const int choice = io::readInt("Enter your choice: ", 0, 6);
            if (choice == 0) break;
            switch (choice) {
            case 1: studentPortal(manager, files); break;
            case 2: adminPortal(manager, files); break;
            case 3: staffPortal(manager); break;
            case 4: dsaPortal(manager); break;
            case 5: saveRecords(manager, files); break;
            case 6: reloadRecords(manager, files); break;
            }
        }
    } catch (const io::InputClosed&) {
        std::cout << "\n  [input ended]\n";
    }

    std::cout << "  Saving before exit...\n";
    const bool saved = saveRecords(manager, files);
    std::cout << "  Goodbye.\n";
    return saved ? 0 : 2;
}
