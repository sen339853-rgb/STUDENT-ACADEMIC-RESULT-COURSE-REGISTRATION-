// AcademicManagerInternal.hpp
// Private helpers shared by the AcademicManager*.cpp files (one file per module,
// so four people can commit without merge conflicts). Not part of the public API.
#ifndef ACADEMIC_MANAGER_INTERNAL_HPP
#define ACADEMIC_MANAGER_INTERNAL_HPP

#include <cstddef>
#include <cstdio>
#include <string>

#include "AcademicManager.hpp"

namespace academic {
namespace detail {

inline OpResult success(const std::string& message) { return OpResult{true, message}; }
inline OpResult failure(const std::string& message) { return OpResult{false, message}; }

inline std::string twoDecimals(double value) {
    char buffer[32];
    std::snprintf(buffer, sizeof buffer, "%.2f", value);
    return buffer;
}

inline void copyField(char* dst, std::size_t size, const std::string& src) {
    // Fields were validated to fit; truncate defensively anyway.
    std::size_t n = src.size() < size - 1 ? src.size() : size - 1;
    src.copy(dst, n);
    dst[n] = '\0';
}

}  // namespace detail
}  // namespace academic

#endif  // ACADEMIC_MANAGER_INTERNAL_HPP
