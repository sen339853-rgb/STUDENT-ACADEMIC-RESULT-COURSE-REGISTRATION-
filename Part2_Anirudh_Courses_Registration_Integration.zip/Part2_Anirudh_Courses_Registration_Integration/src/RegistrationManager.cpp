// RegistrationManager.cpp
#include "RegistrationManager.hpp"

namespace academic {

namespace {

std::string joinCodes(const std::vector<std::string>& codes) {
    std::string out;
    for (std::size_t i = 0; i < codes.size(); ++i) {
        out += (i == 0 ? "" : ", ") + codes[i];
    }
    return out;
}

}  // namespace

RegistrationManager::RegistrationManager(const Graph* prerequisites, const HashTable* courseIndex)
    : graph_(prerequisites), courseIndex_(courseIndex) {}

PrerequisiteReport RegistrationManager::checkPrerequisites(const Student& student, int courseSlot) const {
    PrerequisiteReport report;
    const std::size_t capacity = graph_capacity(graph_);

    // 1. Mark every course the student has PASSED (not merely registered for).
    //    Course codes become graph vertex ids through the course hash table.
    std::vector<unsigned char> passed(capacity, 0);
    for (const Result& r : student.results()) {
        int slot = -1;
        if (student.evaluate(r.centiMarks()).passed &&  // virtual: UG and PG pass marks differ
            ht_find(courseIndex_, r.courseCode().c_str(), &slot) == DS_OK &&
            slot >= 0 && static_cast<std::size_t>(slot) < capacity) {
            passed[static_cast<std::size_t>(slot)] = 1;
        }
    }

    // 2. All direct + transitive prerequisites, found by DFS in C.
    std::vector<int> chain(capacity > 0 ? capacity : 1);
    const std::size_t n = graph_all_prereqs(graph_, courseSlot, chain.data(), chain.size());
    for (std::size_t i = 0; i < n; ++i) {
        report.required.emplace_back(graph_vertex_label(graph_, chain[i]));
    }

    // 3. The C DFS validation itself: which of those are not passed?
    std::vector<int> missing(capacity > 0 ? capacity : 1);
    std::size_t missingCount = 0;
    if (graph_check_prereqs(graph_, courseSlot, passed.data(), passed.size(), missing.data(),
                            missing.size(), &missingCount) == DS_OK) {
        for (std::size_t i = 0; i < missingCount && i < missing.size(); ++i) {
            report.missing.emplace_back(graph_vertex_label(graph_, missing[i]));
        }
    }
    return report;
}

RegistrationOutcome RegistrationManager::requestRegistration(const Student& student, Course& course,
                                                             int courseSlot) const {
    RegistrationOutcome out;
    const std::string& id = student.id();

    if (course.isEnrolled(id)) {
        out.status = RegistrationStatus::AlreadyEnrolled;
        out.message = id + " is already enrolled in " + course.code() + ".";
        return out;
    }
    if (course.isWaitlisted(id)) {
        out.status = RegistrationStatus::AlreadyWaitlisted;
        out.waitlistPosition = course.waitlistPosition(id);
        out.message = id + " is already on the " + course.code() + " waiting list (position " +
                      std::to_string(out.waitlistPosition) + ").";
        return out;
    }
    if (student.hasPassed(course.code())) {
        out.status = RegistrationStatus::AlreadyPassed;
        out.message = id + " has already passed " + course.code() + ".";
        return out;
    }

    const PrerequisiteReport report = checkPrerequisites(student, courseSlot);
    if (!report.eligible()) {
        out.status = RegistrationStatus::MissingPrerequisites;
        out.missingPrerequisites = report.missing;
        out.message = "Rejected: " + course.code() + " requires " + joinCodes(report.required) +
                      ". Not yet passed: " + joinCodes(report.missing) + ".";
        return out;
    }

    if (!course.isFull()) {
        if (!course.enroll(id)) {
            out.status = RegistrationStatus::Failed;
            out.message = "Could not add the enrolment (out of memory).";
            return out;
        }
        out.status = RegistrationStatus::Enrolled;
        out.message = id + " enrolled in " + course.code() + " (" + std::to_string(course.enrolledCount()) +
                      "/" + std::to_string(course.capacity()) + " seats filled).";
        return out;
    }

    if (!course.joinWaitlist(id)) {
        out.status = RegistrationStatus::Failed;
        out.message = "Could not add the waiting-list entry (out of memory).";
        return out;
    }
    out.status = RegistrationStatus::Waitlisted;
    out.waitlistPosition = course.waitlistPosition(id);
    out.message = course.code() + " is full (" + std::to_string(course.capacity()) + " seats). " + id +
                  " joined the waiting list at position " + std::to_string(out.waitlistPosition) + ".";
    return out;
}

std::vector<PromotionEvent> RegistrationManager::fillVacancies(Course& course, int courseSlot,
                                                               const StudentLookup& findStudent) const {
    std::vector<PromotionEvent> events;
    std::string id;
    while (!course.isFull() && course.popWaitlistFront(id)) {  // FIFO: front of the queue first
        PromotionEvent event;
        event.studentId = id;
        const Student* student = findStudent(id);
        if (student == nullptr) {
            event.reason = "student record no longer exists";
        } else if (student->hasPassed(course.code())) {
            event.reason = "has already passed " + course.code();
        } else {
            const PrerequisiteReport report = checkPrerequisites(*student, courseSlot);
            if (!report.eligible()) {
                event.reason = "no longer meets prerequisites (" + joinCodes(report.missing) + ")";
            } else if (course.enroll(id)) {
                event.promoted = true;
                event.reason = "promoted from the waiting list";
            } else {
                event.reason = "enrolment failed (out of memory)";
            }
        }
        events.push_back(event);
    }
    return events;
}

}  // namespace academic
