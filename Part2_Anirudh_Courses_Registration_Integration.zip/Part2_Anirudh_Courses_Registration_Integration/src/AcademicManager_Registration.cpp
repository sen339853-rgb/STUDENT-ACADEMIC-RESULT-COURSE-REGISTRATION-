// AcademicManager_Registration.cpp
// Module D - course registration, waitlist.
#include "AcademicManager.hpp"

#include <cmath>
#include <cstdio>
#include <stdexcept>

#include "AcademicManagerInternal.hpp"
#include "Validation.hpp"
#include "ds/searching_sorting.h"

namespace academic {

using detail::success;
using detail::failure;
using detail::twoDecimals;
using detail::copyField;

// ===========================================================================
// Module D - course registration
// ===========================================================================
bool AcademicManager::checkPrerequisites(const std::string& studentId, const std::string& courseCode,
                                         PrerequisiteReport& report, std::string& error) const {
    const Student* s = findStudent(studentId);
    const int slot = courseSlot(normalizeId(courseCode));
    if (s == nullptr) {
        error = "No student with ID " + normalizeId(studentId) + ".";
        return false;
    }
    if (slot < 0) {
        error = "No course with code " + normalizeId(courseCode) + ".";
        return false;
    }
    report = registration_.checkPrerequisites(*s, slot);
    return true;
}

RegistrationOutcome AcademicManager::registerForCourse(const std::string& studentId, const std::string& courseCode) {
    RegistrationOutcome out;
    const Student* s = findStudent(studentId);                     // 1. hash table
    if (s == nullptr) {
        out.status = RegistrationStatus::StudentNotFound;
        out.message = "No student with ID " + normalizeId(studentId) + ".";
        return out;
    }
    const int slot = courseSlot(normalizeId(courseCode));          // 2. hash table
    if (slot < 0) {
        out.status = RegistrationStatus::CourseNotFound;
        out.message = "No course with code " + normalizeId(courseCode) + ".";
        return out;
    }
    // 3-6. duplicate check, DFS prerequisites, capacity, enrol / waitlist
    return registration_.requestRegistration(*s, *courseAt(slot), slot);
}

std::string AcademicManager::describePromotions(const std::vector<PromotionEvent>& events) const {
    std::string text;
    for (const PromotionEvent& e : events) {
        text += e.promoted ? " Waitlist: " + e.studentId + " promoted to enrolled."
                           : " Waitlist: " + e.studentId + " removed (" + e.reason + ").";
    }
    return text;
}

OpResult AcademicManager::cancelRegistration(const std::string& studentId, const std::string& courseCode) {
    const std::string sid = normalizeId(studentId);
    const std::string code = normalizeId(courseCode);
    const int slot = courseSlot(code);
    Course* c = courseAt(slot);
    if (c == nullptr) return failure("No course with code " + code + ".");
    if (c->isEnrolled(sid)) {
        c->drop(sid);
        // a seat is free now: serve the waiting list in FIFO order
        const std::string promotions = describePromotions(registration_.fillVacancies(*c, slot, studentLookup()));
        return success(sid + " dropped " + code + "." + promotions);
    }
    if (c->isWaitlisted(sid)) {
        c->leaveWaitlist(sid);
        return success(sid + " left the " + code + " waiting list.");
    }
    return failure(sid + " is neither enrolled in nor waitlisted for " + code + ".");
}

OpResult AcademicManager::processWaitlist(const std::string& courseCode) {
    const std::string code = normalizeId(courseCode);
    const int slot = courseSlot(code);
    Course* c = courseAt(slot);
    if (c == nullptr) return failure("No course with code " + code + ".");
    if (c->waitlistSize() == 0) return success("The " + code + " waiting list is empty.");
    if (c->isFull()) return success(code + " has no free seats; the waiting list is unchanged.");
    return success("Processed the " + code + " waiting list." +
                   describePromotions(registration_.fillVacancies(*c, slot, studentLookup())));
}


}  // namespace academic
