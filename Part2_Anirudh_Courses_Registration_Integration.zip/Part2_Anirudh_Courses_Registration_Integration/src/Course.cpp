// Course.cpp
#include "Course.hpp"

#include <stdexcept>
#include <utility>

#include "Validation.hpp"

namespace academic {

Course::Course(std::string code, std::string title, int credits, int capacity)
    : code_(std::move(code)),
      title_(std::move(title)),
      credits_(credits),
      capacity_(capacity),
      roster_(adoptHandle<LinkedListHandle>(ll_create())),
      waitlist_(adoptHandle<QueueHandle>(queue_create())) {
    if (!isValidId(code_)) {
        throw std::invalid_argument("invalid course code '" + code_ + "'");
    }
    if (!isValidText(title_, kMaxNameLength)) {
        throw std::invalid_argument("title must be 1-47 printable characters");
    }
    setCredits(credits);
    if (capacity < kMinCapacity || capacity > kMaxCapacity) {
        throw std::invalid_argument("capacity must be between 1 and 500");
    }
}

bool Course::isEnrolled(const std::string& studentId) const {
    return ll_contains(roster_.get(), studentId.c_str()) != 0;
}

std::vector<std::string> Course::enrolledIds() const {
    std::vector<std::string> ids;
    ids.reserve(enrolledCount());
    for (const LLNode* n = ll_first(roster_.get()); n != nullptr; n = ll_next(n)) {
        ids.emplace_back(ll_node_key(n));
    }
    return ids;
}

bool Course::isWaitlisted(const std::string& studentId) const {
    return queue_contains(waitlist_.get(), studentId.c_str()) != 0;
}

std::size_t Course::waitlistPosition(const std::string& studentId) const {
    return queue_position(waitlist_.get(), studentId.c_str());
}

std::vector<std::string> Course::waitlistIds() const {
    std::vector<std::string> ids;
    ids.reserve(waitlistSize());
    for (const QueueNode* n = queue_front_node(waitlist_.get()); n != nullptr; n = queue_node_next(n)) {
        ids.emplace_back(queue_node_id(n));
    }
    return ids;
}

void Course::setTitle(const std::string& title) {
    if (!isValidText(title, kMaxNameLength)) {
        throw std::invalid_argument("title must be 1-47 printable characters");
    }
    title_ = title;
}

void Course::setCredits(int credits) {
    if (credits < kMinCredits || credits > kMaxCredits) {
        throw std::invalid_argument("credits must be between 1 and 6");
    }
    credits_ = credits;
}

void Course::setCapacity(int capacity) {
    if (capacity < kMinCapacity || capacity > kMaxCapacity) {
        throw std::invalid_argument("capacity must be between 1 and 500");
    }
    if (capacity < static_cast<int>(enrolledCount())) {
        throw std::invalid_argument("capacity cannot be below the " + std::to_string(enrolledCount()) +
                                    " students already enrolled");
    }
    capacity_ = capacity;
}

bool Course::enroll(const std::string& studentId) {
    if (isFull() || isEnrolled(studentId) || isWaitlisted(studentId)) {
        return false;
    }
    return ll_push_back(roster_.get(), studentId.c_str(), 0) == DS_OK;
}

bool Course::drop(const std::string& studentId) {
    return ll_remove(roster_.get(), studentId.c_str()) == DS_OK;
}

bool Course::joinWaitlist(const std::string& studentId) {
    if (isEnrolled(studentId) || isWaitlisted(studentId)) {
        return false;
    }
    return queue_enqueue(waitlist_.get(), studentId.c_str()) == DS_OK;
}

bool Course::leaveWaitlist(const std::string& studentId) {
    return queue_remove(waitlist_.get(), studentId.c_str()) == DS_OK;
}

bool Course::popWaitlistFront(std::string& studentId) {
    char buffer[DS_KEY_LEN];
    if (queue_dequeue(waitlist_.get(), buffer, sizeof buffer) != DS_OK) {
        return false;
    }
    studentId = buffer;
    return true;
}

}  // namespace academic
