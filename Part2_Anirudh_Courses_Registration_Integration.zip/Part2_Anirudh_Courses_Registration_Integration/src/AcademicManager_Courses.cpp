// AcademicManager_Courses.cpp
// Module B - courses and prerequisites.
#include "AcademicManager.hpp"

#include <cmath>
#include <cstdio>
#include <stdexcept>

#include "AcademicManagerInternal.hpp"
#include "Validation.hpp"
#include "ds/searching_sorting.h"

namespace academic {

using detail::success;
using detail::failure;
using detail::twoDecimals;
using detail::copyField;

// ===========================================================================
// Module B - courses and prerequisites
// ===========================================================================
OpResult AcademicManager::addCourse(const std::string& rawCode, const std::string& title, int credits,
                                    int capacity) {
    const std::string code = normalizeId(rawCode);
    if (!isValidId(code)) {
        return failure("Course code must be 2-15 characters (A-Z, 0-9, '-', '_').");
    }
    if (ht_contains(courseIndex_.get(), code.c_str())) {
        return failure("A course with code " + code + " already exists.");
    }
    std::unique_ptr<Course> course;
    try {
        course.reset(new Course(code, trim(title), credits, capacity));
    } catch (const std::invalid_argument& e) {
        return failure(std::string("Invalid course details: ") + e.what() + ".");
    }
    const int slot = static_cast<int>(courses_.size());
    int status = graph_add_vertex(prerequisites_.get(), slot, code.c_str());
    if (status != DS_OK) {
        return failure(std::string("Could not add the course to the prerequisite graph: ") +
                       ds_status_text(status) + ".");
    }
    status = ht_insert(courseIndex_.get(), code.c_str(), slot);
    if (status != DS_OK) {
        graph_remove_vertex(prerequisites_.get(), slot);  // roll back
        return failure(std::string("Could not index the course: ") + ds_status_text(status) + ".");
    }
    courses_.push_back(std::move(course));
    return success("Added course " + code + " (" + courses_.back()->title() + ", " + std::to_string(credits) +
                   " credits, " + std::to_string(capacity) + " seats).");
}

bool AcademicManager::anyResultFor(const std::string& courseCode) const {
    for (const auto& s : students_) {
        if (s && s->findResult(courseCode) != nullptr) return true;
    }
    return false;
}

OpResult AcademicManager::updateCourse(const std::string& rawCode, const std::string& title, int credits,
                                       int capacity) {
    const int slot = courseSlot(normalizeId(rawCode));
    Course* c = courseAt(slot);
    if (c == nullptr) {
        return failure("No course with code " + normalizeId(rawCode) + ".");
    }
    const std::string newTitle = trim(title);
    if (!newTitle.empty() && !isValidText(newTitle, kMaxNameLength)) {
        return failure("Title must be 1-47 printable characters.");
    }
    if (credits != 0) {
        if (credits < kMinCredits || credits > kMaxCredits) {
            return failure("Credits must be between 1 and 6.");
        }
        if (credits != c->credits() && anyResultFor(c->code())) {
            return failure("Credits of " + c->code() + " cannot change: existing results already record " +
                           std::to_string(c->credits()) + " credits.");
        }
    }
    if (capacity != 0) {
        if (capacity < kMinCapacity || capacity > kMaxCapacity) {
            return failure("Capacity must be between 1 and 500.");
        }
        if (capacity < static_cast<int>(c->enrolledCount())) {
            return failure("Capacity cannot be below the " + std::to_string(c->enrolledCount()) +
                           " students already enrolled.");
        }
    }
    if (!newTitle.empty()) c->setTitle(newTitle);
    if (credits != 0) c->setCredits(credits);
    std::string extra;
    if (capacity != 0) {
        c->setCapacity(capacity);
        extra = describePromotions(registration_.fillVacancies(*c, slot, studentLookup()));
    }
    return success("Updated course " + c->code() + "." + extra);
}

OpResult AcademicManager::removeCourse(const std::string& rawCode) {
    const std::string code = normalizeId(rawCode);
    const int slot = courseSlot(code);
    Course* c = courseAt(slot);
    if (c == nullptr) {
        return failure("No course with code " + code + ".");
    }
    if (c->enrolledCount() > 0 || c->waitlistSize() > 0) {
        return failure("Cannot remove " + code + ": it has enrolled or waitlisted students.");
    }
    if (anyResultFor(code)) {
        return failure("Cannot remove " + code + ": students have results recorded for it.");
    }
    const auto dependents = directDependents(code);
    if (!dependents.empty()) {
        std::string list;
        for (const auto& d : dependents) list += " " + d;
        return failure("Cannot remove " + code + ": it is a prerequisite of" + list + ".");
    }
    graph_remove_vertex(prerequisites_.get(), slot);  // also frees its own prerequisite edges
    ht_remove(courseIndex_.get(), code.c_str());
    courses_[static_cast<std::size_t>(slot)].reset();
    return success("Removed course " + code + ".");
}

std::vector<const Course*> AcademicManager::courses() const {
    std::vector<const Course*> out;
    for (const auto& c : courses_) {
        if (c) out.push_back(c.get());
    }
    return out;
}

std::vector<const Course*> AcademicManager::sortedCourses(CourseSortKey key) const {
    std::vector<const Course*> all = courses();
    std::vector<SortRecord> records(all.size());
    for (std::size_t i = 0; i < all.size(); ++i) {
        copyField(records[i].key, DS_KEY_LEN, all[i]->code());
        copyField(records[i].name, DS_NAME_LEN, all[i]->title());
        records[i].score = static_cast<int>(all[i]->enrolledCount());
    }
    int order = SORT_BY_KEY;
    if (key == CourseSortKey::Title) order = SORT_BY_NAME;
    if (key == CourseSortKey::EnrolledHighFirst) order = SORT_BY_SCORE_DESC;
    if (ss_merge_sort(records.data(), records.size(), order) != DS_OK) {
        return all;
    }
    std::vector<const Course*> out;
    for (const SortRecord& r : records) {
        out.push_back(findCourse(r.key));
    }
    return out;
}

OpResult AcademicManager::addPrerequisite(const std::string& rawCourse, const std::string& rawPrereq) {
    const std::string course = normalizeId(rawCourse);
    const std::string prereq = normalizeId(rawPrereq);
    const int c = courseSlot(course);
    const int p = courseSlot(prereq);
    if (c < 0) return failure("Unknown course " + course + ".");
    if (p < 0) return failure("Unknown prerequisite course " + prereq + ".");
    const int status = graph_add_edge(prerequisites_.get(), c, p);
    switch (status) {
    case DS_OK:
        return success(course + " now requires " + prereq + ".");
    case DS_ERR_SELF_LOOP:
        return failure("A course cannot be its own prerequisite.");
    case DS_ERR_DUPLICATE:
        return failure(course + " already requires " + prereq + ".");
    case DS_ERR_CYCLE:
        return failure("Rejected: " + prereq + " already depends on " + course +
                       ", so this would create a prerequisite cycle.");
    default:
        return failure(std::string("Could not add the prerequisite: ") + ds_status_text(status) + ".");
    }
}

OpResult AcademicManager::removePrerequisite(const std::string& rawCourse, const std::string& rawPrereq) {
    const std::string course = normalizeId(rawCourse);
    const std::string prereq = normalizeId(rawPrereq);
    const int c = courseSlot(course);
    const int p = courseSlot(prereq);
    if (c < 0 || p < 0) return failure("Unknown course code.");
    if (graph_remove_edge(prerequisites_.get(), c, p) != DS_OK) {
        return failure(course + " does not require " + prereq + ".");
    }
    return success(course + " no longer requires " + prereq + ".");
}

std::vector<std::string> AcademicManager::directPrerequisites(const std::string& code) const {
    std::vector<std::string> out;
    const int slot = courseSlot(normalizeId(code));
    if (slot < 0) return out;
    std::vector<int> ids(graph_capacity(prerequisites_.get()));
    const std::size_t n = graph_direct_prereqs(prerequisites_.get(), slot, ids.data(), ids.size());
    for (std::size_t i = 0; i < n; ++i) out.emplace_back(graph_vertex_label(prerequisites_.get(), ids[i]));
    return out;
}

std::vector<std::string> AcademicManager::allPrerequisites(const std::string& code) const {
    std::vector<std::string> out;
    const int slot = courseSlot(normalizeId(code));
    if (slot < 0) return out;
    std::vector<int> ids(graph_capacity(prerequisites_.get()));
    const std::size_t n = graph_all_prereqs(prerequisites_.get(), slot, ids.data(), ids.size());
    for (std::size_t i = 0; i < n; ++i) out.emplace_back(graph_vertex_label(prerequisites_.get(), ids[i]));
    return out;
}

std::vector<std::string> AcademicManager::directDependents(const std::string& code) const {
    std::vector<std::string> out;
    const int slot = courseSlot(normalizeId(code));
    if (slot < 0) return out;
    std::vector<int> ids(graph_capacity(prerequisites_.get()));
    const std::size_t n = graph_direct_dependents(prerequisites_.get(), slot, ids.data(), ids.size());
    for (std::size_t i = 0; i < n; ++i) out.emplace_back(graph_vertex_label(prerequisites_.get(), ids[i]));
    return out;
}

std::vector<std::string> AcademicManager::studyOrder() const {
    std::vector<std::string> out;
    std::vector<int> ids(graph_capacity(prerequisites_.get()));
    const std::size_t n = graph_topological_order(prerequisites_.get(), ids.data(), ids.size());
    for (std::size_t i = 0; i < n; ++i) out.emplace_back(graph_vertex_label(prerequisites_.get(), ids[i]));
    return out;
}


}  // namespace academic
