// ConsoleIO.cpp
#include "ConsoleIO.hpp"

#include <cerrno>
#include <cstdlib>
#include <iostream>

#ifdef _WIN32
#include <io.h>
#define SARCRS_ISATTY(fd) _isatty(fd)
#else
#include <unistd.h>
#define SARCRS_ISATTY(fd) isatty(fd)
#endif

#include "Validation.hpp"

namespace io {

namespace {
bool g_echo = false;
}

void setEchoInput(bool echo) { g_echo = echo; }

bool stdinIsTerminal() { return SARCRS_ISATTY(0) != 0; }

std::string readLine(const std::string& prompt) {
    std::cout << prompt << std::flush;
    std::string line;
    if (!std::getline(std::cin, line)) {
        throw InputClosed();
    }
    if (!line.empty() && line.back() == '\r') {
        line.pop_back();  // tolerate Windows line endings in piped scripts
    }
    if (g_echo) {
        std::cout << line << '\n';
    }
    return line;
}

std::string readRequired(const std::string& prompt) {
    for (;;) {
        std::string value = academic::trim(readLine(prompt));
        if (!value.empty()) {
            return value;
        }
        std::cout << "  A value is required.\n";
    }
}

namespace {

bool parseInt(const std::string& text, long& value) {
    const std::string t = academic::trim(text);
    if (t.empty()) return false;
    char* end = nullptr;
    errno = 0;
    value = std::strtol(t.c_str(), &end, 10);
    return errno == 0 && end != nullptr && *end == '\0';
}

}  // namespace

int readInt(const std::string& prompt, int min, int max) {
    for (;;) {
        long value = 0;
        if (parseInt(readLine(prompt), value) && value >= min && value <= max) {
            return static_cast<int>(value);
        }
        std::cout << "  Please enter a whole number from " << min << " to " << max << ".\n";
    }
}

int readOptionalInt(const std::string& prompt, int min, int max) {
    for (;;) {
        const std::string line = academic::trim(readLine(prompt));
        if (line.empty()) {
            return 0;
        }
        long value = 0;
        if (parseInt(line, value) && value >= min && value <= max) {
            return static_cast<int>(value);
        }
        std::cout << "  Enter a number from " << min << " to " << max << ", or leave blank to keep.\n";
    }
}

double readDouble(const std::string& prompt, double min, double max) {
    for (;;) {
        const std::string t = academic::trim(readLine(prompt));
        char* end = nullptr;
        errno = 0;
        const double value = std::strtod(t.c_str(), &end);
        if (!t.empty() && errno == 0 && end != nullptr && *end == '\0' && value >= min && value <= max) {
            return value;
        }
        std::cout << "  Please enter a number from " << min << " to " << max << ".\n";
    }
}

bool readYesNo(const std::string& prompt) {
    for (;;) {
        const std::string t = academic::toUpper(academic::trim(readLine(prompt + " (y/n): ")));
        if (t == "Y" || t == "YES") return true;
        if (t == "N" || t == "NO") return false;
        std::cout << "  Please answer y or n.\n";
    }
}

void printRule(char c, int width) {
    std::cout << std::string(static_cast<std::size_t>(width), c) << '\n';
}

void printTitle(const std::string& title) {
    std::cout << '\n';
    printRule('=');
    std::cout << ' ' << title << '\n';
    printRule('=');
}

}  // namespace io
