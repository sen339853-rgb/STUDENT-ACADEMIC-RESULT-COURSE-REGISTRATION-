# Student Academic Result & Course Registration System
### A Hybrid C/C++ Architecture — PBL Project, Team Code Rushers (DSCPP-III-2026-T251)

Graphic Era (Deemed to be University), Dehradun · B.Tech CSE, 3rd semester ·
Data Structures in C + Object-Oriented Programming in C++

A menu-driven command-line application for managing student records, courses,
examination results and course registration. Pure **C** modules implement the data
structures and algorithms. **C++** classes model the academic domain. The two layers
meet at an `extern "C"` boundary. All data is stored in a local, versioned, checksummed
binary `.dat` file, with no database server.

---

## 1. What it does

| Module | Features |
|---|---|
| **A. Student records** | add / view / update / delete, search by ID (hash table) and by name, sort by ID / name / CGPA (merge sort), UG vs PG students |
| **B. Courses** | add / view / update / remove, seat capacity and availability, prerequisites (DAG with cycle rejection), recommended study order |
| **C. Results** | enter / update marks, UG vs PG grading (runtime polymorphism), CGPA, pass/fail, AVL-tree ranking, undo last marks entry (stack) |
| **D. Registration** | hash lookup → duplicate check → DFS prerequisite check → capacity → enrol **or** FIFO waitlist; cancellation promotes the waitlist |
| **Persistence** | one binary file with magic number, version and CRC-32; atomic save; validated, all-or-nothing load |
| **Analytics** | live hash/AVL/graph statistics, linear vs binary vs hash search comparison, measured benchmark |

Three role menus (Student, Administrator, Academic Staff) plus a DSA demonstration menu.
Picking a role is **not** authentication. This prototype has no logins.

## 2. Build and run

Requirements: GCC/G++ with C11 and C++17 support, and GNU make. Tested on Windows 11 with
MinGW GCC 6.3.0 (`mingw32-make`). The Makefile also has a POSIX branch for Linux/macOS/MSYS2,
which has **not** been tested on those systems.

```bash
make            # Linux/macOS/MSYS2   (Windows cmd/PowerShell: mingw32-make)
make run        # start the CLI
make test       # run the 3 test suites
make memcheck   # malloc/free balance check (GNU ld)
make demo       # replay the scripted 20-step demonstration, then restart and reload
make release    # standalone dist/academic_system.exe that runs on PCs without MinGW
make clean
```

The application stores its data in `data/academic_records.dat`. Use another folder with:

```bash
build/academic_system --data-dir my_data
```

For a quick demo on an empty system: **Administrator Portal → 5. Load Sample Dataset**.
It adds fictional students and courses.

Manual compilation (shows the C/C++ split explicitly):

```bash
gcc -std=c11 -Wall -Wextra -Wpedantic -Iinclude -c src/ds/*.c        # C compiled as C
g++ -std=c++17 -Wall -Wextra -Wpedantic -Iinclude -c src/*.cpp       # C++ compiled as C++
g++ *.o -o academic_system                                           # one executable
```

## 3. Project layout

```
include/ds/*.h        C headers (extern "C" guarded, C11-compatible)
src/ds/*.c            C data structures: linked list, hash table, AVL BST, graph, queue, stack, search/sort
include/*.hpp         C++ headers
src/*.cpp             C++ classes: Student hierarchy, Course, Result, RegistrationManager,
                      AcademicManager (facade), FileManager, Benchmark, ConsoleIO, DemoData, main
tests/                test_data_structures, test_academic_workflow, test_persistence, test_memory
examples/             sample_workflow.txt + after_restart.txt (scripted demo input)
docs/                 architecture, concept mapping, algorithms, testing, viva guide
```

## 4. Documentation

- [docs/architecture.md](docs/architecture.md): layers, `extern "C"`, ownership, data flow, team allocation
- [docs/concept_mapping.md](docs/concept_mapping.md): every DSA and OOP concept → file, function, CLI option, complexity
- [docs/algorithms.md](docs/algorithms.md): search, sort, ranking, DFS, registration, waitlist, undo, save/load
- [docs/testing.md](docs/testing.md): test table with observed results, demo procedure, memory checking
- [docs/viva_guide.md](docs/viva_guide.md): viva questions answered with reference to this code

## 5. Assumptions (not given in the PDFs)

1. **Grading rules are demonstration defaults**, not Graphic Era University's official scheme
   (10-point scale; UG pass mark 40, PG pass mark 50; see `src/Student.cpp`).
2. A prerequisite is satisfied only by a **passed** result. Registering for a course is not enough.
3. CGPA is the credit-weighted mean of grade points over all recorded results, failures included.
4. A student with active registrations cannot be deleted. Cancel them first, so that seats are released
   through the normal path and the waitlist is served.
5. A course cannot be removed while it has students, results, or courses that depend on it.
6. Undo history covers the current session only. It is not saved to disk.
7. IDs are 2–15 characters (A–Z, 0–9, `-`, `_`) and are converted to upper case.

## 6. Limitations

- Single-user CLI prototype: no authentication, no concurrent access, no network.
- Performance numbers come from the built-in benchmark on the machine that runs it. No comparison
  with real university ERP systems has been made.
- AddressSanitizer/Valgrind targets are provided but could not be run on the Windows/MinGW
  development machine. `make memcheck` was used there instead (see docs/testing.md).

## 7. Academic integrity

This code was produced with AI assistance. Follow your course's policy on declaring AI use,
and make sure every team member can explain and modify their assigned module (docs/viva_guide.md).
