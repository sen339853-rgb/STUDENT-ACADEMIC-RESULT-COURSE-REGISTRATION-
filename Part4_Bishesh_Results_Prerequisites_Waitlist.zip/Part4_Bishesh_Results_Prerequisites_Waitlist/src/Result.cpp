// Result.cpp
#include "Result.hpp"

#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <utility>

namespace academic {

Result::Result(std::string courseCode, int centiMarks, int credits)
    : courseCode_(std::move(courseCode)), centiMarks_(centiMarks), credits_(credits) {
    if (!isValidCentiMarks(centiMarks)) {
        throw std::invalid_argument("marks must be between 0 and 100");
    }
    if (credits <= 0) {
        throw std::invalid_argument("credits must be positive");
    }
}

void Result::setCentiMarks(int centiMarks) {
    if (!isValidCentiMarks(centiMarks)) {
        throw std::invalid_argument("marks must be between 0 and 100");
    }
    centiMarks_ = centiMarks;
}

bool Result::isValidCentiMarks(int centiMarks) {
    return centiMarks >= 0 && centiMarks <= kMaxCentiMarks;
}

int Result::toCenti(double marks) {
    return static_cast<int>(std::lround(marks * 100.0));
}

std::string Result::formatMarks(int centiMarks) {
    char buffer[16];
    std::snprintf(buffer, sizeof buffer, "%d.%02d", centiMarks / 100, centiMarks % 100);
    return buffer;
}

}  // namespace academic
