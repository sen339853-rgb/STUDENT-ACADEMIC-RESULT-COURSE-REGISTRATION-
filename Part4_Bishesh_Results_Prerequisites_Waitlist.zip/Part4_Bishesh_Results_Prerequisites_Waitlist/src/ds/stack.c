/*
 * stack.c
 * Linked LIFO stack of MarksChange records (see stack.h).
 */
#include "ds/stack.h"

#include <stdlib.h>

typedef struct StackNode {
    MarksChange data;
    struct StackNode *next; /* the element below this one */
} StackNode;

struct Stack {
    StackNode *top;
    size_t size;
};

Stack *stack_create(void)
{
    Stack *s = (Stack *)malloc(sizeof(Stack));
    if (s == NULL) {
        return NULL;
    }
    s->top = NULL;
    s->size = 0;
    return s;
}

void stack_clear(Stack *s)
{
    StackNode *cur;
    if (s == NULL) {
        return;
    }
    cur = s->top;
    while (cur != NULL) {
        StackNode *below = cur->next;
        free(cur);
        cur = below;
    }
    s->top = NULL;
    s->size = 0;
}

void stack_destroy(Stack *s)
{
    if (s == NULL) {
        return;
    }
    stack_clear(s);
    free(s);
}

int stack_push(Stack *s, const MarksChange *change)
{
    StackNode *node;
    if (s == NULL || change == NULL) {
        return DS_ERR_INVALID;
    }
    node = (StackNode *)malloc(sizeof(StackNode));
    if (node == NULL) {
        return DS_ERR_ALLOC;
    }
    node->data = *change;   /* struct copy: the stack owns its own data */
    node->next = s->top;
    s->top = node;
    s->size++;
    return DS_OK;
}

int stack_pop(Stack *s, MarksChange *out)
{
    StackNode *old;
    if (s == NULL) {
        return DS_ERR_INVALID;
    }
    if (s->top == NULL) {
        return DS_ERR_EMPTY;
    }
    old = s->top;
    if (out != NULL) {
        *out = old->data;
    }
    s->top = old->next;
    free(old);
    s->size--;
    return DS_OK;
}

int stack_peek(const Stack *s, MarksChange *out)
{
    if (s == NULL) {
        return DS_ERR_INVALID;
    }
    if (s->top == NULL) {
        return DS_ERR_EMPTY;
    }
    if (out != NULL) {
        *out = s->top->data;
    }
    return DS_OK;
}

int stack_is_empty(const Stack *s)
{
    return s == NULL || s->top == NULL;
}

size_t stack_size(const Stack *s)
{
    return s == NULL ? 0 : s->size;
}
