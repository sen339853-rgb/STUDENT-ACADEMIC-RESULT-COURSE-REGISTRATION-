/*
 * graph.c
 * Adjacency-list DAG with DFS-based prerequisite validation (see graph.h).
 */
#include "ds/graph.h"

#include <stdlib.h>
#include <string.h>

#define GRAPH_DEFAULT_CAPACITY 16

typedef struct AdjNode {
    int to;                 /* the prerequisite vertex */
    struct AdjNode *next;
} AdjNode;

typedef struct Vertex {
    int active;             /* 0 = unused slot */
    char label[DS_KEY_LEN];
    AdjNode *head;          /* outgoing edges: this course requires ... */
} Vertex;

struct Graph {
    Vertex *vertices;       /* indexed by vertex id */
    size_t capacity;
    size_t vertex_count;
    size_t edge_count;
};

enum { WHITE = 0, GREY = 1, BLACK = 2 };

static int valid_vertex(const Graph *g, int id)
{
    return g != NULL && id >= 0 && (size_t)id < g->capacity && g->vertices[id].active;
}

Graph *graph_create(size_t initial_capacity)
{
    Graph *g = (Graph *)malloc(sizeof(Graph));
    if (g == NULL) {
        return NULL;
    }
    g->capacity = initial_capacity == 0 ? GRAPH_DEFAULT_CAPACITY : initial_capacity;
    g->vertices = (Vertex *)calloc(g->capacity, sizeof(Vertex));
    if (g->vertices == NULL) {
        free(g);
        return NULL;
    }
    g->vertex_count = 0;
    g->edge_count = 0;
    return g;
}

static void free_edges(Vertex *v)
{
    AdjNode *cur = v->head;
    while (cur != NULL) {
        AdjNode *next = cur->next;
        free(cur);
        cur = next;
    }
    v->head = NULL;
}

void graph_destroy(Graph *g)
{
    size_t i;
    if (g == NULL) {
        return;
    }
    for (i = 0; i < g->capacity; ++i) {
        free_edges(&g->vertices[i]);
    }
    free(g->vertices);
    free(g);
}

static int ensure_capacity(Graph *g, size_t needed)
{
    size_t new_cap;
    Vertex *grown;
    if (needed <= g->capacity) {
        return DS_OK;
    }
    new_cap = g->capacity * 2;
    if (new_cap < needed) {
        new_cap = needed;
    }
    grown = (Vertex *)realloc(g->vertices, new_cap * sizeof(Vertex));
    if (grown == NULL) {
        return DS_ERR_ALLOC; /* old array is still valid */
    }
    memset(grown + g->capacity, 0, (new_cap - g->capacity) * sizeof(Vertex));
    g->vertices = grown;
    g->capacity = new_cap;
    return DS_OK;
}

int graph_add_vertex(Graph *g, int id, const char *label)
{
    int status;
    if (g == NULL || id < 0 || label == NULL) {
        return DS_ERR_INVALID;
    }
    status = ensure_capacity(g, (size_t)id + 1);
    if (status != DS_OK) {
        return status;
    }
    if (g->vertices[id].active) {
        return DS_ERR_DUPLICATE;
    }
    if (ds_copy_key(g->vertices[id].label, label, sizeof(g->vertices[id].label)) != DS_OK) {
        return DS_ERR_INVALID;
    }
    g->vertices[id].active = 1;
    g->vertices[id].head = NULL;
    g->vertex_count++;
    return DS_OK;
}

int graph_remove_vertex(Graph *g, int id)
{
    size_t i;
    AdjNode *cur;
    if (!valid_vertex(g, id)) {
        return DS_ERR_NOT_FOUND;
    }
    /* drop outgoing edges */
    for (cur = g->vertices[id].head; cur != NULL; cur = cur->next) {
        g->edge_count--;
    }
    free_edges(&g->vertices[id]);
    /* drop incoming edges (other courses that required this one) */
    for (i = 0; i < g->capacity; ++i) {
        if (g->vertices[i].active) {
            (void)graph_remove_edge(g, (int)i, id);
        }
    }
    g->vertices[id].active = 0;
    g->vertices[id].label[0] = '\0';
    g->vertex_count--;
    return DS_OK;
}

int graph_has_vertex(const Graph *g, int id)
{
    return valid_vertex(g, id);
}

const char *graph_vertex_label(const Graph *g, int id)
{
    return valid_vertex(g, id) ? g->vertices[id].label : NULL;
}

size_t graph_vertex_count(const Graph *g) { return g == NULL ? 0 : g->vertex_count; }
size_t graph_edge_count(const Graph *g) { return g == NULL ? 0 : g->edge_count; }
size_t graph_capacity(const Graph *g) { return g == NULL ? 0 : g->capacity; }

int graph_has_edge(const Graph *g, int course, int prereq)
{
    const AdjNode *cur;
    if (!valid_vertex(g, course)) {
        return 0;
    }
    for (cur = g->vertices[course].head; cur != NULL; cur = cur->next) {
        if (cur->to == prereq) {
            return 1;
        }
    }
    return 0;
}

/* Recursive DFS used by reachability: marks visited[] and stops early. */
static int dfs_reach(const Graph *g, int v, int target, unsigned char *visited)
{
    const AdjNode *cur;
    if (v == target) {
        return 1;
    }
    visited[v] = 1;
    for (cur = g->vertices[v].head; cur != NULL; cur = cur->next) {
        if (!visited[cur->to] && dfs_reach(g, cur->to, target, visited)) {
            return 1;
        }
    }
    return 0;
}

int graph_is_reachable(const Graph *g, int from, int to)
{
    unsigned char *visited;
    int found;
    if (!valid_vertex(g, from) || !valid_vertex(g, to)) {
        return 0;
    }
    visited = (unsigned char *)calloc(g->capacity, 1);
    if (visited == NULL) {
        return 0;
    }
    found = dfs_reach(g, from, to, visited);
    free(visited);
    return found;
}

int graph_add_edge(Graph *g, int course, int prereq)
{
    AdjNode *node;
    AdjNode **tail;
    if (g == NULL) {
        return DS_ERR_INVALID;
    }
    if (!valid_vertex(g, course) || !valid_vertex(g, prereq)) {
        return DS_ERR_NOT_FOUND;
    }
    if (course == prereq) {
        return DS_ERR_SELF_LOOP;
    }
    if (graph_has_edge(g, course, prereq)) {
        return DS_ERR_DUPLICATE;
    }
    /* course -> prereq closes a cycle exactly when prereq can already reach
     * course (prereq requires ... requires course). */
    if (graph_is_reachable(g, prereq, course)) {
        return DS_ERR_CYCLE;
    }
    node = (AdjNode *)malloc(sizeof(AdjNode));
    if (node == NULL) {
        return DS_ERR_ALLOC;
    }
    node->to = prereq;
    node->next = NULL;
    /* append so prerequisites are listed in the order they were defined */
    tail = &g->vertices[course].head;
    while (*tail != NULL) {
        tail = &(*tail)->next;
    }
    *tail = node;
    g->edge_count++;
    return DS_OK;
}

int graph_remove_edge(Graph *g, int course, int prereq)
{
    AdjNode **link;
    if (!valid_vertex(g, course)) {
        return DS_ERR_NOT_FOUND;
    }
    for (link = &g->vertices[course].head; *link != NULL; link = &(*link)->next) {
        if ((*link)->to == prereq) {
            AdjNode *victim = *link;
            *link = victim->next;
            free(victim);
            g->edge_count--;
            return DS_OK;
        }
    }
    return DS_ERR_NOT_FOUND;
}

size_t graph_direct_prereqs(const Graph *g, int course, int *out, size_t max)
{
    size_t count = 0;
    const AdjNode *cur;
    if (!valid_vertex(g, course) || out == NULL) {
        return 0;
    }
    for (cur = g->vertices[course].head; cur != NULL && count < max; cur = cur->next) {
        out[count++] = cur->to;
    }
    return count;
}

size_t graph_direct_dependents(const Graph *g, int prereq, int *out, size_t max)
{
    size_t i;
    size_t count = 0;
    if (!valid_vertex(g, prereq) || out == NULL) {
        return 0;
    }
    for (i = 0; i < g->capacity && count < max; ++i) {
        if (g->vertices[i].active && graph_has_edge(g, (int)i, prereq)) {
            out[count++] = (int)i;
        }
    }
    return count;
}

/* DFS that appends each vertex AFTER all of its prerequisites (post-order). */
static void dfs_postorder(const Graph *g, int v, unsigned char *visited,
                          int *out, size_t max, size_t *count)
{
    const AdjNode *cur;
    visited[v] = 1;
    for (cur = g->vertices[v].head; cur != NULL; cur = cur->next) {
        if (!visited[cur->to]) {
            dfs_postorder(g, cur->to, visited, out, max, count);
        }
    }
    if (*count < max) {
        out[(*count)++] = v;
    }
}

size_t graph_all_prereqs(const Graph *g, int course, int *out, size_t max)
{
    unsigned char *visited;
    int *order;
    size_t total = 0;
    size_t i;
    size_t written = 0;
    if (!valid_vertex(g, course) || out == NULL) {
        return 0;
    }
    visited = (unsigned char *)calloc(g->capacity, 1);
    order = (int *)malloc(g->capacity * sizeof(int));
    if (visited == NULL || order == NULL) {
        free(visited);
        free(order);
        return 0;
    }
    dfs_postorder(g, course, visited, order, g->capacity, &total);
    /* the last vertex in post-order is the course itself: skip it */
    for (i = 0; i + 1 < total && written < max; ++i) {
        out[written++] = order[i];
    }
    free(visited);
    free(order);
    return written;
}

int graph_check_prereqs(const Graph *g, int course,
                        const unsigned char *passed, size_t passed_len,
                        int *missing, size_t max_missing, size_t *missing_count)
{
    int *chain;
    size_t n;
    size_t i;
    if (missing_count == NULL) {
        return DS_ERR_INVALID;
    }
    *missing_count = 0;
    if (!valid_vertex(g, course)) {
        return DS_ERR_NOT_FOUND;
    }
    chain = (int *)malloc(g->capacity * sizeof(int));
    if (chain == NULL) {
        return DS_ERR_ALLOC;
    }
    n = graph_all_prereqs(g, course, chain, g->capacity);
    for (i = 0; i < n; ++i) {
        int v = chain[i];
        int ok = passed != NULL && (size_t)v < passed_len && passed[v] != 0;
        if (!ok) {
            if (missing != NULL && *missing_count < max_missing) {
                missing[*missing_count] = v;
            }
            (*missing_count)++;
        }
    }
    free(chain);
    return DS_OK;
}

static int dfs_cycle(const Graph *g, int v, unsigned char *color)
{
    const AdjNode *cur;
    color[v] = GREY; /* on the current DFS path */
    for (cur = g->vertices[v].head; cur != NULL; cur = cur->next) {
        if (color[cur->to] == GREY) {
            return 1; /* back edge -> cycle */
        }
        if (color[cur->to] == WHITE && dfs_cycle(g, cur->to, color)) {
            return 1;
        }
    }
    color[v] = BLACK; /* fully explored */
    return 0;
}

int graph_has_cycle(const Graph *g)
{
    unsigned char *color;
    size_t i;
    int found = 0;
    if (g == NULL) {
        return 0;
    }
    color = (unsigned char *)calloc(g->capacity, 1);
    if (color == NULL) {
        return 0;
    }
    for (i = 0; i < g->capacity && !found; ++i) {
        if (g->vertices[i].active && color[i] == WHITE) {
            found = dfs_cycle(g, (int)i, color);
        }
    }
    free(color);
    return found;
}

size_t graph_topological_order(const Graph *g, int *out, size_t max)
{
    unsigned char *visited;
    size_t count = 0;
    size_t i;
    if (g == NULL || out == NULL || graph_has_cycle(g)) {
        return 0;
    }
    visited = (unsigned char *)calloc(g->capacity, 1);
    if (visited == NULL) {
        return 0;
    }
    /* Edges point at prerequisites, so plain DFS post-order already lists
     * every prerequisite before the courses that depend on it. */
    for (i = 0; i < g->capacity; ++i) {
        if (g->vertices[i].active && !visited[i]) {
            dfs_postorder(g, (int)i, visited, out, max, &count);
        }
    }
    free(visited);
    return count;
}
