/*
 * queue.c
 * Linked FIFO queue with front/rear pointers (see queue.h).
 */
#include "ds/queue.h"

#include <stdlib.h>
#include <string.h>

struct QueueNode {
    char id[DS_KEY_LEN];
    struct QueueNode *next;
};

struct Queue {
    QueueNode *front; /* next to be served  */
    QueueNode *rear;  /* most recent arrival */
    size_t size;
};

Queue *queue_create(void)
{
    Queue *q = (Queue *)malloc(sizeof(Queue));
    if (q == NULL) {
        return NULL;
    }
    q->front = NULL;
    q->rear = NULL;
    q->size = 0;
    return q;
}

void queue_clear(Queue *q)
{
    QueueNode *cur;
    if (q == NULL) {
        return;
    }
    cur = q->front;
    while (cur != NULL) {
        QueueNode *next = cur->next;
        free(cur);
        cur = next;
    }
    q->front = NULL;
    q->rear = NULL;
    q->size = 0;
}

void queue_destroy(Queue *q)
{
    if (q == NULL) {
        return;
    }
    queue_clear(q);
    free(q);
}

int queue_enqueue(Queue *q, const char *id)
{
    QueueNode *node;
    if (q == NULL || id == NULL) {
        return DS_ERR_INVALID;
    }
    node = (QueueNode *)malloc(sizeof(QueueNode));
    if (node == NULL) {
        return DS_ERR_ALLOC;
    }
    if (ds_copy_key(node->id, id, sizeof(node->id)) != DS_OK) {
        free(node);
        return DS_ERR_INVALID;
    }
    node->next = NULL;
    if (q->rear == NULL) {      /* empty queue: node is both ends */
        q->front = node;
    } else {
        q->rear->next = node;
    }
    q->rear = node;
    q->size++;
    return DS_OK;
}

static int copy_out(const QueueNode *node, char *out, size_t out_size)
{
    if (out == NULL) {
        return DS_OK;
    }
    return ds_copy_key(out, node->id, (unsigned long)out_size);
}

int queue_dequeue(Queue *q, char *out, size_t out_size)
{
    QueueNode *old;
    int status;
    if (q == NULL) {
        return DS_ERR_INVALID;
    }
    if (q->front == NULL) {
        return DS_ERR_EMPTY;
    }
    old = q->front;
    status = copy_out(old, out, out_size);
    if (status != DS_OK) {
        return status; /* caller's buffer too small: queue unchanged */
    }
    q->front = old->next;
    if (q->front == NULL) {
        q->rear = NULL;
    }
    free(old);
    q->size--;
    return DS_OK;
}

int queue_peek(const Queue *q, char *out, size_t out_size)
{
    if (q == NULL) {
        return DS_ERR_INVALID;
    }
    if (q->front == NULL) {
        return DS_ERR_EMPTY;
    }
    return copy_out(q->front, out, out_size);
}

int queue_is_empty(const Queue *q)
{
    return q == NULL || q->front == NULL;
}

size_t queue_size(const Queue *q)
{
    return q == NULL ? 0 : q->size;
}

size_t queue_position(const Queue *q, const char *id)
{
    const QueueNode *cur;
    size_t pos = 1;
    if (q == NULL || id == NULL) {
        return 0;
    }
    for (cur = q->front; cur != NULL; cur = cur->next, ++pos) {
        if (strcmp(cur->id, id) == 0) {
            return pos;
        }
    }
    return 0;
}

int queue_contains(const Queue *q, const char *id)
{
    return queue_position(q, id) != 0;
}

int queue_remove(Queue *q, const char *id)
{
    QueueNode *prev = NULL;
    QueueNode *cur;
    if (q == NULL || id == NULL) {
        return DS_ERR_INVALID;
    }
    for (cur = q->front; cur != NULL; prev = cur, cur = cur->next) {
        if (strcmp(cur->id, id) == 0) {
            if (prev == NULL) {
                q->front = cur->next;
            } else {
                prev->next = cur->next;
            }
            if (q->rear == cur) {
                q->rear = prev;
            }
            free(cur);
            q->size--;
            return DS_OK;
        }
    }
    return DS_ERR_NOT_FOUND;
}

const QueueNode *queue_front_node(const Queue *q)
{
    return q == NULL ? NULL : q->front;
}

const QueueNode *queue_node_next(const QueueNode *node)
{
    return node == NULL ? NULL : node->next;
}

const char *queue_node_id(const QueueNode *node)
{
    return node == NULL ? NULL : node->id;
}
