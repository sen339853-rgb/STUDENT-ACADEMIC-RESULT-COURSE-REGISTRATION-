// AcademicManager_Results.cpp
// Module C - results, AVL ranking and undo stack.
#include "AcademicManager.hpp"

#include <cmath>
#include <cstdio>
#include <stdexcept>

#include "AcademicManagerInternal.hpp"
#include "Validation.hpp"
#include "ds/searching_sorting.h"

namespace academic {

using detail::success;
using detail::failure;
using detail::twoDecimals;
using detail::copyField;

// ===========================================================================
// Module C - results, ranking (AVL) and undo (stack)
// ===========================================================================
int AcademicManager::rankingScore(const Student& student) {
    return static_cast<int>(std::lround(student.cgpa() * 100.0));
}

void AcademicManager::removeFromRanking(const Student& student) {
    if (student.hasResults()) {
        avl_remove(ranking_.get(), rankingScore(student), student.id().c_str());
    }
}

void AcademicManager::addToRanking(const Student& student) {
    if (student.hasResults()) {
        avl_insert(ranking_.get(), rankingScore(student), student.id().c_str());
    }
}

// Which current enrolment would lose its prerequisite basis if this student
// stopped having passed courseCode? Returns that course's code, or "".
std::string AcademicManager::enrolledCourseRequiring(const Student& student, const std::string& courseCode) const {
    for (const auto& c : courses_) {
        if (!c || !c->isEnrolled(student.id())) continue;
        for (const std::string& code : allPrerequisites(c->code())) {
            if (code == courseCode) return c->code();
        }
    }
    return "";
}

OpResult AcademicManager::recordMarks(const std::string& rawStudent, const std::string& rawCourse, double marks) {
    const std::string sid = normalizeId(rawStudent);
    const std::string code = normalizeId(rawCourse);
    Student* s = studentAt(studentSlot(sid));
    const Course* c = courseAt(courseSlot(code));
    if (s == nullptr) return failure("No student with ID " + sid + ".");
    if (c == nullptr) return failure("No course with code " + code + ".");
    if (!(marks >= 0.0 && marks <= 100.0)) {  // also rejects NaN
        return failure("Marks must be between 0 and 100.");
    }
    const int centi = Result::toCenti(marks);
    const Result* existing = s->findResult(code);
    if (existing != nullptr && existing->centiMarks() == centi) {
        return success("Marks unchanged (" + Result::formatMarks(centi) + ").");
    }

    // Safety rule: a pass -> fail change must not leave the student enrolled in
    // a course whose prerequisite they would no longer satisfy.
    const bool wasPassed = existing != nullptr && s->evaluate(existing->centiMarks()).passed;
    const bool willPass = s->evaluate(centi).passed;
    if (wasPassed && !willPass) {
        const std::string blocker = enrolledCourseRequiring(*s, code);
        if (!blocker.empty()) {
            return failure("Rejected: " + sid + " is enrolled in " + blocker + ", which requires a pass in " + code +
                           ". Cancel that registration first.");
        }
    }

    // Remember the previous state BEFORE changing anything (push is O(1)).
    MarksChange change{};
    copyField(change.student_id, DS_KEY_LEN, sid);
    copyField(change.course_code, DS_KEY_LEN, code);
    change.action = existing == nullptr ? MARKS_ENTERED : MARKS_UPDATED;
    change.previous_centi = existing == nullptr ? 0 : existing->centiMarks();
    change.previous_credits = existing == nullptr ? 0 : existing->credits();
    change.new_centi = centi;
    if (stack_push(undo_.get(), &change) != DS_OK) {
        return failure("Out of memory while saving undo history; marks not changed.");
    }

    const double oldCgpa = s->cgpa();
    const bool hadResults = s->hasResults();
    removeFromRanking(*s);                     // old (score, id) key leaves the AVL tree
    s->upsertResult(code, centi, c->credits());
    addToRanking(*s);                          // new key goes in; tree rebalances

    const GradeInfo g = s->evaluate(centi);    // virtual: UG and PG policies differ
    std::string msg = (existing == nullptr ? "Entered " : "Updated ") + code + " for " + sid + ": " +
                      Result::formatMarks(centi) + " -> grade " + g.letter + " (" + std::to_string(g.gradePoint) +
                      " points, " + (g.passed ? "PASS" : "FAIL") + "). CGPA ";
    msg += hadResults ? twoDecimals(oldCgpa) + " -> " : "";
    msg += twoDecimals(s->cgpa()) + ", rank " + std::to_string(rankOf(sid)) + ".";
    return success(msg);
}

OpResult AcademicManager::undoLastMarksEntry() {
    MarksChange change{};
    if (stack_peek(undo_.get(), &change) != DS_OK) {
        return failure("Nothing to undo.");
    }
    Student* s = studentAt(studentSlot(change.student_id));
    if (s == nullptr || s->findResult(change.course_code) == nullptr) {
        stack_pop(undo_.get(), nullptr);  // stale entry: discard it
        return failure("The last change can no longer be undone (record missing); it was discarded.");
    }
    const bool passedNow = s->hasPassed(change.course_code);
    const bool passedAfter = change.action == MARKS_UPDATED && s->evaluate(change.previous_centi).passed;
    if (passedNow && !passedAfter) {
        const std::string blocker = enrolledCourseRequiring(*s, change.course_code);
        if (!blocker.empty()) {
            return failure("Undo blocked: " + std::string(change.student_id) + " is enrolled in " + blocker +
                           ", which requires a pass in " + change.course_code +
                           ". Cancel that registration first.");
        }
    }

    removeFromRanking(*s);
    std::string what;
    if (change.action == MARKS_ENTERED) {
        s->removeResult(change.course_code);
        what = "removed the " + std::string(change.course_code) + " result";
    } else {
        s->upsertResult(change.course_code, change.previous_centi, change.previous_credits);
        what = "restored " + std::string(change.course_code) + " to " + Result::formatMarks(change.previous_centi);
    }
    addToRanking(*s);
    stack_pop(undo_.get(), nullptr);  // only after the state was restored

    std::string msg = "Undo: " + what + " for " + s->id() + ".";
    if (s->hasResults()) {
        msg += " CGPA now " + twoDecimals(s->cgpa()) + ", rank " + std::to_string(rankOf(s->id())) + ".";
    } else {
        msg += " Student has no results and left the ranking.";
    }
    return success(msg);
}

std::size_t AcademicManager::undoDepth() const { return stack_size(undo_.get()); }

bool AcademicManager::peekUndo(MarksChange& out) const {
    return stack_peek(undo_.get(), &out) == DS_OK;
}

void AcademicManager::clearUndoHistory() { stack_clear(undo_.get()); }

std::vector<RankingEntry> AcademicManager::toRankingEntries(const std::vector<AVLEntry>& entries) const {
    std::vector<RankingEntry> out;
    for (const AVLEntry& e : entries) {
        const Student* s = findStudent(e.id);
        if (s == nullptr) continue;
        RankingEntry r;
        // competition ranking: 1 + number of students with a strictly higher CGPA
        r.rank = 1 + static_cast<int>(avl_count_above(ranking_.get(), e.score));
        r.studentId = s->id();
        r.name = s->name();
        r.category = s->categoryName();
        r.cgpa = s->cgpa();
        out.push_back(r);
    }
    return out;
}

std::vector<RankingEntry> AcademicManager::ranking() const {
    std::vector<AVLEntry> entries(avl_size(ranking_.get()));
    entries.resize(avl_reverse_inorder(ranking_.get(), entries.data(), entries.size()));
    return toRankingEntries(entries);
}

std::vector<RankingEntry> AcademicManager::rankingLowestFirst() const {
    std::vector<AVLEntry> entries(avl_size(ranking_.get()));
    entries.resize(avl_inorder(ranking_.get(), entries.data(), entries.size()));
    return toRankingEntries(entries);
}

std::vector<RankingEntry> AcademicManager::rankingAtLeast(double minCgpa) const {
    std::vector<AVLEntry> entries(avl_size(ranking_.get()));
    const int minScore = static_cast<int>(std::lround(minCgpa * 100.0));
    entries.resize(avl_collect_at_least(ranking_.get(), minScore, entries.data(), entries.size()));
    return toRankingEntries(entries);
}

int AcademicManager::rankOf(const std::string& studentId) const {
    const Student* s = findStudent(studentId);
    if (s == nullptr || !s->hasResults()) return 0;
    return 1 + static_cast<int>(avl_count_above(ranking_.get(), rankingScore(*s)));
}


}  // namespace academic
