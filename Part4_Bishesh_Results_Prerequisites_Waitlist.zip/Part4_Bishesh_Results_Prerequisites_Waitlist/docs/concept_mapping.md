# DSA and OOP Concept Mapping

Every concept below is executed by a real CLI operation. None of them is only described.

## 1. Data structures and algorithms (all in C)

| Concept | Problem it solves | File | Key functions | CLI operation that uses it | Time (space) | Why suitable |
|---|---|---|---|---|---|---|
| **Linked list** (head + tail) | ordered course roster; hash-table chains | `src/ds/linked_list.c` | `ll_push_back`, `ll_remove`, `ll_find`, `ll_first/ll_next`, `ll_destroy` | Register / cancel; View Course Details (roster); every hash lookup | push O(1), find/remove O(n) (O(n)) | rosters keep enrolment order and change size often; no shifting as in arrays |
| **Hash table** (separate chaining, FNV-1a, resize at load factor 0.75) | find a student/course by ID without scanning | `src/ds/hash_table.c` | `ht_insert`, `ht_find`, `ht_remove`, `ht_update`, `rehash`, `ht_hash_string` | every operation that takes an ID; Admin → View Student by ID; DSA → 1, 2 | O(1) average, O(n) worst (O(n + buckets)) | IDs are exact-match keys; the average stays constant as the system grows |
| **AVL BST** (balanced, with subtree sizes) | CGPA ranking that stays sorted while marks change | `src/ds/bst.c` | `avl_insert`, `avl_remove`, `rebalance`, `rotate_left/right`, `avl_reverse_inorder`, `avl_inorder`, `avl_count_above`, `avl_collect_at_least` | Student Ranking; Top Performers; student rank in profile; DSA → 3 | insert/delete/search O(log n) worst case; rank O(log n); traversal O(n) (O(n)) | re-sorting after every marks entry would cost O(n log n); the AVL update is O(log n) |
| **Graph** (directed, adjacency lists, DAG) | course prerequisites | `src/ds/graph.c` | `graph_add_edge` (rejects self-loop, duplicate, unknown, cycle), `graph_remove_vertex` | Add Prerequisite; View Prerequisite Chain; DSA → 4 | add edge O(V+E) because of the cycle check (O(V+E)) | prerequisites form a dependency network, not a list or a tree |
| **DFS** | transitive prerequisite validation, cycle detection, study order | `src/ds/graph.c` | `dfs_postorder`, `graph_check_prereqs`, `graph_is_reachable`, `dfs_cycle`, `graph_topological_order` | Register; Check Prerequisites; Available Courses status; Study Order | O(V+E) (O(V) visited array + recursion) | follows dependency chains of any depth; post-order lists foundational courses first |
| **Queue** (FIFO, front + rear) | course waiting list | `src/ds/queue.c` | `queue_enqueue`, `queue_dequeue`, `queue_position`, `queue_remove` | Register when full; Cancel (promotion); Waitlist Status; DSA → 5 | enqueue/dequeue O(1); position/remove O(n) (O(n)) | first come, first served is the fair policy for seats |
| **Stack** (LIFO) | undo the latest marks entry | `src/ds/stack.c` | `stack_push`, `stack_peek`, `stack_pop`, `stack_clear` | Enter/Update Marks (push); Undo Last Marks Entry; DSA → 6 | push/pop/peek O(1) (O(n)) | undo always reverses the most recent change first |
| **Linear search** | baseline; substring search by name | `src/ds/searching_sorting.c` | `ss_linear_search_key`, `ss_search_name` | Search Students by Name; DSA → 2 (comparison count) | O(n) (O(1)) | works on unsorted data and on partial (substring) matches |
| **Binary search** | fast search in a sorted array | `src/ds/searching_sorting.c` | `ss_binary_search_key` | DSA → 2; benchmark | O(log n) (O(1)) | shows the gain once data is sorted |
| **Merge sort** (stable) | sorted listings | `src/ds/searching_sorting.c` | `ss_merge_sort`, `merge`, `ss_compare`, `ss_is_sorted` | Sort Students (ID/name/CGPA); Sort Courses (code/title/enrolment); DSA → 7 | O(n log n) in every case (O(n) auxiliary) | guaranteed n log n with no bad worst case; stable |
| **CRC-32** (supporting algorithm) | detect corrupted or truncated save files | `src/FileManager.cpp` | `FileManager::crc32` | startup load; Reload Records | O(bytes) | detects any change to the file contents |

Sorting keys available: student ID, student name, CGPA (high first, students without results last),
course code, course title, enrolled count (high first). Ties always fall back to ID/code, so the output
order is deterministic.

## 2. Object-oriented programming (all in C++)

| Concept | Classes | Where to point in the code | Purpose here | Maintenance benefit |
|---|---|---|---|---|
| **Classes and objects** | `Student`, `UGStudent`, `PGStudent`, `Course`, `Result`, `RegistrationManager`, `AcademicManager`, `FileManager` | headers in `include/` | each academic entity or service is one class with one job | a change to registration rules touches only `RegistrationManager.cpp` |
| **Encapsulation** | all of them | private members (`Course::roster_`, `Student::results_`); validating setters (`Course::setCapacity` refuses capacity below enrolment; `Student::setSemester`); the facade hands out only `const Student*` / `const Course*` | the CLI cannot change a record without the facade updating every index | invariants are enforced in one place |
| **Inheritance** | `UGStudent : Student`, `PGStudent : Student` | `include/Student.hpp` | both share identity, results storage, `cgpa()`, `hasPassed()`; each defines its own academic policy | a new category (e.g. PhD) needs one new class and no changes elsewhere |
| **Abstraction** (abstract class) | `Student` has pure virtual functions (`evaluate`, `category`, `gradingPolicy`, `academicStanding`, `maxSemester`); `AcademicManager` hides the C layer | `Student.hpp`; `AcademicManager.hpp` | a plain "Student" cannot be created, only a UG or PG student; menus ask for "register" or "rank", never for buckets or nodes | the C internals can change without touching the CLI |
| **Runtime polymorphism** | `evaluate()` overridden in UG/PG; called through `const Student*` | `Student::cgpa()`, `Student::hasPassed()`, `RegistrationManager::checkPrerequisites()`, `printResults()` in `main.cpp` | 45 marks: UG → C (5 points, pass); PG → F (fail). This changes CGPA, ranking **and** prerequisite eligibility | one code path serves both categories |
| **Virtual destructor** | `virtual ~Student()` | `Student.hpp` | `unique_ptr<Student>` deletes a `UGStudent`/`PGStudent` correctly | no slicing or leaks |
| **Constructors / initialiser lists** | every class | e.g. `Course::Course(...) : code_(...), roster_(adoptHandle<...>(ll_create()))` | objects are valid from the moment they exist; bad input throws `invalid_argument`, which the facade turns into a message | no half-initialised objects |
| **RAII** | `CHandles.hpp` (`unique_ptr` + deleter calling `*_destroy`) | `AcademicManager` members, `Course::roster_/waitlist_`, benchmark structures | C memory is freed exactly once, automatically, even on early return | no manual `destroy` calls to forget |
| **`override`, `final`, `const` correctness** | `UGStudent`/`PGStudent` (`final`, `override`); const query methods everywhere | `Student.hpp`, `Course.hpp`, `AcademicManager.hpp` | the compiler checks overrides and blocks mutation through read-only views | mistakes show up at compile time |
| **Move semantics, deleted copies** | `Course` (move-only), `AcademicManager` (move-only) | `Course(const Course&) = delete;` and `importSnapshot` → `*this = std::move(fresh)` | two objects can never own the same C list; loading is all-or-nothing | prevents double free |
| **Facade pattern** | `AcademicManager` | `include/AcademicManager.hpp` | one API between the CLI, business rules, domain classes, C structures and persistence (as required by the Phase-I proposal) | the tests use the same API as the CLI |
