# Viva Preparation Guide

Every answer points to real code. Before the viva, each member should open their files and trace one
operation with a debugger or by hand. Examiners usually ask "show me where".

---

### 1. Why combine C and C++?
C gives direct control over memory and node layout: `malloc`/`free`, pointer links, no hidden
allocations. That suits the data structures (`src/ds/*.c`). C++ gives classes, encapsulation,
inheritance and polymorphism, which suit the academic domain (`Student`, `Course`, `AcademicManager`).
The split matches the course pair, Data Structures in C and OOP in C++, and makes the boundary explicit.
Trade-off: C++ alone (with the STL) would be simpler. We accept the extra interop work for learning and
for full control. We do **not** claim the C layer is faster than `std::unordered_map`; we have not measured that.

### 2. Why do the data structures matter for this project?
Every main feature is a data-structure problem. ID lookup is hashing. Ranking that stays up to date
is a balanced BST. Prerequisites are a DAG traversed with DFS. Fair waitlists are a FIFO queue. Undo is a LIFO
stack. Without them, each request would scan every record. The benchmark (DSA → 8) shows the measured gap,
e.g. hash lookup vs linear search on 20,000 records.

### 3. How does the hash table work? (`hash_table.c`)
`ht_hash_string` computes FNV-1a (XOR each byte in, multiply by the prime 16777619). `index_for` takes it
modulo the bucket count. Each bucket is a `LinkedList`, so colliding keys sit in the same list (**separate chaining**).
`ht_insert` rejects duplicates and doubles the table (`rehash`) before the load factor would pass 0.75.
Average lookup is O(1); the worst case is O(n). The stored value is the record's slot in the C++ vector, not a pointer.

### 4. How does BST ranking work? (`bst.c`)
Key = (CGPA×100, student ID). Lower scores go left; for equal scores the larger ID goes left, so a
**reverse inorder** walk (`avl_reverse_inorder`) gives the highest CGPA first, with ties ordered by ID.
When marks change, `recordMarks` removes the old key and inserts the new one (`removeFromRanking`/`addToRanking`).
The rank is `1 + avl_count_above(score)`, which uses subtree sizes, so equal CGPAs share a rank.

### 5. Why a *balanced* BST?
Students often arrive in sorted order (for example, when results are entered best-first). A plain BST would
then become a linked list with O(n) height. AVL rotations (`rotate_left`, `rotate_right`, the four cases in
`rebalance`) keep |height(left) − height(right)| ≤ 1, so the height stays below 1.44·log₂(n+2) and every
operation is O(log n) in the **worst** case. Test `avl_stays_balanced_on_sorted_input` proves it on 1023 sorted keys.

### 6. Why a graph and DFS for prerequisites?
Prerequisites are many-to-many and chain to any depth (ADV301 → DSA201 → PF101). That is a directed graph.
DFS (`dfs_postorder`) visits every direct and transitive prerequisite once in O(V+E). `graph_check_prereqs`
reports the ones the student has not **passed**. Passes are decided by the virtual `evaluate()`, so UG and
PG pass marks differ.

### 7. How are prerequisite cycles detected?
When an edge course → prereq is added, `graph_add_edge` first asks whether `prereq` can already reach `course`
(`graph_is_reachable`, DFS). If it can, the new edge would close a cycle, so it returns `DS_ERR_CYCLE`.
Self-loops and duplicates are rejected separately. After loading a file, `graph_has_cycle` runs a
white/grey/black DFS: meeting a grey (in-progress) vertex means a back edge, which means a cycle.

### 8. Stack vs queue: where and why?
- **Stack (LIFO)**: `stack.c`, used for undo. The newest marks change must be undone first.
  `recordMarks` pushes the previous state; `undoLastMarksEntry` peeks, validates, restores, then pops.
- **Queue (FIFO)**: `queue.c`, used for waitlists. The earliest request is served first.
  `requestRegistration` enqueues; `fillVacancies` dequeues.
Both have O(1) push/pop or enqueue/dequeue because of the head/top pointers (and the rear pointer for the queue).

### 9. Why is the waiting list FIFO?
FIFO is the simplest fair rule: whoever asked first gets the next seat. On every vacancy, `fillVacancies` takes
the front student, **rechecks** eligibility, and promotes them. If they are no longer eligible, they are removed
with a reason and the next student is considered. Test: `full_course_waitlist_and_fifo_promotion`.

### 10. What does runtime polymorphism demonstrate here?
`Student::evaluate()` is pure virtual. `UGStudent` and `PGStudent` override it with different grading
policies (pass mark 40 vs 50). Code that only holds a `const Student*`, such as `cgpa()`, `hasPassed()`,
`RegistrationManager::checkPrerequisites()` and `printResults()`, calls the correct version at run time
through the vtable. Example: 45 marks is a pass (C) for UG and a fail (F) for PG. That changes CGPA, ranking and
eligibility (test `ug_and_pg_grading_differ_through_base_pointer`; demo step 5–8).

### 11. What is the purpose of the abstract class?
`Student` has pure virtual functions, so `new Student(...)` does not compile. Every student must be a
concrete UG or PG student with a defined policy. The base class holds everything they share (ID, name, results,
CGPA calculation). The virtual destructor makes `unique_ptr<Student>` delete derived objects correctly.

### 12. How does `extern "C"` work?
C++ compilers *mangle* function names to encode parameter types (for overloading). C compilers do not.
Inside `extern "C" { ... }` (guarded by `#ifdef __cplusplus` in every `include/ds/*.h`), g++ uses the plain
C name, so a call from `AcademicManager_*.cpp` links to the symbol in the gcc-compiled `hash_table.o`.
Only C types cross: ints, `const char*`, plain structs, opaque pointers. No exceptions or `std::string`.

### 13. Encapsulation and inheritance in this code?
Encapsulation: `Course` keeps its roster and waitlist private and enforces "never above capacity" and
"never on both lists" itself (`Course::enroll`, `joinWaitlist`, `setCapacity`). The facade returns only
`const` pointers, so the CLI cannot change a record without the indexes being updated.
Inheritance: UG/PG share all of `Student` and override only policy methods (`evaluate`,
`academicStanding`, `maxSemester`, `gradingPolicy`).

### 14. How is binary persistence implemented?
`exportSnapshot` turns the state into plain records (IDs, names, numbers) in a fixed order.
`FileManager::serialize` writes magic "SARCRSDB", a version, the payload length, six tagged sections and a CRC-32,
using byte-by-byte little-endian integers. `save` writes `<file>.tmp` and then swaps it in, so a crash
cannot destroy the old file. On load, `deserialize` checks the magic, version, length, CRC and every
bound. `importSnapshot` then rebuilds every hash table, AVL tree, graph, list and queue from scratch inside a
new manager, and swaps it in only if every record is valid. We never write C++ objects or pointers directly:
they contain heap addresses that mean nothing after a restart.

### 15. Memory ownership and leak prevention?
Each allocation has exactly one owner (table in architecture.md §3). C memory is freed by `*_destroy`
functions called automatically by RAII handles (`CHandles.hpp`). C functions free their temporary buffers
before returning, and `free_nodes` in the AVL tree uses post-order so children are freed before parents. `Course` and
`AcademicManager` cannot be copied, which prevents two owners of one list (double free). Verified by
`make memcheck`: the live heap-block count returns to its starting value after the full workflow.

### 16. Search and sort complexity?
Hash O(1) average / O(n) worst; linear O(n); binary O(log n), but only on sorted data; merge sort
O(n log n) every case with O(n) extra space; AVL O(log n) worst case. DSA → 2 prints actual comparison
counts on live data; DSA → 8 prints measured times.

### 17. What were the integration challenges?
(1) Name mangling, solved with `extern "C"`. (2) Ownership across languages: C stores only IDs and slot numbers;
C++ owns the objects. (3) Keeping five indexes consistent: validate-then-mutate in every facade method.
(4) Marks edits that could invalidate registrations: pass→fail is blocked while a dependent enrolment exists.
(5) Coarse Windows timer (≈0.6 ms): the benchmark repeats each batch until 50 ms have passed.
(6) `mingw32-make` runs recipes in `cmd.exe`: the Makefile has a Windows branch.

### 18. Limitations?
Single-user CLI, no authentication, no concurrency. Grading rules are demonstration defaults. The data is
kept fully in memory. A waitlist stays in place when the course is full, even for students who later become
ineligible; they are only removed when a seat opens. No comparison with a real ERP system. ASan/Valgrind were not
run on the Windows machine.

### 19. Future improvements?
Real authentication and role permissions; configurable grading policies loaded from a file; semesters and
course history (retakes); per-student credit limits; concurrency control for simultaneous registration;
an index of enrolments per student (instead of scanning courses); CSV import/export; a GUI on top of the same facade.

---

## Probing questions to expect

- *"Why not `std::unordered_map` / `std::set`?"* The course is about implementing the structures; ours are
  tested, but the STL versions would be fine in production. Do not claim ours are faster.
- *"Why not SQL?"* The proposal chose local binary files (no server). Trade-off: no queries, no concurrent
  access, everything held in memory.
- *"What happens with two students on the same CGPA?"* Same rank number; listed by ascending ID
  (`compare_keys` in `bst.c`).
- *"What if the save file is edited by hand?"* The CRC fails, so the file is reported as corrupt, renamed to `.corrupt`,
  and the program starts empty. A file with a valid checksum but bad records is also rejected by `importSnapshot`.
- *"Show the undo actually restoring data."* Staff → 2 (update marks) → 4 (ranking) → 3 (undo) → 4 (ranking).
- *"Can a student register without passing the prerequisite?"* No. Demo step 7. Being registered for a course is
  not the same as passing it.

## Per-member walkthroughs (practise these)

| Member | Trace this operation from CLI to C and back |
|---|---|
| Pratham | Admin → Students → Add, then View by ID: `addStudent` → `ht_insert`; `findStudent` → `ht_find` → slot → `Student`. Explain FNV-1a, chaining, rehash, and an AVL rotation. |
| Anirudh | Student → Register when the course is full: `registerForCourse` → `requestRegistration` → `Course::joinWaitlist` → `queue_enqueue`; then the save. Explain the facade, RAII handles and the Makefile's C/C++ split. |
| Anjali | Admin → Students → Sort by name: `sortedStudents` → `ss_merge_sort`; DSA → 2 comparison counts; Save → `serialize` → CRC → temp-file swap; corrupted-file handling. |
| Bishesh | Staff → Enter marks → Undo: `recordMarks` → `stack_push` → AVL update; `undoLastMarksEntry`; prerequisite DFS in `graph_check_prereqs`; `fillVacancies` after a cancellation. |
