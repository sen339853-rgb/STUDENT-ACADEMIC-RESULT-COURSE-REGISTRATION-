// Result.hpp
// One examination result: a student's marks in one course.
#ifndef RESULT_HPP
#define RESULT_HPP

#include <string>

namespace academic {

// Outcome of applying a grading policy to a mark.
struct GradeInfo {
    std::string letter;  // e.g. "A+"
    int gradePoint;      // 0-10
    bool passed;
};

class Result {
public:
    // Marks are kept in hundredths ("centi-marks", 72.5 -> 7250) so they can
    // be compared exactly and written to the binary file as integers.
    Result(std::string courseCode, int centiMarks, int credits);

    const std::string& courseCode() const { return courseCode_; }
    int centiMarks() const { return centiMarks_; }
    double marks() const { return centiMarks_ / 100.0; }
    // Credits are recorded with the result, like a transcript line, so a
    // later catalogue change cannot silently alter an existing CGPA.
    int credits() const { return credits_; }

    void setCentiMarks(int centiMarks);

    static constexpr int kMaxCentiMarks = 10000;  // 100.00
    static bool isValidCentiMarks(int centiMarks);
    static int toCenti(double marks);              // rounds to 0.01
    static std::string formatMarks(int centiMarks); // 7250 -> "72.50"

private:
    std::string courseCode_;
    int centiMarks_;
    int credits_;
};

}  // namespace academic

#endif  // RESULT_HPP
