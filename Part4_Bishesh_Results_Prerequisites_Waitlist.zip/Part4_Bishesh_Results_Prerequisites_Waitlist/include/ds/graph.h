/*
 * graph.h
 * Directed prerequisite graph stored as adjacency lists.
 *
 * Vertices are courses, identified by a small non-negative integer id (the
 * course's slot in the C++ record store) plus a printable label (the course
 * code). An edge  course -> prereq  means "course REQUIRES prereq".
 *
 * The graph is kept a Directed Acyclic Graph (DAG): graph_add_edge rejects
 * self-loops, duplicate edges, unknown vertices, and any edge that would
 * close a cycle (checked with DFS before the edge is inserted).
 *
 * Complexity (V vertices, E edges):
 *   add vertex      O(1) amortised          add edge      O(V + E) (cycle DFS)
 *   DFS/reachability O(V + E)               topological order O(V + E)
 *   memory          O(V + E)
 */
#ifndef GRAPH_H
#define GRAPH_H

#include <stddef.h>
#include "ds/ds_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Graph Graph;

Graph *graph_create(size_t initial_capacity);
void graph_destroy(Graph *graph);

int graph_add_vertex(Graph *graph, int id, const char *label);
int graph_remove_vertex(Graph *graph, int id);  /* also drops its edges */
int graph_has_vertex(const Graph *graph, int id);
const char *graph_vertex_label(const Graph *graph, int id);
size_t graph_vertex_count(const Graph *graph);
size_t graph_edge_count(const Graph *graph);
size_t graph_capacity(const Graph *graph);      /* every id is < capacity */

int graph_add_edge(Graph *graph, int course, int prereq);
int graph_remove_edge(Graph *graph, int course, int prereq);
int graph_has_edge(const Graph *graph, int course, int prereq);

/* 1 if a path from -> ... -> to exists (DFS), else 0. */
int graph_is_reachable(const Graph *graph, int from, int to);

/* Direct prerequisites, in the order they were added. */
size_t graph_direct_prereqs(const Graph *graph, int course, int *out, size_t max);
/* Direct dependents: courses that list `prereq` as a direct prerequisite. */
size_t graph_direct_dependents(const Graph *graph, int prereq, int *out, size_t max);
/* All direct + transitive prerequisites in DFS post-order, i.e. the most
 * foundational course first. The course itself is not included. */
size_t graph_all_prereqs(const Graph *graph, int course, int *out, size_t max);

/* Prerequisite validation with DFS.
 * passed[id] != 0 means the student has PASSED course id (ids >= passed_len
 * count as not passed). Every direct and transitive prerequisite of course
 * that is not passed is written to missing[] (foundational first).
 * Returns DS_OK and sets *missing_count; the student is eligible when
 * *missing_count == 0. */
int graph_check_prereqs(const Graph *graph, int course,
                        const unsigned char *passed, size_t passed_len,
                        int *missing, size_t max_missing, size_t *missing_count);

/* Whole-graph cycle check (white/grey/black DFS). Used to validate data
 * loaded from disk. Returns 1 if a cycle exists. */
int graph_has_cycle(const Graph *graph);

/* Topological order of all vertices, prerequisites before dependents.
 * Returns the number written, or 0 if the graph has a cycle. */
size_t graph_topological_order(const Graph *graph, int *out, size_t max);

#ifdef __cplusplus
}
#endif

#endif /* GRAPH_H */
