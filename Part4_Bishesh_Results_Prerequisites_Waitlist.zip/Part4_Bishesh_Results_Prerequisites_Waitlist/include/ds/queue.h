/*
 * queue.h
 * FIFO queue of student IDs, used as the waiting list of one course.
 *
 * Implemented as a singly linked list with front and rear pointers:
 *   enqueue at rear  O(1)      dequeue at front  O(1)      peek O(1)
 *   contains / position / remove-from-middle  O(n)  (needed when a student
 *   leaves a waiting list voluntarily).
 */
#ifndef QUEUE_H
#define QUEUE_H

#include <stddef.h>
#include "ds/ds_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Queue Queue;
typedef struct QueueNode QueueNode; /* opaque, used only as a cursor */

Queue *queue_create(void);
void queue_destroy(Queue *queue);
void queue_clear(Queue *queue);

int queue_enqueue(Queue *queue, const char *id);
/* Copies the front ID into out (out_size bytes) and removes it. */
int queue_dequeue(Queue *queue, char *out, size_t out_size);
int queue_peek(const Queue *queue, char *out, size_t out_size);
int queue_is_empty(const Queue *queue);
size_t queue_size(const Queue *queue);

int queue_contains(const Queue *queue, const char *id);
/* 1-based position from the front, or 0 if absent. */
size_t queue_position(const Queue *queue, const char *id);
/* Removes a specific ID wherever it is, keeping everyone else's order. */
int queue_remove(Queue *queue, const char *id);

/* Read-only traversal from front to rear. */
const QueueNode *queue_front_node(const Queue *queue);
const QueueNode *queue_node_next(const QueueNode *node);
const char *queue_node_id(const QueueNode *node);

#ifdef __cplusplus
}
#endif

#endif /* QUEUE_H */
