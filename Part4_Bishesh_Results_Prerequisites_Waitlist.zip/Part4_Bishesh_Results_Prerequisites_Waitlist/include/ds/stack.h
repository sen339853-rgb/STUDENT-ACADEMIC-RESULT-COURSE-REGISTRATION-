/*
 * stack.h
 * LIFO stack of marks-entry changes, used for "undo last marks entry".
 *
 * Each element records enough of the PREVIOUS state to restore it exactly:
 * whether a result existed before, and if so its marks and credits.
 * Marks are stored in hundredths (72.5 -> 7250) so no precision is lost.
 *
 * Implemented as a singly linked list where the head is the top:
 *   push O(1), pop O(1), peek O(1), clear O(n).
 */
#ifndef STACK_H
#define STACK_H

#include <stddef.h>
#include "ds/ds_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum MarksAction {
    MARKS_ENTERED = 1,   /* a new result was created  -> undo deletes it   */
    MARKS_UPDATED = 2    /* an existing result changed -> undo restores it */
} MarksAction;

typedef struct MarksChange {
    char student_id[DS_KEY_LEN];
    char course_code[DS_KEY_LEN];
    int action;            /* MarksAction */
    int previous_centi;    /* valid when action == MARKS_UPDATED */
    int previous_credits;  /* valid when action == MARKS_UPDATED */
    int new_centi;         /* value written by the change (for display) */
} MarksChange;

typedef struct Stack Stack;

Stack *stack_create(void);
void stack_destroy(Stack *stack);
void stack_clear(Stack *stack);

int stack_push(Stack *stack, const MarksChange *change);  /* copies *change */
int stack_pop(Stack *stack, MarksChange *out);            /* out may be NULL */
int stack_peek(const Stack *stack, MarksChange *out);
int stack_is_empty(const Stack *stack);
size_t stack_size(const Stack *stack);

#ifdef __cplusplus
}
#endif

#endif /* STACK_H */
