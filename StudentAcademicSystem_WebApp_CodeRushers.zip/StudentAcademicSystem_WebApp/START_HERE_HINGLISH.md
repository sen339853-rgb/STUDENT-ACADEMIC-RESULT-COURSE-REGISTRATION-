# Code Rushers — Working Academic Web App

**Project:** Student Academic Result & Course Registration System

## Sabse simple: Chrome mein run karo

1. `StudentAcademicSystem_WebApp.zip` download karke **Extract All** karo.
2. Extracted `StudentAcademicSystem_WebApp` folder kholo.
3. `index.html` par **double-click** karo. Chrome/Edge mein website khul jayegi. Internet, VS Code, Node.js, ya Python ki zaroorat nahi.
4. Left menu se **Overview, Students, Courses, Registration, Results & Grades, Leaderboard, Activity & Data** open kar sakte ho.
5. **Overview → Run mentor demo** pe click karoge toh live academic workflow execute hoga aur output show hoga.

Agar browser local-file access restrict kare, VS Code **Live Server** extension ke saath `index.html` par right-click → **Open with Live Server**. Alternative: project folder mein terminal open karo, `python -m http.server 8000` run karo, phir http://localhost:8000 kholo.

## Mentor ke saamne khud input → output ka demo

**Pehle Overview → Reset sample data** click karo, taaki starting position consistent ho.

1. **Registration** tab mein Student `S1003` aur Course `DSA201` choose karo. **Check eligibility**: prerequisite `PRG101` fail hai (25/100), isliye REJECTED.
2. Student `S1001`, Course `DSA201` select karke **Register**: ENROLLED. Course capacity = 1, ab 0 seats.
3. Student `S1002`, Course `DSA201` **Register**: WAITLISTED, position #1.
4. `S1001` aur `DSA201` **Cancel registration**: seat khali hogi aur queue ke pehle student `S1002` ko admission mil jayega.
5. **Results & Grades** mein `S1001`, `PRG101`, marks `95` enter karo. Result/GPA update hota dikhega. **Undo latest marks** karo, old marks (85) restore ho jayenge.
6. **Leaderboard** kholo: GPA based student ranking dikhegi.
7. Browser close karke dobara `index.html` kholo: localStorage available hone par changes preserved rahenge. **Activity & Data → Export JSON** backup bhi de sakte ho.

## Apne inputs kya de sakte ho?

| Screen | Input | Sample |
|---|---|---|
| Students | ID, name, UG/PG, program, semester | `S2001`, `Aditya`, `UG`, `BTech CSE`, `3` |
| Courses | Code, title, credits, seat capacity | `AI301`, `Intro to AI`, `4`, `2` |
| Prerequisites | Course aur prerequisite course | `AI301` needs `DSA201` |
| Results | Student, course, marks (0–100) | `S2001`, `PRG101`, `91` |
| Registration | Student + course | `S2001` → `DSA201` |
| Ranking | Calculated GPA; no manual input | Leaderboard tab |

## Important distinction: C/C++ PBL vs browser app

- **Original C/C++ console application** uses C11 data structures (custom hash table, AVL/BST, linked list, graph, queue, stack) and C++17 OOP with `extern "C"`, plus local binary `.dat` storage.
- **This browser app** is a **separate HTML/CSS/JavaScript version** implementing the same student/course/result/registration business workflow for a visual live demonstration. It does **not** execute the original compiled C/C++ code or expose its binary `.dat` format directly.
- Browser version uses JavaScript DFS, FIFO arrays, an undo stack and JS object-oriented classes. It stores state using browser `localStorage`, with JSON export/import.
- Grading policies are fictional **demonstration rules, not official university grading policies**: UG pass ≥40, PG pass ≥50, grade points are based on demonstration thresholds.
- No real login, multi-user server, secure database, or university ERP integration. Do not upload real student records into this prototype.

## Developer verification

If Node.js installed: `node tests/test_core.js` (19 automated domain-logic assertions).

## Files

`index.html` — web entry point; `styles.css` — styling; `core.js` — academic logic; `app.js` — user interface; `tests/test_core.js` — executable tests.

**Quick viva line:** “Sir, our original project is a hybrid C/C++ CLI implementation. This is its browser-based interactive demonstration layer, showing the same academic workflows with user inputs and live outputs. The browser implementation is standalone JavaScript, not the native C/C++ executable.”
