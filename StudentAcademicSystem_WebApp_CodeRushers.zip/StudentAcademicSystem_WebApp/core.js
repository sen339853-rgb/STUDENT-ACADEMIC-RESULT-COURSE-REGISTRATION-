/* Academic System — browser-side working implementation.
   This is a JavaScript demonstration of the same academic workflows as the C/C++ CLI.
   It does not execute the native C/C++ data-structure modules. */
(function(root, factory) {
  const exported = factory();
  if (typeof module === 'object' && module.exports) module.exports = exported;
  else root.AcademicCore = exported;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';
  const KEY = 'code-rushers-academic-v1';
  const ID_RE = /^[A-Za-z0-9_-]{1,31}$/;
  const clone = data => JSON.parse(JSON.stringify(data));
  const fail = message => { throw new Error(message); };
  const clean = x => String(x ?? '').trim();
  const text = (v, label, max=79) => {
    const s = clean(v);
    if (!s || s.length > max || /[\x00-\x1f\x7f]/.test(s)) fail(`${label} must be 1–${max} valid characters.`);
    return s;
  };
  const id = (v, label='ID') => { const s=clean(v).toUpperCase(); if(!ID_RE.test(s)) fail(`${label} can contain 1–31 letters, numbers, - or _.`); return s; };
  const intRange = (v,label,min,max) => {
    const n = Number(v);
    if (v==='' || v===null || !Number.isInteger(n) || n<min || n>max) fail(`${label} must be an integer from ${min} to ${max}.`);
    return n;
  };
  const numberRange = (v,label,min,max) => {
    const n=Number(v);
    if(v==='' || v===null || !Number.isFinite(n) || n<min || n>max) fail(`${label} must be from ${min} to ${max}.`);
    return n;
  };
  class Student {
    constructor(record){this.record=record;}
    passes(m){throw new Error('Abstract grading method');}
    gradePoints(m){throw new Error('Abstract grading method');}
  }
  class UGStudent extends Student {
    passes(m){return m>=40;}
    gradePoints(m){return m<40?0:m>=90?10:m>=80?9:m>=70?8:m>=60?7:m>=50?6:5;}
  }
  class PGStudent extends Student {
    passes(m){return m>=50;}
    gradePoints(m){return m<50?0:m>=90?10:m>=80?9:m>=70?8:m>=60?7:6;}
  }
  const studentObject = record => record.type==='PG'?new PGStudent(record):new UGStudent(record);
  const now = () => new Date().toISOString();
  const initial = () => ({
    version:1,
    students:[
      {id:'S1001',name:'Aanya Sharma',program:'BTech CSE',semester:3,type:'UG'},
      {id:'S1002',name:'Rohan Mehta',program:'BTech CSE',semester:3,type:'UG'},
      {id:'S1003',name:'Meera Singh',program:'BTech CSE',semester:3,type:'UG'},
      {id:'S1004',name:'Kavya Rao',program:'MTech CSE',semester:1,type:'PG'}
    ],
    courses:[
      {code:'PRG101',title:'Programming Fundamentals',credits:4,capacity:8,prereqs:[],enrolled:[],waitlist:[]},
      {code:'DSA201',title:'Data Structures',credits:4,capacity:1,prereqs:['PRG101'],enrolled:[],waitlist:[]},
      {code:'ALG301',title:'Advanced Algorithms',credits:3,capacity:2,prereqs:['DSA201'],enrolled:[],waitlist:[]},
      {code:'DB202',title:'Database Systems',credits:3,capacity:2,prereqs:[],enrolled:[],waitlist:[]}
    ],
    results:[
      {student:'S1001',course:'PRG101',marks:85},
      {student:'S1002',course:'PRG101',marks:78},
      {student:'S1003',course:'PRG101',marks:25},
      {student:'S1004',course:'PRG101',marks:88}
    ],
    undo:[],
    events:[{time:now(),kind:'system',message:'Fictional demo dataset loaded. Try registration with S1003, S1001 and S1002.'}]
  });
  class AcademicSystem {
    constructor(data) {this.state=data ? clone(data) : initial(); this.validate();}
    snapshot(){return clone(this.state);}
    students(){return this.state.students;}
    courses(){return this.state.courses;}
    student(sid){return this.state.students.find(s=>s.id===clean(sid).toUpperCase())||null;}
    course(code){return this.state.courses.find(c=>c.code===clean(code).toUpperCase())||null;}
    requireStudent(sid){return this.student(sid)||fail(`Student ${clean(sid)||'(empty)'} not found.`);}
    requireCourse(code){return this.course(code)||fail(`Course ${clean(code)||'(empty)'} not found.`);}
    result(sid,code){return this.state.results.find(r=>r.student===clean(sid).toUpperCase()&&r.course===clean(code).toUpperCase())||null;}
    gpa(sid){
      const s=this.requireStudent(sid), obj=studentObject(s);
      const entries=this.state.results.filter(r=>r.student===s.id);
      let pts=0, credits=0;
      entries.forEach(r=>{const c=this.course(r.course); if(c){credits+=c.credits;pts+=c.credits*obj.gradePoints(r.marks);}});
      return credits?pts/credits:0;
    }
    ranking(){return this.students().map(s=>({...s,gpa:this.gpa(s.id)})).sort((a,b)=>b.gpa-a.gpa || a.id.localeCompare(b.id));}
    passes(sid,code){const s=this.requireStudent(sid), r=this.result(s.id,code);return !!(r&&studentObject(s).passes(r.marks));}
    // Genuine DFS over the directed prerequisite graph (checks indirect dependencies too).
    dependencies(code){
      const target=this.requireCourse(code), seen=new Set(), visiting=new Set(), answer=[];
      const dfs=c=>{
        if(visiting.has(c.code))fail('Prerequisite cycle detected.');
        visiting.add(c.code);
        for(const req of c.prereqs){const dep=this.requireCourse(req);dfs(dep);if(!seen.has(dep.code)){seen.add(dep.code);answer.push(dep.code);}}
        visiting.delete(c.code);
      };
      dfs(target); return answer;
    }
    eligibility(sid,code){
      const student=this.requireStudent(sid), course=this.requireCourse(code);
      const required=this.dependencies(course.code);
      const missing=required.filter(pre=>!this.passes(student.id,pre));
      return {ok:missing.length===0,required,missing,message:missing.length?`NOT ELIGIBLE: ${missing.join(', ')} prerequisite(s) not passed.`:'ELIGIBLE: all direct and transitive prerequisites passed.'};
    }
    _activeValid(sid){
      return this.courses().every(c=>!(c.enrolled.includes(sid)||c.waitlist.includes(sid))||this.eligibility(sid,c.code).ok);
    }
    log(message,kind='info'){
      this.state.events.unshift({time:now(),kind,message});
      this.state.events.length=Math.min(this.state.events.length,150);
      return message;
    }
    addStudent(data){
      const s={id:id(data.id,'Student ID'),name:text(data.name,'Name'),program:text(data.program,'Program'),semester:intRange(data.semester,'Semester',1,12),type:clean(data.type).toUpperCase()};
      if(!['UG','PG'].includes(s.type))fail('Student type must be UG or PG.');
      if(this.student(s.id))fail(`Student ${s.id} already exists.`);
      this.students().push(s);return this.log(`Student ${s.id} (${s.type}) added successfully.`,'success');
    }
    updateStudent(sid,data){
      const s=this.requireStudent(sid);const newName=text(data.name,'Name'),newProgram=text(data.program,'Program'),newSemester=intRange(data.semester,'Semester',1,12);s.name=newName;s.program=newProgram;s.semester=newSemester;
      return this.log(`Student ${s.id} updated.`,'success');
    }
    deleteStudent(sid){
      const s=this.requireStudent(sid);
      if(this.courses().some(c=>c.enrolled.includes(s.id)||c.waitlist.includes(s.id)))fail('Cancel active enrollments and waitlists before deleting student.');
      this.state.students=this.students().filter(x=>x.id!==s.id);
      this.state.results=this.state.results.filter(x=>x.student!==s.id);
      this.state.undo=[];
      return this.log(`Student ${s.id} deleted; their results and undo history cleared.`,'success');
    }
    addCourse(data){
      const c={code:id(data.code,'Course code'),title:text(data.title,'Course title'),credits:intRange(data.credits,'Credits',1,10),capacity:intRange(data.capacity,'Capacity',1,10000),prereqs:[],enrolled:[],waitlist:[]};
      if(this.course(c.code))fail(`Course ${c.code} already exists.`);
      this.courses().push(c);return this.log(`Course ${c.code} added with ${c.capacity} seats.`,'success');
    }
    updateCourse(code,data){
      const c=this.requireCourse(code), cap=intRange(data.capacity,'Capacity',1,10000);
      if(cap<c.enrolled.length)fail('Capacity cannot be smaller than current enrollment.');
      const newTitle=text(data.title,'Course title'),newCredits=intRange(data.credits,'Credits',1,10);c.title=newTitle;c.credits=newCredits;c.capacity=cap;
      const promoted=this.promote(c);
      return this.log(`Course ${c.code} updated.${promoted.length?' Promoted '+promoted.join(', ')+'.':''}`,'success');
    }
    deleteCourse(code){
      const c=this.requireCourse(code);
      if(c.enrolled.length||c.waitlist.length)fail('Cancel enrollments and waitlist entries first.');
      if(this.state.results.some(r=>r.course===c.code))fail('Course has recorded results.');
      if(this.courses().some(x=>x.prereqs.includes(c.code)))fail('Another course depends on this prerequisite. Remove the dependency first.');
      this.state.courses=this.courses().filter(x=>x.code!==c.code);
      return this.log(`Course ${c.code} deleted.`,'success');
    }
    addPrereq(code,needed){
      const c=this.requireCourse(code), dep=this.requireCourse(needed);
      if(c.code===dep.code)fail('Self-dependency is not allowed.');
      if(c.prereqs.includes(dep.code))fail('Prerequisite already exists.');
      if(this.dependencies(dep.code).includes(c.code))fail('Rejected: this prerequisite would create a cycle.');
      c.prereqs.push(dep.code);
      if(this.students().some(s=>!this._activeValid(s.id))){c.prereqs.pop();fail('Dependency would invalidate an existing enrollment/waitlist.');}
      return this.log(`${c.code} now requires ${dep.code} (graph edge).`,'success');
    }
    removePrereq(code,needed){
      const c=this.requireCourse(code), p=id(needed,'Prerequisite ID');
      if(!c.prereqs.includes(p))fail('Prerequisite link not found.');
      c.prereqs=c.prereqs.filter(x=>x!==p);
      return this.log(`Removed ${p} prerequisite from ${c.code}.`,'success');
    }
    promote(course){
      const promoted=[];
      while(course.enrolled.length<course.capacity&&course.waitlist.length){
        const sid=course.waitlist.shift(); // preserve FIFO order of the waiting array
        if(this.student(sid)&&!course.enrolled.includes(sid)&&this.eligibility(sid,course.code).ok){course.enrolled.push(sid);promoted.push(sid);}
      }
      return promoted;
    }
    register(sid,code){
      const s=this.requireStudent(sid), c=this.requireCourse(code);
      if(c.enrolled.includes(s.id))fail(`${s.id} is already enrolled in ${c.code}.`);
      if(c.waitlist.includes(s.id))fail(`${s.id} is already waitlisted for ${c.code}.`);
      const e=this.eligibility(s.id,c.code);
      if(!e.ok)fail(`REJECTED: ${e.missing.join(', ')} prerequisite(s) not passed.`);
      const promoted=this.promote(c);
      if(c.enrolled.length<c.capacity){c.enrolled.push(s.id);return this.log(`ENROLLED: ${s.id} → ${c.code}. Seats left: ${c.capacity-c.enrolled.length}.`,'success');}
      c.waitlist.push(s.id);
      return this.log(`WAITLISTED: ${s.id} → ${c.code}. FIFO position #${c.waitlist.length}${promoted.length?' (previous waiters promoted)':''}.`,'warning');
    }
    cancel(sid,code){
      const s=this.requireStudent(sid), c=this.requireCourse(code);
      if(c.waitlist.includes(s.id)){
        c.waitlist=c.waitlist.filter(x=>x!==s.id);
        return this.log(`Removed ${s.id} from ${c.code} waitlist.`,'success');
      }
      if(!c.enrolled.includes(s.id))fail('No enrollment or waitlist entry found.');
      c.enrolled=c.enrolled.filter(x=>x!==s.id);
      const promoted=this.promote(c);
      return this.log(`CANCELLED: ${s.id} left ${c.code}.${promoted.length?' Promoted from FIFO waitlist: '+promoted.join(', ')+'.':' Seat available.'}`,'success');
    }
    setMarks(sid,code,marks){
      const s=this.requireStudent(sid), c=this.requireCourse(code), m=numberRange(marks,'Marks',0,100), previous=this.result(s.id,c.code);
      if(previous&&previous.marks===m)return this.log('Marks unchanged.');
      const before=previous?previous.marks:null;
      if(previous)previous.marks=m;
      else this.state.results.push({student:s.id,course:c.code,marks:m});
      if(!this._activeValid(s.id)){
        if(previous)previous.marks=before;
        else this.state.results=this.state.results.filter(r=>!(r.student===s.id&&r.course===c.code));
        fail('Marks change rejected: an active registration depends on passing this prerequisite.');
      }
      this.state.undo.push({student:s.id,course:c.code,previous:before});
      const policy=studentObject(s);
      return this.log(`MARKS SAVED: ${s.id} / ${c.code} = ${m}/100 → ${policy.passes(m)?'PASS':'FAIL'}, ${policy.gradePoints(m)} grade points.`,'success');
    }
    undoMarks(){
      const op=this.state.undo.at(-1); if(!op)fail('Undo stack is empty.');
      const s=this.requireStudent(op.student), c=this.requireCourse(op.course), current=this.result(s.id,c.code);
      if(!current)fail('Undo target is missing.');
      const last=current.marks;
      if(op.previous===null)this.state.results=this.state.results.filter(r=>!(r.student===s.id&&r.course===c.code));
      else current.marks=op.previous;
      if(!this._activeValid(s.id)){
        if(op.previous===null)this.state.results.push({student:s.id,course:c.code,marks:last});
        else current.marks=last;
        fail('Cannot undo: an active enrollment requires the current passing marks.');
      }
      this.state.undo.pop();
      return this.log(`UNDO: restored ${s.id}/${c.code} to ${op.previous===null?'no recorded result':op.previous+'/100'}.`,'success');
    }
    registrations(sid){
      const s=this.requireStudent(sid);
      return this.courses().flatMap(c=>c.enrolled.includes(s.id)?[{code:c.code,status:'ENROLLED',position:0}]:c.waitlist.includes(s.id)?[{code:c.code,status:'WAITLISTED',position:c.waitlist.indexOf(s.id)+1}]:[]);
    }
    stats(){return {students:this.students().length,courses:this.courses().length,enrolled:this.courses().reduce((n,c)=>n+c.enrolled.length,0),waiting:this.courses().reduce((n,c)=>n+c.waitlist.length,0),results:this.state.results.length};}
    validate(){
      const st=this.state;
      if(!st||st.version!==1||!Array.isArray(st.students)||!Array.isArray(st.courses)||!Array.isArray(st.results)||!Array.isArray(st.undo)||!Array.isArray(st.events))fail('Invalid or unsupported data format.');
      if(st.students.length>5000||st.courses.length>1000||st.results.length>100000||st.undo.length>20000||st.events.length>300)fail('Data exceeds supported demo limits.');
      const sids=new Set(),codes=new Set();
      for(const s of st.students){if(!s||id(s.id)!==s.id||sids.has(s.id))fail('Duplicate or invalid student ID.');sids.add(s.id);text(s.name,'Name');text(s.program,'Program');intRange(s.semester,'Semester',1,12);if(!['UG','PG'].includes(s.type))fail('Invalid student type.');}
      for(const c of st.courses){if(!c||id(c.code)!==c.code||codes.has(c.code))fail('Duplicate or invalid course code.');codes.add(c.code);text(c.title,'Course title');intRange(c.credits,'Credits',1,10);intRange(c.capacity,'Capacity',1,10000);if(!Array.isArray(c.prereqs)||!Array.isArray(c.enrolled)||!Array.isArray(c.waitlist))fail('Invalid course lists.');if(c.enrolled.length>c.capacity)fail('Over-capacity enrollment.');if(new Set(c.enrolled).size!==c.enrolled.length||new Set(c.waitlist).size!==c.waitlist.length)fail('Duplicate enrollment/waitlist.');if(new Set([...c.enrolled,...c.waitlist]).size!==c.enrolled.length+c.waitlist.length)fail('Enrollment/waitlist overlap.');}
      for(const c of st.courses){if(new Set(c.prereqs).size!==c.prereqs.length||c.prereqs.some(p=>!codes.has(p)||p===c.code))fail('Invalid prerequisite reference.');if([...c.enrolled,...c.waitlist].some(s=>!sids.has(s)))fail('Unknown student in registrations.');}
      const resultKeys=new Set();
      for(const r of st.results){if(!r||!sids.has(r.student)||!codes.has(r.course))fail('Unknown results reference.');numberRange(r.marks,'Marks',0,100);const k=r.student+'|'+r.course;if(resultKeys.has(k))fail('Duplicate result.');resultKeys.add(k);}
      for(const op of st.undo){if(!op||!sids.has(op.student)||!codes.has(op.course)||(op.previous!==null&&!(Number.isFinite(op.previous)&&op.previous>=0&&op.previous<=100)))fail('Invalid undo record.');}
      // check for graph cycles and validate all currently admitted/waitlisted students
      for(const c of st.courses)this.dependencies(c.code);
      for(const s of st.students)if(!this._activeValid(s.id))fail('Data contains students enrolled without passing prerequisites.');
      for(const event of st.events){if(!event||typeof event.message!=='string'||event.message.length>500||typeof event.kind!=='string'||typeof event.time!=='string')fail('Invalid activity log.');}
      return true;
    }
  }
  return {AcademicSystem, initial, KEY, studentObject, UGStudent, PGStudent};
});
