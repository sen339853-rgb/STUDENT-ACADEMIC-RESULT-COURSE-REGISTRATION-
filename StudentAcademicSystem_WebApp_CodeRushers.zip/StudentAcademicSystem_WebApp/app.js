/* Browser UI — no npm, backend, internet or external library required. */
(() => {
  'use strict';
  const {AcademicSystem, initial, KEY, studentObject} = window.AcademicCore;
  const app = document.getElementById('app');
  const bread = document.getElementById('breadcrumb');
  const fileInput = document.getElementById('importFile');
  const pageNames={dashboard:'Overview',students:'Students',courses:'Courses',registration:'Registration',results:'Results & Grades',ranking:'Leaderboard',activity:'Activity & Data',about:'How it works'};
  let model;
  let page='dashboard', selectedStudent='S1001', selectedCourse='DSA201';
  let editingStudent=null, editingCourse=null, studentSort='id';
  let output='Select a student and course, then click an action to see the live result.';
  let toastTimer;
  let storageActive=true;
  const escape = str => String(str??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const escAttr = escape;
  const s = (value) => escape(value);
  const when = iso => {const d=new Date(iso);return Number.isNaN(d.getTime())?'Unknown time':d.toLocaleString(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});};
  const fmt = n => Number(n).toFixed(2);
  function init(){
    try{
      const item=localStorage.getItem(KEY);
      model=item?new AcademicSystem(JSON.parse(item)):new AcademicSystem();
    }catch(err){model=new AcademicSystem();storageActive=false;output='Local data unavailable or invalid. Started with fictional demo records. '+err.message;}
    render();
  }
  function save(){try{localStorage.setItem(KEY,JSON.stringify(model.snapshot()));storageActive=true;}catch(e){storageActive=false;showToast('Browser storage unavailable. Export JSON to keep your work.','error');}}
  function showToast(message,type='success'){
    const el=document.getElementById('toast');
    el.textContent=message;el.className=`toast visible ${type}`;
    clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('visible'),4300);
  }
  function attempt(fn){
    try{const msg=fn();output=String(msg);save();render();showToast(msg, 'success');return true;}
    catch(err){output='ERROR: '+err.message;model.log(output,'error');save();render();showToast(err.message,'error');return false;}
  }
  function select(options,val,placeholder){
    return `${placeholder?`<option value="">${s(placeholder)}</option>`:''}${options.map(o=>`<option value="${escAttr(o.value)}" ${o.value===val?'selected':''}>${s(o.label)}</option>`).join('')}`;
  }
  const studentOptions=val=>select(model.students().map(x=>({value:x.id,label:`${x.id} — ${x.name}`})),val,'Choose a student');
  const courseOptions=val=>select(model.courses().map(x=>({value:x.code,label:`${x.code} — ${x.title}`})),val,'Choose a course');
  const field=(label,name,el)=>`<div class="field"><label for="${name}">${label}</label>${el}</div>`;
  const input=(name,placeholder,type='text',value='',opts='')=>`<input id="${name}" name="${name}" type="${type}" placeholder="${escAttr(placeholder)}" value="${escAttr(value)}" ${opts} required/>`;
  const selectField=(label,name,options,value)=>field(label,name,`<select id="${name}" name="${name}" required>${select(options,value)}</select>`);
  const heading=(kicker,title,description,actions='')=>`<div class="heading-row"><div><div class="eyebrow">${s(kicker)}</div><h1>${s(title)}</h1><p class="subtitle">${s(description)}</p></div>${actions?`<div class="heading-actions">${actions}</div>`:''}</div>`;
  const cardTitle=(title,right='')=>`<div class="card-title-row"><h2>${s(title)}</h2>${right}</div>`;
  const pill=(name,type='gray')=>`<span class="pill ${type}">${s(name)}</span>`;
  const outputBox=()=>`<div class="output-box"><div class="output-top"><span>● &nbsp; LIVE SYSTEM OUTPUT</span><span class="output-dots">•••</span></div><pre id="liveOutput">${s(output)}</pre></div>`;
  const studentName = id => model.student(id)?.name||id;
  function render(){
    bread.textContent=pageNames[page];
    document.querySelectorAll('[data-page]').forEach(btn=>btn.classList.toggle('active',btn.dataset.page===page));
    selectedStudent=model.student(selectedStudent)?selectedStudent:model.students()[0]?.id||'';
    selectedCourse=model.course(selectedCourse)?selectedCourse:model.courses()[0]?.code||'';
    const screens={dashboard,students,courses,registration,results,ranking,activity,about};
    app.innerHTML=screens[page]();
  }
  function overviewStats(){
    const t=model.stats();
    const items=[['Total Students',t.students,'Registered learners','♙',''],['Active Courses',t.courses,'Available course catalog','▤','teal'],['Enrollments',t.enrolled,'Currently allocated seats','✓','orange'],['On Waitlist',t.waiting,'Pending FIFO requests','◷','pink']];
    return `<div class="stats-grid">${items.map(v=>`<article class="stat-card"><div class="stat-top"><span>${v[0]}</span><span class="stat-icon ${v[4]}">${v[3]}</span></div><div class="stat-value">${v[1]}</div><div class="stat-note">${v[2]}</div></article>`).join('')}</div>`;
  }
  function recentEvents(limit=5){
    const events=model.state.events.slice(0,limit);
    return events.length?events.map(e=>`<div class="activity-item"><span class="event-dot ${e.kind==='info'?'':escape(e.kind)}"></span><div><p>${s(e.message)}</p><time>${s(when(e.time))}</time></div></div>`).join(''):'<div class="empty">No activity yet.</div>';
  }
  function dashboard(){
    const courses=model.courses();
    return `${heading('YOUR ACADEMIC WORKSPACE','Academic Dashboard','Manage course enrollments, academic results and student records in one place.',`<button class="btn btn-quiet" data-action="reset">↻ Reset sample data</button>`)}
    <div class="welcome-banner"><div><span class="banner-kicker">CODE RUSHERS · PBL WORKING MODEL</span><h2>See the entire workflow in action.</h2><p>Use the live registration simulator below, or run the mentor demonstration to automatically test prerequisite rejection, registration, waitlist, promotion and undo.</p></div><button class="btn" data-action="mentorDemo">▶ Run mentor demo</button></div>
    ${overviewStats()}
    <div class="two-col">
      <div><section class="card">${cardTitle('Live input → output simulator',pill('INTERACTIVE','good'))}
        <p class="subtitle" style="margin:-7px 0 19px">Choose any student and course. Every click updates the same academic records used throughout the app.</p>
        <form data-form="registration" class="form-grid">
          ${field('Student ID','quickStudent',`<select id="quickStudent" name="student" required>${studentOptions(selectedStudent)}</select>`)}
          ${field('Course code','quickCourse',`<select id="quickCourse" name="course" required>${courseOptions(selectedCourse)}</select>`)}
          <div class="form-actions"><button type="submit" name="intent" value="check" class="btn btn-quiet">◈ Check eligibility</button><button type="submit" name="intent" value="register" class="btn btn-primary">+ Register student</button><button type="submit" name="intent" value="cancel" class="btn">× Cancel registration</button></div>
        </form>${outputBox()}
      </section>
      <section class="card">${cardTitle('Course seat availability','')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Course</th><th>Seats filled</th><th>Availability</th></tr></thead><tbody>${courses.map(c=>`<tr><td><span class="mono">${s(c.code)}</span><div class="small muted">${s(c.title)}</div></td><td><div class="progress-track"><div class="progress-fill" style="width:${Math.min(100,c.enrolled.length/c.capacity*100)}%"></div></div><span class="small muted">${c.enrolled.length} / ${c.capacity}</span></td><td>${pill(c.capacity===c.enrolled.length?'Full':`${c.capacity-c.enrolled.length} left`,c.capacity===c.enrolled.length?'warn':'good')}</td></tr>`).join('')}</tbody></table></div></section></div>
      <div><section class="card">${cardTitle('Try this 5-step demo',pill('MENTOR READY'))}
        <div class="steps">${[
          ['S1003 → DSA201','Rejected: Programming prerequisite not passed.'],
          ['S1001 → DSA201','Accepted: one seat gets occupied.'],
          ['S1002 → DSA201','Course is full: added to FIFO waitlist.'],
          ['Cancel S1001','S1002 is automatically promoted.'],
          ['85 → 95 → Undo','GPA changes, then previous marks restored.']
        ].map((v,i)=>`<div class="step"><span class="step-num">${i+1}</span><div><strong>${s(v[0])}</strong><p>${s(v[1])}</p></div></div>`).join('')}</div>
        <div class="separator"></div><button class="btn btn-dark btn-block" data-action="mentorDemo">▶ Run all 5 actions</button>
      </section><section class="card">${cardTitle('Recent activity',`<button class="link-btn" data-page="activity">View all →</button>`)}${recentEvents(5)}</section></div>
    </div><div class="footer-note">Offline academic workflow demo · Fictional sample data · Local browser storage · University grading policy not claimed</div>`;
  }
  function students(){
    const edit=editingStudent?model.student(editingStudent):null;
    const rows=model.ranking().sort((a,b)=>studentSort==='name'?a.name.localeCompare(b.name):studentSort==='gpa'?b.gpa-a.gpa||a.id.localeCompare(b.id):a.id.localeCompare(b.id));
    return `${heading('ADMINISTRATOR / MODULE 01','Student Management','Create, search, edit and delete UG or PG student records.')}
      <div class="two-col"><div><section class="card">${cardTitle('Student directory',pill(`${rows.length} STUDENTS`))}
        <div class="grid-top"><input class="search-input" id="studentSearch" type="search" placeholder="Search ID or student name..." aria-label="Search students"/><div class="field" style="max-width:160px"><select id="studentSort" aria-label="Sort students"><option value="id" ${studentSort==='id'?'selected':''}>Sort: Student ID</option><option value="name" ${studentSort==='name'?'selected':''}>Sort: Name</option><option value="gpa" ${studentSort==='gpa'?'selected':''}>Sort: GPA</option></select></div></div>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Student</th><th>Type</th><th>Semester</th><th>GPA</th><th>Actions</th></tr></thead><tbody id="studentRows">${rows.map(a=>`<tr data-search="${escAttr((a.id+' '+a.name+' '+a.program).toLowerCase())}"><td><div class="strong">${s(a.name)}</div><span class="mono">${s(a.id)}</span><div class="small muted">${s(a.program)}</div></td><td>${pill(a.type,a.type==='PG'?'warn':'gray')}</td><td>${a.semester}</td><td><strong>${fmt(a.gpa)}</strong></td><td><div class="table-actions"><button class="link-btn" data-action="editStudent" data-id="${escAttr(a.id)}">Edit</button><button class="link-btn danger" data-action="deleteStudent" data-id="${escAttr(a.id)}">Delete</button></div></td></tr>`).join('')}</tbody></table></div>
        ${rows.length?'':'<div class="empty">Add a student to begin.</div>'}
      </section></div>
      <div><section class="card">${cardTitle(edit?'Edit student details':'Add a new student',pill(edit?'UPDATE':'NEW'))}
        <form data-form="student" class="form-grid">
          ${field('Student ID', 'studentId', input('studentId','e.g. S2001','text',edit?.id||'','maxlength="31" '+(edit?'readonly':'')))}
          ${selectField('Category','studentType',[{value:'UG',label:'UG — Undergraduate'},{value:'PG',label:'PG — Postgraduate'}],edit?.type||'UG').replace('<select id="studentType"','<select id="studentType" '+(edit?'disabled':''))}
          ${field('Full name', 'studentName', input('studentName','e.g. Aanya Sharma','text',edit?.name||'','maxlength="79"'))}
          ${field('Program', 'studentProgram', input('studentProgram','e.g. BTech CSE','text',edit?.program||'','maxlength="79"'))}
          ${field('Semester', 'studentSemester', input('studentSemester','1 – 12','number',edit?.semester||3,'min="1" max="12"'))}
          <div class="form-actions"><button class="btn btn-primary" type="submit">${edit?'Save student changes':'+ Add student'}</button>${edit?'<button class="btn btn-quiet" type="button" data-action="cancelEditStudent">Cancel editing</button>':''}</div>
        </form><p class="note">Student IDs are unique. Grades use different demo rules for UG and PG. Deletion is blocked while registrations are active.</p>
      </section><section class="card">${cardTitle('Grading policies')}<div class="list-rows"><div class="list-row"><b>UG minimum pass</b>${pill('40 / 100','good')}</div><div class="list-row"><b>PG minimum pass</b>${pill('50 / 100','warn')}</div></div><p class="note">These are illustrative grading rules matching the C/C++ prototype, not official university policy.</p></section></div></div>`;
  }
  function courses(){
    const edit=editingCourse?model.course(editingCourse):null;
    const active=model.course(selectedCourse);
    return `${heading('ADMINISTRATOR / MODULE 02','Course Management','Define courses, seat limits and directed prerequisite relationships.')}
      <div class="two-col"><div><section class="card">${cardTitle('Course catalog',pill(`${model.courses().length} COURSES`))}
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Course</th><th>Credits</th><th>Seats</th><th>Waiting</th><th>Actions</th></tr></thead><tbody>${model.courses().map(c=>`<tr><td><div class="strong">${s(c.title)}</div><span class="mono">${s(c.code)}</span></td><td>${c.credits}</td><td>${c.enrolled.length} / ${c.capacity}</td><td>${c.waitlist.length}</td><td><div class="table-actions"><button class="link-btn" data-action="viewCourse" data-code="${escAttr(c.code)}">View</button><button class="link-btn" data-action="editCourse" data-code="${escAttr(c.code)}">Edit</button><button class="link-btn danger" data-action="deleteCourse" data-code="${escAttr(c.code)}">Delete</button></div></td></tr>`).join('')}</tbody></table></div>
      </section><section class="card">${cardTitle('Prerequisite graph',pill('DIRECTED ACYCLIC'))}<form class="form-grid" data-form="prereq"><div class="field"><label for="preCourse">Course</label><select id="preCourse" name="course" required>${courseOptions(selectedCourse)}</select></div><div class="field"><label for="preRequired">Requires completion of</label><select id="preRequired" name="needed" required>${courseOptions('PRG101')}</select></div><div class="form-actions"><button type="submit" name="intent" value="add" class="btn btn-primary">+ Add prerequisite</button><button type="submit" name="intent" value="remove" class="btn btn-quiet">− Remove link</button></div></form><p class="note">Graph DFS checks direct + indirect dependencies and prevents circular prerequisites.</p></section></div>
      <div><section class="card">${cardTitle(edit?'Edit course':'Add a new course',pill(edit?'UPDATE':'NEW'))}<form data-form="course" class="form-grid">
        ${field('Course code','courseCode',input('courseCode','e.g. AI401','text',edit?.code||'','maxlength="31" '+(edit?'readonly':'')))}
        ${field('Course title','courseTitle',input('courseTitle','e.g. Artificial Intelligence','text',edit?.title||'','maxlength="79"'))}
        ${field('Credits','courseCredits',input('courseCredits','1 – 10','number',edit?.credits??4,'min="1" max="10"'))}
        ${field('Capacity','courseCapacity',input('courseCapacity','1 – 10000','number',edit?.capacity??3,'min="1" max="10000"'))}
        <div class="form-actions"><button class="btn btn-primary" type="submit">${edit?'Save course changes':'+ Add course'}</button>${edit?'<button type="button" class="btn btn-quiet" data-action="cancelEditCourse">Cancel</button>':''}</div>
      </form></section><section class="card">${cardTitle('Selected course details',active?pill(active.code):'')}
        ${active?`<div class="registration-card"><div class="registration-head"><div><h3>${s(active.title)}</h3><p>Course code: <span class="mono">${s(active.code)}</span></p></div>${pill(`${active.capacity-active.enrolled.length} seats left`,active.enrolled.length>=active.capacity?'warn':'good')}</div><div class="registration-meta"><span>${active.credits} credits</span><span>${active.enrolled.length} enrolled</span><span>${active.waitlist.length} waiting</span></div></div><div class="small muted" style="margin-bottom:9px">Direct prerequisites</div><div>${active.prereqs.length?active.prereqs.map(p=>`<span class="chip">${s(p)}</span>`).join(''):pill('No prerequisites','gray')}</div><div class="separator"></div><div class="small muted" style="margin-bottom:8px">Enrolled students</div>${active.enrolled.length?active.enrolled.map(id=>`<div class="list-row"><b>${s(id)} · ${s(studentName(id))}</b>${pill('ENROLLED','good')}</div>`).join(''):'<div class="helper">No enrollments yet.</div>'}`:'<div class="empty">Add a course first.</div>'}</section></div></div>`;
  }
  function registration(){
    const active=model.course(selectedCourse), stu=model.student(selectedStudent);
    const items=stu?model.registrations(stu.id):[];
    return `${heading('STUDENT PORTAL / MODULE 03','Course Registration','Validate prerequisites, allocate seats and manage first-in-first-out waiting lists.')}
      <div class="two-col"><div><section class="card">${cardTitle('Register / cancel a course',pill('LIVE VALIDATION','good'))}
        <form data-form="registration" class="form-grid">
          ${field('Choose student','regStudent',`<select id="regStudent" name="student" required>${studentOptions(selectedStudent)}</select>`)}
          ${field('Choose course','regCourse',`<select id="regCourse" name="course" required>${courseOptions(selectedCourse)}</select>`)}
          <div class="form-actions"><button type="submit" name="intent" value="check" class="btn btn-quiet">◈ Check prerequisites</button><button type="submit" name="intent" value="register" class="btn btn-primary">+ Register</button><button type="submit" name="intent" value="cancel" class="btn btn-danger">× Cancel</button></div>
        </form>${outputBox()}
      </section><section class="card">${cardTitle('All available courses')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Course</th><th>Seats used</th><th>Waitlist</th><th>Prerequisites</th></tr></thead><tbody>${model.courses().map(c=>`<tr><td><span class="mono">${s(c.code)}</span><div class="small muted">${s(c.title)}</div></td><td>${c.enrolled.length} / ${c.capacity}</td><td>${c.waitlist.length}</td><td>${c.prereqs.length?c.prereqs.map(p=>`<span class="chip">${s(p)}</span>`).join(''):pill('None')}</td></tr>`).join('')}</tbody></table></div></section></div>
      <div><section class="card">${cardTitle(`${selectedCourse || 'Course'} · seat status`,active?pill(active.enrolled.length===active.capacity?'FULL':'OPEN',active.enrolled.length===active.capacity?'warn':'good'):'')}
        ${active?`<div class="registration-card"><div class="registration-head"><div><h3>${s(active.title)}</h3><p>${s(active.code)}</p></div><span class="gpa-text">${active.enrolled.length}/${active.capacity}</span></div><div class="progress-track" style="width:100%;margin-top:15px"><div class="progress-fill" style="width:${Math.min(100,active.enrolled.length/active.capacity*100)}%"></div></div><div class="registration-meta"><span>${active.capacity-active.enrolled.length} available seats</span><span>${active.waitlist.length} waiting</span></div></div><div class="small muted" style="margin-bottom:9px">FIFO waiting order (first registered = first promoted)</div>${active.waitlist.length?active.waitlist.map((sid,i)=>`<div class="list-row"><b>#${i+1} &nbsp; ${s(sid)}</b><small>${s(studentName(sid))}</small></div>`).join(''):'<div class="empty">No students on this waitlist.</div>'}`:'<div class="empty">No course selected.</div>'}
      </section><section class="card">${cardTitle(`${stu?.name||'Student'} · registrations`)}${items.length?items.map(it=>`<div class="list-row"><b class="mono">${s(it.code)}</b>${pill(it.status+(it.position?' #'+it.position:''),it.status==='ENROLLED'?'good':'warn')}</div>`).join(''):'<div class="empty">This student has no active registrations or waitlists.</div>'}</section></div></div>`;
  }
  function results(){
    const student=model.student(selectedStudent);
    const grades=student?model.state.results.filter(r=>r.student===student.id):[];
    const policy=student?studentObject(student):null;
    return `${heading('ACADEMIC STAFF / MODULE 04','Results & Grades','Enter examination marks, calculate credit-weighted GPA and undo the latest marks modification.',`<button class="btn btn-quiet" data-action="undo">↶ Undo last marks edit</button>`)}
      <div class="two-col"><div><section class="card">${cardTitle('Enter / update academic marks',pill('STAFF ACTION'))}
        <form class="form-grid" data-form="marks">
          ${field('Student ID','marksStudent',`<select id="marksStudent" name="student" required>${studentOptions(selectedStudent)}</select>`)}
          ${field('Course code','marksCourse',`<select id="marksCourse" name="course" required>${courseOptions(selectedCourse)}</select>`)}
          ${field('Marks scored (out of 100)','marksValue',input('marksValue','Enter marks from 0 to 100','number','','min="0" max="100" step="0.01"'))}
          <div class="form-actions"><button class="btn btn-primary" type="submit">✓ Save marks</button><button class="btn btn-quiet" type="button" data-action="undo">↶ Undo last edit</button></div>
        </form><p class="note">Updating passing marks to a failing mark is blocked if active registrations depend on that prerequisite.</p>${outputBox()}
      </section><section class="card">${cardTitle('Student academic results',`<span class="badge-icon">${student?s(student.type)+' STUDENT':'NO STUDENT'}</span>`)}
        <div class="field" style="max-width:300px;margin-bottom:15px"><label for="resultStudent">Show results for</label><select id="resultStudent" data-action="selectedStudent">${studentOptions(selectedStudent)}</select></div>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Course</th><th>Marks / 100</th><th>Grade points</th><th>Status</th></tr></thead><tbody>${grades.map(r=>`<tr><td><span class="mono">${s(r.course)}</span><div class="small muted">${s(model.course(r.course)?.title||'')}</div></td><td><strong>${r.marks}</strong></td><td>${policy.gradePoints(r.marks)} / 10</td><td>${pill(policy.passes(r.marks)?'PASS':'FAIL',policy.passes(r.marks)?'good':'bad')}</td></tr>`).join('')}</tbody></table></div>${grades.length?'':'<div class="empty">No examination results recorded.</div>'}
      </section></div>
      <div><section class="card">${cardTitle('Academic performance',pill('AUTOMATIC'))}<div class="stat-top">Credit-weighted GPA</div><div class="stat-value" style="font-size:45px">${student?fmt(model.gpa(student.id)):'0.00'}<span class="mini-info"> / 10</span></div><div class="progress-track" style="width:100%;height:9px"><div class="progress-fill" style="width:${student?model.gpa(student.id)*10:0}%"></div></div><div class="separator"></div><div class="list-row"><b>Pass threshold</b>${pill(student?(student.type==='UG'?'40 / 100':'50 / 100'):'—','good')}</div><div class="list-row"><b>Completed results</b>${pill(grades.length,'gray')}</div><div class="list-row"><b>Undo history</b>${pill(model.state.undo.length+' edits','gray')}</div><p class="note">Grade points: UG ≥40 passes, PG ≥50 passes. Weighted GPA considers recorded courses and credits. Demo grading only.</p></section><section class="card">${cardTitle('Latest marks changes')}<div class="helper">Undo works as a last-in-first-out stack. Clicking Undo restores the actual previous marks and recalculates rankings.</div><div class="separator"></div><button class="btn btn-dark btn-block" data-action="undo" ${model.state.undo.length?'':'disabled'}>↶ Undo most recent marks edit</button></section></div></div>`;
  }
  function ranking(){
    const rows=model.ranking();
    return `${heading('DSA / STUDENT PERFORMANCE','Academic Leaderboard','Compare student performance using calculated GPA and deterministic ID tie-breaking.',`<button class="btn btn-quiet" data-page="results">+ Update results</button>`)}
      <div class="stats-grid">${[
        ['Total ranked',rows.length,'Includes students with no results','♙',''],
        ['Highest GPA',rows.length?fmt(rows[0].gpa):'—','Top credit-weighted score','★','teal'],
        ['Average GPA',rows.length?fmt(rows.reduce((n,r)=>n+r.gpa,0)/rows.length):'—','Across all students','◈','orange'],
        ['Published results',model.stats().results,'Marked course records','✓','pink']
      ].map(v=>`<article class="stat-card"><div class="stat-top"><span>${s(v[0])}</span><span class="stat-icon ${v[4]}">${v[3]}</span></div><div class="stat-value">${s(v[1])}</div><div class="stat-note">${s(v[2])}</div></article>`).join('')}</div>
      <div class="two-col"><section class="card">${cardTitle('Ranked student directory',pill('GPA DESCENDING'))}<div class="table-wrap"><table class="data-table"><thead><tr><th>Rank</th><th>Student</th><th>Category</th><th>GPA / 10</th><th>Performance</th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td><span class="rank-num ${i===0?'first':i===1?'second':i===2?'third':''}">${i+1}</span></td><td><div class="strong">${s(r.name)}</div><span class="mono">${s(r.id)}</span></td><td>${pill(r.type)}</td><td><strong class="gpa-text">${fmt(r.gpa)}</strong></td><td><div class="score-bar"><div style="width:${Math.min(100,r.gpa*10)}%"></div></div></td></tr>`).join('')}</tbody></table></div></section><div><section class="card">${cardTitle('How rankings are calculated')}<div class="steps"><div class="step"><span class="step-num">1</span><div><strong>Retrieve recorded course marks</strong><p>Collect each student's results and corresponding course credits.</p></div></div><div class="step"><span class="step-num">2</span><div><strong>Apply UG or PG grading</strong><p>Use student-type policy to convert marks into grade points.</p></div></div><div class="step"><span class="step-num">3</span><div><strong>Calculate credit-weighted GPA</strong><p>Σ (grade point × credits) ÷ Σ credits.</p></div></div><div class="step"><span class="step-num">4</span><div><strong>Sort students by GPA</strong><p>Highest GPA first; student ID breaks ties predictably.</p></div></div></div></section><section class="card">${cardTitle('DSA relationship')}<p class="note">The native C/C++ CLI uses a custom C AVL-balanced binary search tree for its rankings. This offline browser demo reproduces the same results in JavaScript using an array sort, not the native AVL implementation.</p></section></div></div>`;
  }
  function activity(){
    return `${heading('SYSTEM / BACKUP','Activity & Data','Review every action, export a backup or restore saved records.',`<button class="btn btn-quiet" data-action="export">⇩ Export JSON</button><button class="btn btn-quiet" data-action="import">⇧ Import JSON</button>`)}
    <div class="two-col"><section class="card">${cardTitle('Activity log',pill(`${model.state.events.length} EVENTS`))}${recentEvents(100)}</section><div><section class="card">${cardTitle('Your data stays in this browser',pill(storageActive?'AUTO SAVE ON':'EXPORT RECOMMENDED',storageActive?'good':'warn'))}<p class="subtitle">Updates are automatically saved locally using your browser’s localStorage. You can also download or import a JSON snapshot of all students, courses, results, enrollments and waiting lists.</p><div class="separator"></div><div class="list-rows"><button class="btn btn-primary btn-block" data-action="export">⇩ Download backup.json</button><button class="btn btn-quiet btn-block" data-action="import">⇧ Import saved JSON</button></div></section><section class="card danger-zone">${cardTitle('Restart demonstration')}<p class="subtitle" style="margin:0 0 15px">Replace all current changes with the original fictional sample dataset. Recommended before showing the mentor demo.</p><button class="btn btn-danger" data-action="reset">↻ Reset demo data</button></section><section class="card">${cardTitle('Sample scenario')}<div class="demo-strip">Start with <strong>S1003 → DSA201</strong> (fails), then <strong>S1001 → DSA201</strong> (enrolled), then <strong>S1002 → DSA201</strong> (waitlisted). Cancel S1001 to automatically admit S1002.</div></section></div></div>`;
  }
  function about(){
    return `${heading('PBL / DOCUMENTATION','How the System Works','Know exactly what is happening behind every action you demonstrate.')}
    <div class="two-col"><div><section class="card">${cardTitle('Modules and input examples')}<div class="steps">${[
      ['Student Management','Enter student ID, name, program, semester and UG/PG category.'],
      ['Course Management','Enter course code, title, credits, seat limit and prerequisite codes.'],
      ['Result Management','Select student, select course, enter marks from 0 to 100, then view GPA.'],
      ['Registration','Select student and course; prerequisite DFS checks results; available seat = enroll, otherwise waitlist.'],
      ['Ranking & Undo','Sort calculated GPAs; undo reverses the latest supported marks edit.']
    ].map((x,i)=>`<div class="step"><span class="step-num">${i+1}</span><div><strong>${s(x[0])}</strong><p>${s(x[1])}</p></div></div>`).join('')}</div></section><section class="card">${cardTitle('Original project architecture')}<div class="demo-strip"><strong>Original native app:</strong> C11 foundational data structures + C++17 OOP domain classes, connected with <span class="code">extern "C"</span>, data stored in local binary records.<br/><br/><strong>This web app:</strong> JavaScript implementation of the equivalent user-facing academic workflows, storing browser data locally. It does not run or compile the C/C++ modules inside the browser.</div></section></div>
      <div><section class="card">${cardTitle('Concept-to-feature mapping')}<div class="list-rows">${[
        ['Hash table','Student / course ID lookup in C/C++ CLI'],
        ['Graph + DFS','Validate transitive prerequisites'],
        ['Queue / FIFO','Waiting list and automatic promotion'],
        ['Stack / LIFO','Marks update undo'],
        ['Linked list','Course enrollments in the C/C++ CLI'],
        ['AVL / BST','Academic rankings in C/C++ CLI'],
        ['OOP polymorphism','Different UG and PG grading methods'],
        ['File handling','Binary .dat in CLI; JSON/localStorage on web']
      ].map(x=>`<div class="list-row"><b>${s(x[0])}</b><small style="text-align:right">${s(x[1])}</small></div>`).join('')}</div></section><section class="card">${cardTitle('For your mentor')}<p class="subtitle">The easiest demonstration is on Overview: click <b>Run mentor demo</b> to execute real academic operations and show the outputs. For interactive proof, go to Registration and enter your own IDs and course codes.</p><div class="separator"></div><button class="btn btn-primary btn-block" data-page="dashboard">← Open interactive demo</button></section></div></div>`;
  }
  function mentorDemo(){
    model=new AcademicSystem(initial());
    let lines=['===== ACTUAL MENTOR DEMO OUTPUT ====='];
    const doOne=(label,fn)=>{try{lines.push('\nINPUT: '+label,'OUTPUT: '+fn());}catch(err){lines.push('\nINPUT: '+label,'OUTPUT: REJECTED — '+err.message);model.log(label+' → REJECTED: '+err.message,'warning');}};
    doOne('Register S1003 in DSA201',()=>model.register('S1003','DSA201'));
    doOne('Register S1001 in DSA201',()=>model.register('S1001','DSA201'));
    doOne('Register S1002 in DSA201',()=>model.register('S1002','DSA201'));
    doOne('Cancel S1001 in DSA201',()=>model.cancel('S1001','DSA201'));
    doOne('Set S1001 / PRG101 marks to 95',()=>model.setMarks('S1001','PRG101',95));
    doOne('Undo last marks edit',()=>model.undoMarks());
    lines.push('\nRESULT: '+model.registrations('S1002').map(x=>x.code+' '+x.status).join(', '));
    lines.push('FINAL S1001 GPA: '+fmt(model.gpa('S1001'))+'/10');
    output=lines.join('\n');page='dashboard';selectedStudent='S1002';selectedCourse='DSA201';editingStudent=null;editingCourse=null;save();render();showToast('Mentor demo finished: all six live operations executed!','success');
  }
  function useForm(form,submitter){
    const data=Object.fromEntries(new FormData(form).entries());
    const name=form.dataset.form, intent=submitter?.value||'register';
    if(name==='student'){
      if(editingStudent){const target=editingStudent;if(attempt(()=>model.updateStudent(target,{name:data.studentName,program:data.studentProgram,semester:data.studentSemester}))){editingStudent=null;render();}}
      else attempt(()=>model.addStudent({id:data.studentId,name:data.studentName,program:data.studentProgram,semester:data.studentSemester,type:data.studentType}));
      return;
    }
    if(name==='course'){
      const obj={code:data.courseCode,title:data.courseTitle,credits:data.courseCredits,capacity:data.courseCapacity};
      if(editingCourse){const target=editingCourse;if(attempt(()=>model.updateCourse(target,obj))){editingCourse=null;render();}}
      else attempt(()=>model.addCourse(obj));
      return;
    }
    if(name==='prereq'){
      selectedCourse=data.course;
      attempt(()=>intent==='remove'?model.removePrereq(data.course,data.needed):model.addPrereq(data.course,data.needed));return;
    }
    if(name==='registration'){
      selectedStudent=data.student;selectedCourse=data.course;
      if(intent==='check'){
        attempt(()=>{const e=model.eligibility(data.student,data.course);return `${data.student} → ${data.course}: ${e.message}`;});
      }else if(intent==='cancel') attempt(()=>model.cancel(data.student,data.course));
      else attempt(()=>model.register(data.student,data.course));
      return;
    }
    if(name==='marks'){
      selectedStudent=data.student;selectedCourse=data.course;
      attempt(()=>model.setMarks(data.student,data.course,data.marksValue));return;
    }
  }
  document.addEventListener('submit',e=>{
    if(!e.target.matches('form[data-form]'))return;
    e.preventDefault();useForm(e.target,e.submitter);
  });
  document.addEventListener('click',e=>{
    const nav=e.target.closest('button[data-page]');
    if(nav){page=nav.dataset.page;document.getElementById('sidebar').classList.remove('open');render();return;}
    const b=e.target.closest('button[data-action]');if(!b)return;
    const a=b.dataset.action;
    if(a==='export'){
      const blob=new Blob([JSON.stringify(model.snapshot(),null,2)],{type:'application/json'});
      const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='CodeRushers_Academic_Backup.json';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);showToast('Backup downloaded successfully.');return;
    }
    if(a==='import'){fileInput.click();return;}
    if(a==='reset'){
      if(!confirm('Reset all data to the original sample records? This will erase unsaved custom changes.'))return;
      model=new AcademicSystem(initial());selectedStudent='S1001';selectedCourse='DSA201';editingStudent=null;editingCourse=null;output='Demo records reset. Try registering S1003 → DSA201.';save();render();showToast('Fictional sample data restored.');return;
    }
    if(a==='mentorDemo'){mentorDemo();return;}
    if(a==='undo'){attempt(()=>model.undoMarks());return;}
    if(a==='editStudent'){editingStudent=b.dataset.id;page='students';render();return;}
    if(a==='cancelEditStudent'){editingStudent=null;render();return;}
    if(a==='deleteStudent'){
      const sid=b.dataset.id;
      if(confirm(`Delete ${sid}? All its results will also be deleted.`))attempt(()=>model.deleteStudent(sid));return;
    }
    if(a==='editCourse'){editingCourse=b.dataset.code;selectedCourse=b.dataset.code;page='courses';render();return;}
    if(a==='cancelEditCourse'){editingCourse=null;render();return;}
    if(a==='viewCourse'){selectedCourse=b.dataset.code;render();return;}
    if(a==='deleteCourse'){
      const code=b.dataset.code;
      if(confirm(`Delete course ${code}?`))attempt(()=>model.deleteCourse(code));return;
    }
  });
  document.addEventListener('change',e=>{
    if(e.target.id==='studentSort'){studentSort=e.target.value;render();return;}
    if(e.target.dataset.action==='selectedStudent'){selectedStudent=e.target.value;render();return;}
    if(e.target.id==='regStudent'||e.target.id==='quickStudent'||e.target.id==='marksStudent')selectedStudent=e.target.value;
    if(e.target.id==='regCourse'||e.target.id==='quickCourse'||e.target.id==='marksCourse')selectedCourse=e.target.value;
  });
  document.addEventListener('input',e=>{
    if(e.target.id!=='studentSearch')return;
    const q=e.target.value.toLowerCase().trim();
    document.querySelectorAll('#studentRows tr[data-search]').forEach(tr=>tr.hidden=!tr.dataset.search.includes(q));
  });
  fileInput.addEventListener('change',async e=>{
    const f=e.target.files[0];if(!f)return;
    try{
      if(f.size>5*1024*1024)throw new Error('Backup file is too large (max 5 MB).');
      const raw=JSON.parse(await f.text());
      const proposed=new AcademicSystem(raw);
      if(!confirm(`Import backup containing ${proposed.students().length} students and ${proposed.courses().length} courses? This replaces current data.`))return;
      model=proposed;editingStudent=null;editingCourse=null;output='Imported a valid JSON backup. All course and student relationships verified.';
      model.log('Validated JSON backup imported.','success');save();render();showToast('Academic backup restored successfully.');
    }catch(err){showToast('Import rejected: '+err.message,'error');}
    finally{fileInput.value='';}
  });
  document.getElementById('menuButton').addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
  init();
})();
