// DemoData.hpp
// Optional fictional sample data for a quick demonstration.
//
// The loader only calls the public AcademicManager API, so the sample data
// goes through exactly the same validation as data typed at the CLI. All
// names and IDs are invented for the demo.
#ifndef DEMO_DATA_HPP
#define DEMO_DATA_HPP

#include "AcademicManager.hpp"

namespace academic {

// Refuses to run unless the system is empty, so it never mixes with real data.
OpResult loadSampleData(AcademicManager& manager);

}  // namespace academic

#endif  // DEMO_DATA_HPP
