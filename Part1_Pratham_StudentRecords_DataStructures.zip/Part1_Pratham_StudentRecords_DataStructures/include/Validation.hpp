// Validation.hpp
// Input normalisation and validation rules shared by the whole C++ layer.
#ifndef VALIDATION_HPP
#define VALIDATION_HPP

#include <string>

namespace academic {

// Limits chosen to fit the fixed-size C buffers (DS_KEY_LEN / DS_NAME_LEN).
constexpr std::size_t kMaxIdLength = 15;
constexpr std::size_t kMinIdLength = 2;
constexpr std::size_t kMaxNameLength = 47;
constexpr std::size_t kMaxProgramLength = 31;
constexpr int kMinCredits = 1;
constexpr int kMaxCredits = 6;
constexpr int kMinCapacity = 1;
constexpr int kMaxCapacity = 500;

std::string trim(const std::string& text);
std::string toUpper(const std::string& text);

// IDs and course codes are trimmed and upper-cased: " s101 " -> "S101".
std::string normalizeId(const std::string& raw);

// 2-15 characters from A-Z, 0-9, '-' or '_' (call on a normalised ID).
bool isValidId(const std::string& id);

// 1..maxLength printable characters, not only spaces.
bool isValidText(const std::string& text, std::size_t maxLength);

}  // namespace academic

#endif  // VALIDATION_HPP
