// Student.hpp
// Abstract Student base class with UG and PG specialisations.
//
// The two derived classes share identity data and result storage, and differ
// in academic policy: grade bands, pass mark, good-standing threshold and the
// number of semesters. These policies are DEMONSTRATION DEFAULTS chosen for
// this project (see docs/algorithms.md); they are NOT Graphic Era University's
// official grading scheme. They live in one table each (Student.cpp) so they
// can be changed in a single place.
#ifndef STUDENT_HPP
#define STUDENT_HPP

#include <string>
#include <vector>

#include "Result.hpp"

namespace academic {

enum class StudentCategory { UG = 1, PG = 2 };

struct GradeBand {
    int minCentiMarks;  // lowest mark (x100) that earns this band
    const char* letter;
    int gradePoint;
};

struct GradingPolicy {
    const char* name;
    int passCentiMarks;              // below this the course is failed
    std::vector<GradeBand> bands;    // highest band first
    double goodStandingCgpa;         // CGPA needed for "good standing"
    int maxSemester;
};

const GradingPolicy& undergraduatePolicy();
const GradingPolicy& postgraduatePolicy();

class Student {
public:
    Student(std::string id, std::string name, std::string program, int semester);
    virtual ~Student() = default;  // deleting through Student* is safe

    Student(const Student&) = delete;
    Student& operator=(const Student&) = delete;

    // ---- identity (read-only outside the AcademicManager) ----
    const std::string& id() const { return id_; }
    const std::string& name() const { return name_; }
    const std::string& program() const { return program_; }
    int semester() const { return semester_; }

    // ---- polymorphic academic policy ----
    virtual StudentCategory category() const = 0;
    virtual std::string categoryName() const = 0;
    virtual const GradingPolicy& gradingPolicy() const = 0;
    virtual GradeInfo evaluate(int centiMarks) const = 0;
    virtual std::string academicStanding(double cgpa) const = 0;
    virtual int maxSemester() const = 0;

    // ---- results (computed with the virtual evaluate()) ----
    const std::vector<Result>& results() const { return results_; }
    const Result* findResult(const std::string& courseCode) const;
    bool hasResults() const { return !results_.empty(); }
    bool hasPassed(const std::string& courseCode) const;
    double cgpa() const;          // credit-weighted mean of grade points
    int creditsAttempted() const;
    int creditsEarned() const;    // credits of passed courses only

    // ---- mutators: the AcademicManager is the only caller, because it
    //      hands out const Student* to everyone else ----
    void setName(const std::string& name);
    void setProgram(const std::string& program);
    void setSemester(int semester);
    void upsertResult(const std::string& courseCode, int centiMarks, int credits);
    bool removeResult(const std::string& courseCode);

protected:
    // Shared band lookup used by both derived evaluate() implementations.
    static GradeInfo applyPolicy(const GradingPolicy& policy, int centiMarks);

private:
    Result* findResultMutable(const std::string& courseCode);

    std::string id_;
    std::string name_;
    std::string program_;
    int semester_;
    std::vector<Result> results_;
};

class UGStudent final : public Student {
public:
    UGStudent(std::string id, std::string name, std::string program, int semester);

    StudentCategory category() const override { return StudentCategory::UG; }
    std::string categoryName() const override { return "UG"; }
    const GradingPolicy& gradingPolicy() const override { return undergraduatePolicy(); }
    GradeInfo evaluate(int centiMarks) const override;
    std::string academicStanding(double cgpa) const override;
    int maxSemester() const override { return undergraduatePolicy().maxSemester; }
};

class PGStudent final : public Student {
public:
    PGStudent(std::string id, std::string name, std::string program, int semester);

    StudentCategory category() const override { return StudentCategory::PG; }
    std::string categoryName() const override { return "PG"; }
    const GradingPolicy& gradingPolicy() const override { return postgraduatePolicy(); }
    GradeInfo evaluate(int centiMarks) const override;
    std::string academicStanding(double cgpa) const override;
    int maxSemester() const override { return postgraduatePolicy().maxSemester; }
};

}  // namespace academic

#endif  // STUDENT_HPP
