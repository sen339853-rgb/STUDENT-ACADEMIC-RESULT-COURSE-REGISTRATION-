/*
 * ds_common.h
 * Shared constants and status codes for the pure C data-structure layer.
 *
 * Every C module returns one of the DS_* status codes so that the C++ layer
 * can translate failures into readable messages without exceptions ever
 * crossing the C/C++ boundary.
 */
#ifndef DS_COMMON_H
#define DS_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

/* Maximum key length (student ID / course code) including the '\0'. */
#define DS_KEY_LEN 16
/* Maximum name/title length used by sortable records, including '\0'. */
#define DS_NAME_LEN 48

typedef enum DSStatus {
    DS_OK = 0,
    DS_ERR_ALLOC = -1,      /* malloc/calloc/realloc returned NULL        */
    DS_ERR_NOT_FOUND = -2,  /* key / vertex / element does not exist       */
    DS_ERR_DUPLICATE = -3,  /* key / edge already present                  */
    DS_ERR_INVALID = -4,    /* bad argument (NULL pointer, empty key ...)  */
    DS_ERR_EMPTY = -5,      /* pop/dequeue/peek on an empty container      */
    DS_ERR_CYCLE = -6,      /* edge would create a cycle in the DAG        */
    DS_ERR_SELF_LOOP = -7   /* edge from a vertex to itself                */
} DSStatus;

/* Human-readable text for a status code (static string, never freed). */
const char *ds_status_text(int status);

/* Safe bounded copy: always NUL-terminates, returns DS_ERR_INVALID if the
 * source is NULL, empty, or does not fit into dst_size bytes. */
int ds_copy_key(char *dst, const char *src, unsigned long dst_size);

#ifdef __cplusplus
}
#endif

#endif /* DS_COMMON_H */
