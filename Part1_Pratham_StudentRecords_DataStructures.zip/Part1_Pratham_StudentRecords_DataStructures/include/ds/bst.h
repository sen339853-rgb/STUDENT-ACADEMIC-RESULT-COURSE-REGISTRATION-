/*
 * bst.h
 * AVL-balanced Binary Search Tree used for academic ranking.
 *
 * Each node stores (score, student ID). The score is the CGPA multiplied by
 * 100 and rounded (8.25 -> 825), so equal CGPAs compare exactly equal.
 *
 * Ordering (the BST property):
 *   lower score  -> left,  higher score -> right;
 *   equal score  -> the LARGER ID goes left.
 * Consequently a REVERSE inorder walk (right, node, left) visits students
 * from the highest CGPA to the lowest, and students with an equal CGPA come
 * out in ascending ID order - the deterministic tie-break of the ranking.
 * A normal inorder walk gives the opposite (lowest CGPA first).
 *
 * Every node also stores the size of its subtree, which lets the tree answer
 * "how many students have a strictly higher CGPA?" (rank) in O(log n).
 *
 * Why AVL: after each insert/delete the tree re-balances with rotations so
 * the heights of the two subtrees of any node differ by at most 1. That keeps
 * the height <= ~1.44 log2(n+2), so search, insert and delete are O(log n)
 * in the WORST case (a plain BST degrades to O(n) for sorted input).
 */
#ifndef BST_H
#define BST_H

#include <stddef.h>
#include "ds/ds_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct AVLTree AVLTree;

typedef struct AVLEntry {
    int score;
    char id[DS_KEY_LEN];
} AVLEntry;

AVLTree *avl_create(void);
void avl_destroy(AVLTree *tree);
void avl_clear(AVLTree *tree);

int avl_insert(AVLTree *tree, int score, const char *id);
int avl_remove(AVLTree *tree, int score, const char *id);
int avl_contains(const AVLTree *tree, int score, const char *id);

size_t avl_size(const AVLTree *tree);
int avl_height(const AVLTree *tree);           /* empty tree -> 0 */

/* Traversals copy up to max entries into out[] and return how many. */
size_t avl_inorder(const AVLTree *tree, AVLEntry *out, size_t max);
size_t avl_reverse_inorder(const AVLTree *tree, AVLEntry *out, size_t max);

/* Number of entries whose score is strictly greater than score: O(log n). */
size_t avl_count_above(const AVLTree *tree, int score);

/* Entries with score >= min_score, highest first. Subtrees that cannot
 * contain qualifying scores are skipped (ordered retrieval). */
size_t avl_collect_at_least(const AVLTree *tree, int min_score, AVLEntry *out, size_t max);

/* Self-check used by tests: verifies ordering, AVL balance, stored heights
 * and subtree sizes. Returns 1 when every invariant holds. */
int avl_validate(const AVLTree *tree);

#ifdef __cplusplus
}
#endif

#endif /* BST_H */
