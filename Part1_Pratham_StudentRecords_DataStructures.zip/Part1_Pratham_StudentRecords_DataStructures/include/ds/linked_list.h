/*
 * linked_list.h
 * Singly linked list of (key, value) pairs with head and tail pointers.
 *
 * Used in two places in the project:
 *   1. Separate chaining inside the hash table (one list per bucket).
 *   2. Course rosters: the ordered list of student IDs enrolled in a course.
 *
 * The list owns its nodes. Keys are copied into the node, so callers never
 * have to keep their own strings alive.
 *
 * Complexity: push_back/push_front O(1) (tail pointer), find/remove O(n),
 * traversal O(n), destroy O(n). Space: one node per element.
 */
#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stddef.h>
#include "ds/ds_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct LinkedList LinkedList; /* opaque list handle */
typedef struct LLNode LLNode;         /* opaque node, used only as a cursor */

LinkedList *ll_create(void);
void ll_destroy(LinkedList *list);            /* frees every node + list    */
void ll_clear(LinkedList *list);              /* frees nodes, keeps list    */

int ll_push_back(LinkedList *list, const char *key, int value);
int ll_push_front(LinkedList *list, const char *key, int value);
int ll_remove(LinkedList *list, const char *key);  /* first match only      */
int ll_find(const LinkedList *list, const char *key, int *out_value);
int ll_contains(const LinkedList *list, const char *key);
int ll_set_value(LinkedList *list, const char *key, int value);
size_t ll_size(const LinkedList *list);

/* Read-only traversal cursor:
 *   for (n = ll_first(list); n != NULL; n = ll_next(n)) ll_node_key(n) ...
 * Cursors are invalidated by any modification of the list. */
const LLNode *ll_first(const LinkedList *list);
const LLNode *ll_next(const LLNode *node);
const char *ll_node_key(const LLNode *node);
int ll_node_value(const LLNode *node);

#ifdef __cplusplus
}
#endif

#endif /* LINKED_LIST_H */
