/*
 * hash_table.h
 * String-keyed hash table with separate chaining (one linked list per bucket).
 *
 * Maps a unique key (student ID or course code) to an int value. In this
 * project the value is the "slot" of the record inside the C++ record store,
 * so the C layer never holds pointers to C++ objects.
 *
 * Hash function: 32-bit FNV-1a over the key bytes, reduced modulo the bucket
 * count. Collisions are resolved by appending to that bucket's linked list.
 * When the load factor (size / buckets) would exceed HT_MAX_LOAD_FACTOR the
 * table doubles its bucket array and rehashes every key.
 *
 * Complexity: insert/find/remove are O(1) on average (expected chain length
 * is the load factor, kept <= 0.75). The worst case is O(n), when every key
 * lands in one bucket - hashing does not guarantee O(1) worst case.
 * Resizing is O(n) but happens rarely, so insert is amortised O(1).
 */
#ifndef HASH_TABLE_H
#define HASH_TABLE_H

#include <stddef.h>
#include "ds/ds_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define HT_MAX_LOAD_FACTOR 0.75

typedef struct HashTable HashTable;

HashTable *ht_create(size_t initial_buckets);   /* 0 -> default of 16 */
void ht_destroy(HashTable *table);
void ht_clear(HashTable *table);

int ht_insert(HashTable *table, const char *key, int value); /* no dupes */
int ht_find(const HashTable *table, const char *key, int *out_value);
int ht_contains(const HashTable *table, const char *key);
int ht_update(HashTable *table, const char *key, int value);
int ht_remove(HashTable *table, const char *key);

size_t ht_size(const HashTable *table);
size_t ht_bucket_count(const HashTable *table);
double ht_load_factor(const HashTable *table);
size_t ht_longest_chain(const HashTable *table);
size_t ht_colliding_buckets(const HashTable *table); /* buckets with >1 key */
size_t ht_bucket_index(const HashTable *table, const char *key);

unsigned long ht_hash_string(const char *key);  /* FNV-1a, 32-bit */

#ifdef __cplusplus
}
#endif

#endif /* HASH_TABLE_H */
