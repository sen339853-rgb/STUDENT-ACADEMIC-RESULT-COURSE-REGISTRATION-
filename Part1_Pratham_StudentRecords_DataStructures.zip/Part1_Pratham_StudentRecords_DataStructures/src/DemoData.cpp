// DemoData.cpp
#include "DemoData.hpp"

namespace academic {

OpResult loadSampleData(AcademicManager& m) {
    if (!m.isEmpty()) {
        return OpResult{false, "Sample data can only be loaded into an empty system."};
    }
    struct S { StudentCategory cat; const char* id; const char* name; const char* program; int sem; };
    const S students[] = {
        {StudentCategory::UG, "UG26001", "Aarav Example", "B.Tech CSE", 3},
        {StudentCategory::UG, "UG26002", "Bhavna Sample", "B.Tech CSE", 3},
        {StudentCategory::UG, "UG26003", "Chirag Demo", "B.Tech CSE", 3},
        {StudentCategory::UG, "UG26004", "Diya Placeholder", "B.Tech CSE", 1},
        {StudentCategory::PG, "PG26001", "Esha Fictional", "M.Tech CSE", 1},
        {StudentCategory::PG, "PG26002", "Farhan Testcase", "M.Tech CSE", 2},
    };
    struct C { const char* code; const char* title; int credits; int capacity; };
    const C courses[] = {
        {"CS101", "Programming Fundamentals", 4, 60},
        {"MA101", "Engineering Mathematics I", 4, 60},
        {"CS201", "Data Structures in C", 4, 2},
        {"CS202", "Object Oriented Programming in C++", 3, 40},
        {"CS301", "Design and Analysis of Algorithms", 4, 30},
        {"CS401", "Advanced Algorithms", 3, 20},
    };
    struct P { const char* course; const char* prereq; };
    const P prereqs[] = {
        {"CS201", "CS101"}, {"CS202", "CS101"}, {"CS301", "CS201"}, {"CS301", "MA101"}, {"CS401", "CS301"},
    };
    struct R { const char* student; const char* course; double marks; };
    const R results[] = {
        {"UG26001", "CS101", 86}, {"UG26001", "MA101", 78},
        {"UG26002", "CS101", 72}, {"UG26002", "MA101", 64},
        {"UG26003", "CS101", 42}, {"UG26003", "MA101", 55},  // 42: UG pass, would fail under PG rules
        {"PG26001", "CS101", 91}, {"PG26001", "CS201", 47},  // 47: PG fail (PG pass mark is 50)
        {"PG26002", "CS101", 88}, {"PG26002", "CS201", 81}, {"PG26002", "MA101", 70},
    };

    for (const S& s : students) {
        OpResult r = m.addStudent(s.cat, s.id, s.name, s.program, s.sem);
        if (!r.ok) return r;
    }
    for (const C& c : courses) {
        OpResult r = m.addCourse(c.code, c.title, c.credits, c.capacity);
        if (!r.ok) return r;
    }
    for (const P& p : prereqs) {
        OpResult r = m.addPrerequisite(p.course, p.prereq);
        if (!r.ok) return r;
    }
    for (const R& r : results) {
        OpResult res = m.recordMarks(r.student, r.course, r.marks);
        if (!res.ok) return res;
    }
    // Sample marks are setup data, not a staff edit that should be undoable.
    m.clearUndoHistory();
    return OpResult{true, "Loaded 6 fictional students, 6 courses, 5 prerequisite links and 11 results."};
}

}  // namespace academic
