// Validation.cpp
#include "Validation.hpp"

#include <cctype>

namespace academic {

std::string trim(const std::string& text) {
    std::size_t begin = 0;
    std::size_t end = text.size();
    while (begin < end && std::isspace(static_cast<unsigned char>(text[begin]))) {
        ++begin;
    }
    while (end > begin && std::isspace(static_cast<unsigned char>(text[end - 1]))) {
        --end;
    }
    return text.substr(begin, end - begin);
}

std::string toUpper(const std::string& text) {
    std::string out = text;
    for (char& c : out) {
        c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    }
    return out;
}

std::string normalizeId(const std::string& raw) {
    return toUpper(trim(raw));
}

bool isValidId(const std::string& id) {
    if (id.size() < kMinIdLength || id.size() > kMaxIdLength) {
        return false;
    }
    for (char c : id) {
        const bool ok = (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_';
        if (!ok) {
            return false;
        }
    }
    return true;
}

bool isValidText(const std::string& text, std::size_t maxLength) {
    if (text.empty() || text.size() > maxLength || trim(text).empty()) {
        return false;
    }
    for (char c : text) {
        if (!std::isprint(static_cast<unsigned char>(c))) {
            return false;
        }
    }
    return true;
}

}  // namespace academic
