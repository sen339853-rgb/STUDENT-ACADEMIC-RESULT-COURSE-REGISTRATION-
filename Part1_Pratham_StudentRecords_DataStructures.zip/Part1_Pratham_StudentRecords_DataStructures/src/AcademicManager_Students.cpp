// AcademicManager_Students.cpp
// Module A - student records.
#include "AcademicManager.hpp"

#include <cmath>
#include <cstdio>
#include <stdexcept>

#include "AcademicManagerInternal.hpp"
#include "Validation.hpp"
#include "ds/searching_sorting.h"

namespace academic {

using detail::success;
using detail::failure;
using detail::twoDecimals;
using detail::copyField;

// ===========================================================================
// Module A - student records
// ===========================================================================
OpResult AcademicManager::addStudent(StudentCategory category, const std::string& rawId,
                                     const std::string& name, const std::string& program, int semester) {
    const std::string id = normalizeId(rawId);
    if (!isValidId(id)) {
        return failure("Student ID must be 2-15 characters (A-Z, 0-9, '-', '_').");
    }
    if (ht_contains(studentIndex_.get(), id.c_str())) {
        return failure("A student with ID " + id + " already exists.");
    }
    std::unique_ptr<Student> student;
    try {
        if (category == StudentCategory::UG) {
            student.reset(new UGStudent(id, trim(name), trim(program), semester));
        } else {
            student.reset(new PGStudent(id, trim(name), trim(program), semester));
        }
    } catch (const std::invalid_argument& e) {
        return failure(std::string("Invalid student details: ") + e.what() + ".");
    }
    const int slot = static_cast<int>(students_.size());
    const int status = ht_insert(studentIndex_.get(), id.c_str(), slot);
    if (status != DS_OK) {
        return failure(std::string("Could not index the student: ") + ds_status_text(status) + ".");
    }
    students_.push_back(std::move(student));
    return success("Added " + students_.back()->categoryName() + " student " + id + " (" +
                   students_.back()->name() + ").");
}

OpResult AcademicManager::updateStudent(const std::string& rawId, const std::string& name,
                                        const std::string& program, int semester) {
    Student* s = studentAt(studentSlot(normalizeId(rawId)));
    if (s == nullptr) {
        return failure("No student with ID " + normalizeId(rawId) + ".");
    }
    const std::string newName = trim(name);
    const std::string newProgram = trim(program);
    // validate everything first so a bad field leaves the record untouched
    if (!newName.empty() && !isValidText(newName, kMaxNameLength)) {
        return failure("Name must be 1-47 printable characters.");
    }
    if (!newProgram.empty() && !isValidText(newProgram, kMaxProgramLength)) {
        return failure("Program must be 1-31 printable characters.");
    }
    if (semester != 0 && (semester < 1 || semester > s->maxSemester())) {
        return failure("Semester must be between 1 and " + std::to_string(s->maxSemester()) + " for a " +
                       s->categoryName() + " student.");
    }
    if (!newName.empty()) s->setName(newName);
    if (!newProgram.empty()) s->setProgram(newProgram);
    if (semester != 0) s->setSemester(semester);
    return success("Updated student " + s->id() + ".");
}

OpResult AcademicManager::deleteStudent(const std::string& rawId) {
    const std::string id = normalizeId(rawId);
    const int slot = studentSlot(id);
    Student* s = studentAt(slot);
    if (s == nullptr) {
        return failure("No student with ID " + id + ".");
    }
    // Documented constraint: active registrations must be cancelled first, so
    // seats are released through the normal path (which promotes waitlists).
    const auto enrolled = registrationsOf(id);
    const auto waiting = waitlistsOf(id);
    if (!enrolled.empty() || !waiting.empty()) {
        std::string list;
        for (const auto& c : enrolled) list += " " + c;
        for (const auto& w : waiting) list += " " + w.first + "(waitlist)";
        return failure("Cannot delete " + id + ": cancel these registrations first:" + list + ".");
    }
    removeFromRanking(*s);
    ht_remove(studentIndex_.get(), id.c_str());
    students_[static_cast<std::size_t>(slot)].reset();
    std::string note;
    if (!stack_is_empty(undo_.get())) {
        stack_clear(undo_.get());  // history may refer to the deleted student
        note = " Marks undo history was cleared.";
    }
    return success("Deleted student " + id + " and their results." + note);
}

std::vector<const Student*> AcademicManager::students() const {
    std::vector<const Student*> out;
    for (const auto& s : students_) {
        if (s) out.push_back(s.get());
    }
    return out;
}

std::vector<const Student*> AcademicManager::searchStudentsByName(const std::string& fragment) const {
    std::vector<const Student*> all = students();
    std::vector<SortRecord> records(all.size());
    for (std::size_t i = 0; i < all.size(); ++i) {
        copyField(records[i].key, DS_KEY_LEN, all[i]->id());
        copyField(records[i].name, DS_NAME_LEN, all[i]->name());
        records[i].score = 0;
    }
    std::vector<std::size_t> hits(all.size() + 1);
    const std::size_t n = ss_search_name(records.data(), records.size(), trim(fragment).c_str(),
                                         hits.data(), hits.size());
    std::vector<const Student*> out;
    for (std::size_t i = 0; i < n; ++i) {
        out.push_back(all[hits[i]]);
    }
    return out;
}

std::vector<const Student*> AcademicManager::sortedStudents(StudentSortKey key) const {
    std::vector<const Student*> all = students();
    std::vector<SortRecord> records(all.size());
    for (std::size_t i = 0; i < all.size(); ++i) {
        copyField(records[i].key, DS_KEY_LEN, all[i]->id());
        copyField(records[i].name, DS_NAME_LEN, all[i]->name());
        records[i].score = all[i]->hasResults() ? rankingScore(*all[i]) : -1;
    }
    int order = SORT_BY_KEY;
    if (key == StudentSortKey::Name) order = SORT_BY_NAME;
    if (key == StudentSortKey::CgpaHighFirst) order = SORT_BY_SCORE_DESC;
    if (ss_merge_sort(records.data(), records.size(), order) != DS_OK) {
        return all;  // allocation failure: fall back to slot order
    }
    std::vector<const Student*> out;
    for (const SortRecord& r : records) {
        out.push_back(findStudent(r.key));
    }
    return out;
}

std::vector<std::string> AcademicManager::registrationsOf(const std::string& studentId) const {
    const std::string id = normalizeId(studentId);
    std::vector<std::string> codes;
    for (const auto& c : courses_) {
        if (c && c->isEnrolled(id)) codes.push_back(c->code());
    }
    return codes;
}

std::vector<std::pair<std::string, std::size_t>> AcademicManager::waitlistsOf(const std::string& studentId) const {
    const std::string id = normalizeId(studentId);
    std::vector<std::pair<std::string, std::size_t>> entries;
    for (const auto& c : courses_) {
        if (!c) continue;
        const std::size_t pos = c->waitlistPosition(id);
        if (pos != 0) entries.emplace_back(c->code(), pos);
    }
    return entries;
}


}  // namespace academic
