/*
 * bst.c
 * AVL tree with subtree sizes (see bst.h for the ordering rules).
 */
#include "ds/bst.h"

#include <stdlib.h>
#include <string.h>

typedef struct AVLNode {
    int score;
    char id[DS_KEY_LEN];
    int height;            /* leaf = 1 */
    size_t size;           /* nodes in this subtree, including itself */
    struct AVLNode *left;
    struct AVLNode *right;
} AVLNode;

struct AVLTree {
    AVLNode *root;
};

/* <0 if (sa, ia) is ordered before (sb, ib) in an inorder walk. */
static int compare_keys(int sa, const char *ia, int sb, const char *ib)
{
    if (sa != sb) {
        return sa < sb ? -1 : 1;
    }
    return strcmp(ib, ia); /* equal score: larger ID first (goes left) */
}

static int height_of(const AVLNode *n) { return n == NULL ? 0 : n->height; }
static size_t size_of(const AVLNode *n) { return n == NULL ? 0 : n->size; }

static void refresh(AVLNode *n)
{
    int hl = height_of(n->left);
    int hr = height_of(n->right);
    n->height = 1 + (hl > hr ? hl : hr);
    n->size = 1 + size_of(n->left) + size_of(n->right);
}

static int balance_factor(const AVLNode *n)
{
    return height_of(n->left) - height_of(n->right);
}

/*      y              x
 *     / \            / \
 *    x   C   --->   A   y
 *   / \                / \
 *  A   B              B   C        */
static AVLNode *rotate_right(AVLNode *y)
{
    AVLNode *x = y->left;
    y->left = x->right;
    x->right = y;
    refresh(y); /* y is now the child, so update it first */
    refresh(x);
    return x;
}

static AVLNode *rotate_left(AVLNode *x)
{
    AVLNode *y = x->right;
    x->right = y->left;
    y->left = x;
    refresh(x);
    refresh(y);
    return y;
}

/* Restore the AVL property at n (|balance| <= 1) using the four cases. */
static AVLNode *rebalance(AVLNode *n)
{
    int bf;
    refresh(n);
    bf = balance_factor(n);
    if (bf > 1) {                              /* left heavy  */
        if (balance_factor(n->left) < 0) {     /* Left-Right  */
            n->left = rotate_left(n->left);
        }
        return rotate_right(n);                /* Left-Left   */
    }
    if (bf < -1) {                             /* right heavy */
        if (balance_factor(n->right) > 0) {    /* Right-Left  */
            n->right = rotate_right(n->right);
        }
        return rotate_left(n);                 /* Right-Right */
    }
    return n;
}

static void free_nodes(AVLNode *n)
{
    if (n == NULL) {
        return;
    }
    free_nodes(n->left);
    free_nodes(n->right);
    free(n); /* post-order: children are freed before their parent */
}

AVLTree *avl_create(void)
{
    AVLTree *tree = (AVLTree *)malloc(sizeof(AVLTree));
    if (tree != NULL) {
        tree->root = NULL;
    }
    return tree;
}

void avl_clear(AVLTree *tree)
{
    if (tree == NULL) {
        return;
    }
    free_nodes(tree->root);
    tree->root = NULL;
}

void avl_destroy(AVLTree *tree)
{
    if (tree == NULL) {
        return;
    }
    avl_clear(tree);
    free(tree);
}

static AVLNode *insert_node(AVLNode *n, int score, const char *id, int *status)
{
    int cmp;
    if (n == NULL) {
        AVLNode *node = (AVLNode *)malloc(sizeof(AVLNode));
        if (node == NULL) {
            *status = DS_ERR_ALLOC;
            return NULL;
        }
        node->score = score;
        (void)ds_copy_key(node->id, id, sizeof(node->id));
        node->height = 1;
        node->size = 1;
        node->left = NULL;
        node->right = NULL;
        *status = DS_OK;
        return node;
    }
    cmp = compare_keys(score, id, n->score, n->id);
    if (cmp == 0) {
        *status = DS_ERR_DUPLICATE;
        return n;
    }
    if (cmp < 0) {
        AVLNode *child = insert_node(n->left, score, id, status);
        if (*status != DS_OK) {
            return n; /* nothing changed below, no rebalancing needed */
        }
        n->left = child;
    } else {
        AVLNode *child = insert_node(n->right, score, id, status);
        if (*status != DS_OK) {
            return n;
        }
        n->right = child;
    }
    return rebalance(n);
}

int avl_insert(AVLTree *tree, int score, const char *id)
{
    int status = DS_OK;
    AVLNode *root;
    if (tree == NULL || id == NULL || id[0] == '\0' || strlen(id) >= DS_KEY_LEN) {
        return DS_ERR_INVALID;
    }
    root = insert_node(tree->root, score, id, &status);
    if (status == DS_OK) {
        tree->root = root;
    }
    return status;
}

static AVLNode *remove_node(AVLNode *n, int score, const char *id, int *status)
{
    int cmp;
    if (n == NULL) {
        *status = DS_ERR_NOT_FOUND;
        return NULL;
    }
    cmp = compare_keys(score, id, n->score, n->id);
    if (cmp < 0) {
        n->left = remove_node(n->left, score, id, status);
    } else if (cmp > 0) {
        n->right = remove_node(n->right, score, id, status);
    } else {
        *status = DS_OK;
        if (n->left == NULL || n->right == NULL) {
            /* zero or one child: splice the node out */
            AVLNode *child = n->left != NULL ? n->left : n->right;
            free(n);
            return child;
        } else {
            /* two children: copy the inorder successor (leftmost node of the
             * right subtree) into n, then delete the successor instead */
            AVLNode *succ = n->right;
            while (succ->left != NULL) {
                succ = succ->left;
            }
            n->score = succ->score;
            memcpy(n->id, succ->id, sizeof(n->id));
            /* search with n's copy of the key: succ itself is about to be freed */
            n->right = remove_node(n->right, n->score, n->id, status);
        }
    }
    return rebalance(n);
}

int avl_remove(AVLTree *tree, int score, const char *id)
{
    int status = DS_ERR_NOT_FOUND;
    if (tree == NULL || id == NULL) {
        return DS_ERR_INVALID;
    }
    tree->root = remove_node(tree->root, score, id, &status);
    return status;
}

int avl_contains(const AVLTree *tree, int score, const char *id)
{
    const AVLNode *n;
    if (tree == NULL || id == NULL) {
        return 0;
    }
    n = tree->root;
    while (n != NULL) {
        int cmp = compare_keys(score, id, n->score, n->id);
        if (cmp == 0) {
            return 1;
        }
        n = cmp < 0 ? n->left : n->right;
    }
    return 0;
}

size_t avl_size(const AVLTree *tree)
{
    return tree == NULL ? 0 : size_of(tree->root);
}

int avl_height(const AVLTree *tree)
{
    return tree == NULL ? 0 : height_of(tree->root);
}

static void inorder(const AVLNode *n, AVLEntry *out, size_t max, size_t *count)
{
    if (n == NULL || *count >= max) {
        return;
    }
    inorder(n->left, out, max, count);
    if (*count < max) {
        out[*count].score = n->score;
        memcpy(out[*count].id, n->id, sizeof(n->id));
        (*count)++;
    }
    inorder(n->right, out, max, count);
}

static void reverse_inorder(const AVLNode *n, AVLEntry *out, size_t max, size_t *count)
{
    if (n == NULL || *count >= max) {
        return;
    }
    reverse_inorder(n->right, out, max, count);
    if (*count < max) {
        out[*count].score = n->score;
        memcpy(out[*count].id, n->id, sizeof(n->id));
        (*count)++;
    }
    reverse_inorder(n->left, out, max, count);
}

size_t avl_inorder(const AVLTree *tree, AVLEntry *out, size_t max)
{
    size_t count = 0;
    if (tree != NULL && out != NULL) {
        inorder(tree->root, out, max, &count);
    }
    return count;
}

size_t avl_reverse_inorder(const AVLTree *tree, AVLEntry *out, size_t max)
{
    size_t count = 0;
    if (tree != NULL && out != NULL) {
        reverse_inorder(tree->root, out, max, &count);
    }
    return count;
}

size_t avl_count_above(const AVLTree *tree, int score)
{
    /* Walk one root-to-leaf path. Whenever a node's score is higher than the
     * query, that node and its whole right subtree are higher too. */
    size_t count = 0;
    const AVLNode *n = tree == NULL ? NULL : tree->root;
    while (n != NULL) {
        if (n->score > score) {
            count += 1 + size_of(n->right);
            n = n->left;
        } else {
            n = n->right;
        }
    }
    return count;
}

static void collect(const AVLNode *n, int min_score, AVLEntry *out, size_t max, size_t *count)
{
    if (n == NULL || *count >= max) {
        return;
    }
    collect(n->right, min_score, out, max, count);
    if (n->score < min_score) {
        return; /* the left subtree only holds scores <= n->score: prune it */
    }
    if (*count < max) {
        out[*count].score = n->score;
        memcpy(out[*count].id, n->id, sizeof(n->id));
        (*count)++;
    }
    collect(n->left, min_score, out, max, count);
}

size_t avl_collect_at_least(const AVLTree *tree, int min_score, AVLEntry *out, size_t max)
{
    size_t count = 0;
    if (tree != NULL && out != NULL) {
        collect(tree->root, min_score, out, max, &count);
    }
    return count;
}

/* Returns subtree height, or -1 if an invariant is broken. lo/hi are the
 * exclusive bounds inherited from ancestors (NULL = unbounded). */
static int validate(const AVLNode *n, const AVLNode *lo, const AVLNode *hi)
{
    int hl;
    int hr;
    if (n == NULL) {
        return 0;
    }
    if (lo != NULL && compare_keys(n->score, n->id, lo->score, lo->id) <= 0) {
        return -1;
    }
    if (hi != NULL && compare_keys(n->score, n->id, hi->score, hi->id) >= 0) {
        return -1;
    }
    hl = validate(n->left, lo, n);
    hr = validate(n->right, n, hi);
    if (hl < 0 || hr < 0 || hl - hr > 1 || hr - hl > 1) {
        return -1;
    }
    if (n->height != 1 + (hl > hr ? hl : hr)) {
        return -1;
    }
    if (n->size != 1 + size_of(n->left) + size_of(n->right)) {
        return -1;
    }
    return n->height;
}

int avl_validate(const AVLTree *tree)
{
    if (tree == NULL) {
        return 0;
    }
    return validate(tree->root, NULL, NULL) >= 0;
}
