/*
 * hash_table.c
 * Separate-chaining hash table built on top of linked_list.c.
 */
#include "ds/hash_table.h"
#include "ds/linked_list.h"

#include <stdlib.h>
#include <string.h>

#define HT_DEFAULT_BUCKETS 16

struct HashTable {
    LinkedList **buckets; /* bucket i is NULL until a key hashes there */
    size_t bucket_count;
    size_t size;
};

unsigned long ht_hash_string(const char *key)
{
    /* FNV-1a: start from the offset basis, then for each byte XOR it in and
     * multiply by the FNV prime. Every input bit influences the result. */
    unsigned long hash = 2166136261UL;
    const unsigned char *p = (const unsigned char *)key;
    while (*p != '\0') {
        hash ^= (unsigned long)(*p++);
        hash = (hash * 16777619UL) & 0xFFFFFFFFUL;
    }
    return hash;
}

static size_t index_for(const char *key, size_t bucket_count)
{
    return (size_t)(ht_hash_string(key) % (unsigned long)bucket_count);
}

HashTable *ht_create(size_t initial_buckets)
{
    HashTable *table = (HashTable *)malloc(sizeof(HashTable));
    if (table == NULL) {
        return NULL;
    }
    table->bucket_count = initial_buckets == 0 ? HT_DEFAULT_BUCKETS : initial_buckets;
    table->size = 0;
    table->buckets = (LinkedList **)calloc(table->bucket_count, sizeof(LinkedList *));
    if (table->buckets == NULL) {
        free(table);
        return NULL;
    }
    return table;
}

void ht_clear(HashTable *table)
{
    size_t i;
    if (table == NULL) {
        return;
    }
    for (i = 0; i < table->bucket_count; ++i) {
        ll_destroy(table->buckets[i]);
        table->buckets[i] = NULL;
    }
    table->size = 0;
}

void ht_destroy(HashTable *table)
{
    if (table == NULL) {
        return;
    }
    ht_clear(table);
    free(table->buckets);
    free(table);
}

/* Double the bucket array and move every key to its new bucket.
 * On allocation failure the old table is left untouched. */
static int rehash(HashTable *table, size_t new_count)
{
    LinkedList **fresh = (LinkedList **)calloc(new_count, sizeof(LinkedList *));
    size_t i;
    if (fresh == NULL) {
        return DS_ERR_ALLOC;
    }
    for (i = 0; i < table->bucket_count; ++i) {
        const LLNode *node;
        for (node = ll_first(table->buckets[i]); node != NULL; node = ll_next(node)) {
            size_t idx = index_for(ll_node_key(node), new_count);
            if (fresh[idx] == NULL) {
                fresh[idx] = ll_create();
            }
            if (fresh[idx] == NULL ||
                ll_push_back(fresh[idx], ll_node_key(node), ll_node_value(node)) != DS_OK) {
                size_t j;
                for (j = 0; j < new_count; ++j) {
                    ll_destroy(fresh[j]);
                }
                free(fresh);
                return DS_ERR_ALLOC;
            }
        }
    }
    for (i = 0; i < table->bucket_count; ++i) {
        ll_destroy(table->buckets[i]);
    }
    free(table->buckets);
    table->buckets = fresh;
    table->bucket_count = new_count;
    return DS_OK;
}

int ht_insert(HashTable *table, const char *key, int value)
{
    size_t idx;
    int status;
    if (table == NULL || key == NULL || key[0] == '\0' || strlen(key) >= DS_KEY_LEN) {
        return DS_ERR_INVALID;
    }
    if (ht_contains(table, key)) {
        return DS_ERR_DUPLICATE;
    }
    /* Grow before inserting so the load factor stays <= HT_MAX_LOAD_FACTOR.
     * If growing fails we still insert: a longer chain is slower, not wrong. */
    if ((double)(table->size + 1) / (double)table->bucket_count > HT_MAX_LOAD_FACTOR) {
        (void)rehash(table, table->bucket_count * 2);
    }
    idx = index_for(key, table->bucket_count);
    if (table->buckets[idx] == NULL) {
        table->buckets[idx] = ll_create();
        if (table->buckets[idx] == NULL) {
            return DS_ERR_ALLOC;
        }
    }
    status = ll_push_back(table->buckets[idx], key, value);
    if (status == DS_OK) {
        table->size++;
    }
    return status;
}

int ht_find(const HashTable *table, const char *key, int *out_value)
{
    if (table == NULL || key == NULL) {
        return DS_ERR_INVALID;
    }
    return ll_find(table->buckets[index_for(key, table->bucket_count)], key, out_value);
}

int ht_contains(const HashTable *table, const char *key)
{
    return ht_find(table, key, NULL) == DS_OK;
}

int ht_update(HashTable *table, const char *key, int value)
{
    if (table == NULL || key == NULL) {
        return DS_ERR_INVALID;
    }
    return ll_set_value(table->buckets[index_for(key, table->bucket_count)], key, value);
}

int ht_remove(HashTable *table, const char *key)
{
    size_t idx;
    int status;
    if (table == NULL || key == NULL) {
        return DS_ERR_INVALID;
    }
    idx = index_for(key, table->bucket_count);
    if (table->buckets[idx] == NULL) {
        return DS_ERR_NOT_FOUND; /* empty bucket: the key cannot be here */
    }
    status = ll_remove(table->buckets[idx], key);
    if (status == DS_OK) {
        table->size--;
        if (ll_size(table->buckets[idx]) == 0) {
            ll_destroy(table->buckets[idx]);
            table->buckets[idx] = NULL;
        }
    }
    return status;
}

size_t ht_size(const HashTable *table)
{
    return table == NULL ? 0 : table->size;
}

size_t ht_bucket_count(const HashTable *table)
{
    return table == NULL ? 0 : table->bucket_count;
}

double ht_load_factor(const HashTable *table)
{
    if (table == NULL || table->bucket_count == 0) {
        return 0.0;
    }
    return (double)table->size / (double)table->bucket_count;
}

size_t ht_longest_chain(const HashTable *table)
{
    size_t i;
    size_t longest = 0;
    if (table == NULL) {
        return 0;
    }
    for (i = 0; i < table->bucket_count; ++i) {
        size_t len = ll_size(table->buckets[i]);
        if (len > longest) {
            longest = len;
        }
    }
    return longest;
}

size_t ht_colliding_buckets(const HashTable *table)
{
    size_t i;
    size_t count = 0;
    if (table == NULL) {
        return 0;
    }
    for (i = 0; i < table->bucket_count; ++i) {
        if (ll_size(table->buckets[i]) > 1) {
            count++;
        }
    }
    return count;
}

size_t ht_bucket_index(const HashTable *table, const char *key)
{
    if (table == NULL || key == NULL) {
        return 0;
    }
    return index_for(key, table->bucket_count);
}
