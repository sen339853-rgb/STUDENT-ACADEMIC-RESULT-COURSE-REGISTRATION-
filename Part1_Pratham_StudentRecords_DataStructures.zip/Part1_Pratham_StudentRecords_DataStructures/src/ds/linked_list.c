/*
 * linked_list.c
 * Singly linked list with head/tail pointers (see linked_list.h).
 */
#include "ds/linked_list.h"

#include <stdlib.h>
#include <string.h>

struct LLNode {
    char key[DS_KEY_LEN];
    int value;
    struct LLNode *next;
};

struct LinkedList {
    LLNode *head;
    LLNode *tail;
    size_t size;
};

static LLNode *make_node(const char *key, int value)
{
    LLNode *node = (LLNode *)malloc(sizeof(LLNode));
    if (node == NULL) {
        return NULL;
    }
    if (ds_copy_key(node->key, key, sizeof(node->key)) != DS_OK) {
        free(node);
        return NULL;
    }
    node->value = value;
    node->next = NULL;
    return node;
}

LinkedList *ll_create(void)
{
    LinkedList *list = (LinkedList *)malloc(sizeof(LinkedList));
    if (list == NULL) {
        return NULL;
    }
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
    return list;
}

void ll_clear(LinkedList *list)
{
    LLNode *cur;
    if (list == NULL) {
        return;
    }
    cur = list->head;
    while (cur != NULL) {
        LLNode *next = cur->next; /* read next BEFORE freeing the node */
        free(cur);
        cur = next;
    }
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
}

void ll_destroy(LinkedList *list)
{
    if (list == NULL) {
        return;
    }
    ll_clear(list);
    free(list);
}

static int key_is_valid(const char *key)
{
    return key != NULL && key[0] != '\0' && strlen(key) < DS_KEY_LEN;
}

int ll_push_back(LinkedList *list, const char *key, int value)
{
    LLNode *node;
    if (list == NULL || !key_is_valid(key)) {
        return DS_ERR_INVALID;
    }
    node = make_node(key, value);
    if (node == NULL) {
        return DS_ERR_ALLOC;
    }
    if (list->tail == NULL) {
        list->head = node;
    } else {
        list->tail->next = node;
    }
    list->tail = node;
    list->size++;
    return DS_OK;
}

int ll_push_front(LinkedList *list, const char *key, int value)
{
    LLNode *node;
    if (list == NULL || !key_is_valid(key)) {
        return DS_ERR_INVALID;
    }
    node = make_node(key, value);
    if (node == NULL) {
        return DS_ERR_ALLOC;
    }
    node->next = list->head;
    list->head = node;
    if (list->tail == NULL) {
        list->tail = node;
    }
    list->size++;
    return DS_OK;
}

int ll_remove(LinkedList *list, const char *key)
{
    LLNode *prev = NULL;
    LLNode *cur;
    if (list == NULL || key == NULL) {
        return DS_ERR_INVALID;
    }
    cur = list->head;
    while (cur != NULL && strcmp(cur->key, key) != 0) {
        prev = cur;
        cur = cur->next;
    }
    if (cur == NULL) {
        return DS_ERR_NOT_FOUND;
    }
    /* Unlink: either the head moves forward or the previous node skips cur. */
    if (prev == NULL) {
        list->head = cur->next;
    } else {
        prev->next = cur->next;
    }
    if (list->tail == cur) {
        list->tail = prev;
    }
    free(cur);
    list->size--;
    return DS_OK;
}

static LLNode *find_node(const LinkedList *list, const char *key)
{
    LLNode *cur;
    if (list == NULL || key == NULL) {
        return NULL;
    }
    for (cur = list->head; cur != NULL; cur = cur->next) {
        if (strcmp(cur->key, key) == 0) {
            return cur;
        }
    }
    return NULL;
}

int ll_find(const LinkedList *list, const char *key, int *out_value)
{
    LLNode *node = find_node(list, key);
    if (node == NULL) {
        return DS_ERR_NOT_FOUND;
    }
    if (out_value != NULL) {
        *out_value = node->value;
    }
    return DS_OK;
}

int ll_contains(const LinkedList *list, const char *key)
{
    return find_node(list, key) != NULL;
}

int ll_set_value(LinkedList *list, const char *key, int value)
{
    LLNode *node = find_node(list, key);
    if (node == NULL) {
        return DS_ERR_NOT_FOUND;
    }
    node->value = value;
    return DS_OK;
}

size_t ll_size(const LinkedList *list)
{
    return list == NULL ? 0 : list->size;
}

const LLNode *ll_first(const LinkedList *list)
{
    return list == NULL ? NULL : list->head;
}

const LLNode *ll_next(const LLNode *node)
{
    return node == NULL ? NULL : node->next;
}

const char *ll_node_key(const LLNode *node)
{
    return node == NULL ? NULL : node->key;
}

int ll_node_value(const LLNode *node)
{
    return node == NULL ? 0 : node->value;
}
