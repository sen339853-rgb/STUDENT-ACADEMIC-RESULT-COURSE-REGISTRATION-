/*
 * ds_common.c
 * Status-code text and a bounded string copy shared by all C modules.
 */
#include "ds/ds_common.h"

#include <string.h>

const char *ds_status_text(int status)
{
    switch (status) {
    case DS_OK:            return "ok";
    case DS_ERR_ALLOC:     return "memory allocation failed";
    case DS_ERR_NOT_FOUND: return "not found";
    case DS_ERR_DUPLICATE: return "duplicate entry";
    case DS_ERR_INVALID:   return "invalid argument";
    case DS_ERR_EMPTY:     return "container is empty";
    case DS_ERR_CYCLE:     return "would create a prerequisite cycle";
    case DS_ERR_SELF_LOOP: return "a course cannot be its own prerequisite";
    default:               return "unknown error";
    }
}

int ds_copy_key(char *dst, const char *src, unsigned long dst_size)
{
    size_t len;
    if (dst == NULL || src == NULL || dst_size == 0) {
        return DS_ERR_INVALID;
    }
    len = strlen(src);
    if (len == 0 || len >= dst_size) {
        return DS_ERR_INVALID;
    }
    memcpy(dst, src, len + 1);
    return DS_OK;
}
