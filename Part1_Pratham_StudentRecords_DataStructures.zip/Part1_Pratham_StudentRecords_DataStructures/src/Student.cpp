// Student.cpp
#include "Student.hpp"

#include <algorithm>
#include <stdexcept>
#include <utility>

#include "Validation.hpp"

namespace academic {

// ---------------------------------------------------------------------------
// Demonstration grading policies (10-point scale). Edit these tables to change
// the academic rules; nothing else in the program hard-codes a threshold.
// ---------------------------------------------------------------------------
const GradingPolicy& undergraduatePolicy() {
    static const GradingPolicy policy{
        "Undergraduate (demo policy)",
        4000,  // pass mark 40
        {{9000, "O", 10}, {8000, "A+", 9}, {7000, "A", 8}, {6000, "B+", 7},
         {5000, "B", 6},  {4500, "C", 5},  {4000, "P", 4},  {0, "F", 0}},
        5.0,   // good standing CGPA
        8};    // semesters in a UG programme
    return policy;
}

const GradingPolicy& postgraduatePolicy() {
    static const GradingPolicy policy{
        "Postgraduate (demo policy)",
        5000,  // pass mark 50: PG is stricter
        {{9000, "O", 10}, {8000, "A+", 9}, {7000, "A", 8}, {6000, "B+", 7},
         {5500, "B", 6},  {5000, "C", 5},  {0, "F", 0}},
        6.0,
        4};
    return policy;
}

// ---------------------------------------------------------------------------
// Student (abstract base)
// ---------------------------------------------------------------------------
Student::Student(std::string id, std::string name, std::string program, int semester)
    : id_(std::move(id)), name_(std::move(name)), program_(std::move(program)), semester_(semester) {
    if (!isValidId(id_)) {
        throw std::invalid_argument("invalid student ID '" + id_ + "'");
    }
    if (!isValidText(name_, kMaxNameLength)) {
        throw std::invalid_argument("name must be 1-47 printable characters");
    }
    if (!isValidText(program_, kMaxProgramLength)) {
        throw std::invalid_argument("program must be 1-31 printable characters");
    }
}

GradeInfo Student::applyPolicy(const GradingPolicy& policy, int centiMarks) {
    for (const GradeBand& band : policy.bands) {
        if (centiMarks >= band.minCentiMarks) {
            return GradeInfo{band.letter, band.gradePoint, centiMarks >= policy.passCentiMarks};
        }
    }
    return GradeInfo{"F", 0, false};
}

const Result* Student::findResult(const std::string& courseCode) const {
    for (const Result& r : results_) {
        if (r.courseCode() == courseCode) {
            return &r;
        }
    }
    return nullptr;
}

Result* Student::findResultMutable(const std::string& courseCode) {
    for (Result& r : results_) {
        if (r.courseCode() == courseCode) {
            return &r;
        }
    }
    return nullptr;
}

bool Student::hasPassed(const std::string& courseCode) const {
    const Result* r = findResult(courseCode);
    return r != nullptr && evaluate(r->centiMarks()).passed;  // virtual call
}

double Student::cgpa() const {
    // CGPA = sum(gradePoint x credits) / sum(credits) over all recorded results.
    int weighted = 0;
    int credits = 0;
    for (const Result& r : results_) {
        weighted += evaluate(r.centiMarks()).gradePoint * r.credits();
        credits += r.credits();
    }
    return credits == 0 ? 0.0 : static_cast<double>(weighted) / credits;
}

int Student::creditsAttempted() const {
    int total = 0;
    for (const Result& r : results_) {
        total += r.credits();
    }
    return total;
}

int Student::creditsEarned() const {
    int total = 0;
    for (const Result& r : results_) {
        if (evaluate(r.centiMarks()).passed) {
            total += r.credits();
        }
    }
    return total;
}

void Student::setName(const std::string& name) {
    if (!isValidText(name, kMaxNameLength)) {
        throw std::invalid_argument("name must be 1-47 printable characters");
    }
    name_ = name;
}

void Student::setProgram(const std::string& program) {
    if (!isValidText(program, kMaxProgramLength)) {
        throw std::invalid_argument("program must be 1-31 printable characters");
    }
    program_ = program;
}

void Student::setSemester(int semester) {
    if (semester < 1 || semester > maxSemester()) {
        throw std::invalid_argument("semester must be between 1 and " + std::to_string(maxSemester()) +
                                    " for a " + categoryName() + " student");
    }
    semester_ = semester;
}

void Student::upsertResult(const std::string& courseCode, int centiMarks, int credits) {
    if (Result* existing = findResultMutable(courseCode)) {
        existing->setCentiMarks(centiMarks);
        return;
    }
    results_.emplace_back(courseCode, centiMarks, credits);
}

bool Student::removeResult(const std::string& courseCode) {
    auto it = std::find_if(results_.begin(), results_.end(),
                           [&](const Result& r) { return r.courseCode() == courseCode; });
    if (it == results_.end()) {
        return false;
    }
    results_.erase(it);
    return true;
}

// ---------------------------------------------------------------------------
// UGStudent / PGStudent
// ---------------------------------------------------------------------------
UGStudent::UGStudent(std::string id, std::string name, std::string program, int semester)
    : Student(std::move(id), std::move(name), std::move(program), semester) {
    setSemester(semester);  // validates against the UG semester limit
}

GradeInfo UGStudent::evaluate(int centiMarks) const {
    return applyPolicy(undergraduatePolicy(), centiMarks);
}

std::string UGStudent::academicStanding(double cgpa) const {
    if (!hasResults()) {
        return "No results yet";
    }
    return cgpa >= undergraduatePolicy().goodStandingCgpa ? "Good standing" : "Academic warning";
}

PGStudent::PGStudent(std::string id, std::string name, std::string program, int semester)
    : Student(std::move(id), std::move(name), std::move(program), semester) {
    setSemester(semester);
}

GradeInfo PGStudent::evaluate(int centiMarks) const {
    return applyPolicy(postgraduatePolicy(), centiMarks);
}

std::string PGStudent::academicStanding(double cgpa) const {
    if (!hasResults()) {
        return "No results yet";
    }
    // PG students also need every attempted course passed for good standing.
    for (const Result& r : results()) {
        if (!evaluate(r.centiMarks()).passed) {
            return "Academic warning (failed course)";
        }
    }
    return cgpa >= postgraduatePolicy().goodStandingCgpa ? "Good standing" : "Academic warning";
}

}  // namespace academic
