// test_framework.hpp
// Minimal self-contained test harness (no external libraries).
//
//   TEST(name) { CHECK(condition); CHECK_EQ(a, b); }
//   int main() { return runAllTests("suite name"); }
//
// A test is reported PASS only if every CHECK inside it held.
#ifndef TEST_FRAMEWORK_HPP
#define TEST_FRAMEWORK_HPP

#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace testing {

struct TestCase {
    const char* name;
    std::function<void()> body;
};

inline std::vector<TestCase>& registry() {
    static std::vector<TestCase> tests;
    return tests;
}

inline int& currentFailures() {
    static int failures = 0;
    return failures;
}

inline int& currentChecks() {
    static int checks = 0;
    return checks;
}

struct Registrar {
    Registrar(const char* name, std::function<void()> body) { registry().push_back({name, std::move(body)}); }
};

inline void check(bool ok, const std::string& expr, const char* file, int line) {
    ++currentChecks();
    if (!ok) {
        ++currentFailures();
        std::cout << "      CHECK FAILED: " << expr << "  (" << file << ":" << line << ")\n";
    }
}

template <typename A, typename B>
void checkEq(const A& a, const B& b, const char* ea, const char* eb, const char* file, int line) {
    std::ostringstream text;
    text << ea << " == " << eb << "  [got " << a << " vs " << b << "]";
    check(a == b, text.str(), file, line);
}

inline int runAllTests(const char* suite) {
    int passed = 0;
    int failed = 0;
    int totalChecks = 0;
    std::cout << "=== " << suite << " ===\n";
    for (const TestCase& t : registry()) {
        currentFailures() = 0;
        currentChecks() = 0;
        t.body();
        totalChecks += currentChecks();
        if (currentFailures() == 0) {
            ++passed;
            std::cout << "  [PASS] " << t.name << " (" << currentChecks() << " checks)\n";
        } else {
            ++failed;
            std::cout << "  [FAIL] " << t.name << " (" << currentFailures() << " of " << currentChecks()
                      << " checks failed)\n";
        }
    }
    std::cout << "--- " << suite << ": " << passed << " passed, " << failed << " failed, " << totalChecks
              << " checks ---\n\n";
    return failed == 0 ? 0 : 1;
}

}  // namespace testing

#define TEST(name)                                                   \
    static void name();                                              \
    static ::testing::Registrar registrar_##name(#name, name);       \
    static void name()

#define CHECK(cond) ::testing::check(static_cast<bool>(cond), #cond, __FILE__, __LINE__)
#define CHECK_EQ(a, b) ::testing::checkEq((a), (b), #a, #b, __FILE__, __LINE__)

#endif  // TEST_FRAMEWORK_HPP
