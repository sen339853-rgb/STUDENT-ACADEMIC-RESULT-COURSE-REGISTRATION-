// test_data_structures.cpp
// Unit tests for the pure C modules, called from C++ through extern "C".
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "CHandles.hpp"
#include "ds/searching_sorting.h"
#include "test_framework.hpp"

using namespace academic;

// ---------------------------------------------------------------------------
// Linked list
// ---------------------------------------------------------------------------
TEST(linked_list_insert_find_traverse) {
    LinkedListHandle list = adoptHandle<LinkedListHandle>(ll_create());
    CHECK_EQ(ll_size(list.get()), 0u);
    CHECK_EQ(ll_push_back(list.get(), "B", 2), DS_OK);
    CHECK_EQ(ll_push_back(list.get(), "C", 3), DS_OK);
    CHECK_EQ(ll_push_front(list.get(), "A", 1), DS_OK);
    CHECK_EQ(ll_size(list.get()), 3u);

    std::string order;
    for (const LLNode* n = ll_first(list.get()); n != nullptr; n = ll_next(n)) order += ll_node_key(n);
    CHECK_EQ(order, std::string("ABC"));

    int value = 0;
    CHECK_EQ(ll_find(list.get(), "C", &value), DS_OK);
    CHECK_EQ(value, 3);
    CHECK_EQ(ll_find(list.get(), "Z", &value), DS_ERR_NOT_FOUND);
    CHECK_EQ(ll_set_value(list.get(), "B", 20), DS_OK);
    ll_find(list.get(), "B", &value);
    CHECK_EQ(value, 20);
    CHECK_EQ(ll_push_back(list.get(), "", 0), DS_ERR_INVALID);
    CHECK_EQ(ll_push_back(list.get(), "THIS-KEY-IS-TOO-LONG", 0), DS_ERR_INVALID);
}

TEST(linked_list_delete_head_middle_tail) {
    LinkedListHandle list = adoptHandle<LinkedListHandle>(ll_create());
    for (const char* k : {"A", "B", "C", "D"}) ll_push_back(list.get(), k, 0);
    CHECK_EQ(ll_remove(list.get(), "D"), DS_OK);  // tail
    CHECK_EQ(ll_push_back(list.get(), "E", 0), DS_OK);  // tail pointer must still be correct
    CHECK_EQ(ll_remove(list.get(), "A"), DS_OK);  // head
    CHECK_EQ(ll_remove(list.get(), "C"), DS_OK);  // middle
    CHECK_EQ(ll_remove(list.get(), "C"), DS_ERR_NOT_FOUND);
    std::string order;
    for (const LLNode* n = ll_first(list.get()); n != nullptr; n = ll_next(n)) order += ll_node_key(n);
    CHECK_EQ(order, std::string("BE"));
    ll_clear(list.get());
    CHECK_EQ(ll_size(list.get()), 0u);
    CHECK(ll_first(list.get()) == nullptr);
    CHECK_EQ(ll_push_back(list.get(), "F", 0), DS_OK);  // usable after clear
    CHECK_EQ(ll_size(list.get()), 1u);
}

// ---------------------------------------------------------------------------
// Hash table
// ---------------------------------------------------------------------------
TEST(hash_table_insert_find_update_remove) {
    HashTableHandle t = adoptHandle<HashTableHandle>(ht_create(16));
    CHECK_EQ(ht_insert(t.get(), "S101", 0), DS_OK);
    CHECK_EQ(ht_insert(t.get(), "S102", 1), DS_OK);
    CHECK_EQ(ht_insert(t.get(), "S101", 9), DS_ERR_DUPLICATE);  // duplicate key rejected
    CHECK_EQ(ht_size(t.get()), 2u);
    int v = -1;
    CHECK_EQ(ht_find(t.get(), "S102", &v), DS_OK);
    CHECK_EQ(v, 1);
    CHECK_EQ(ht_find(t.get(), "S999", &v), DS_ERR_NOT_FOUND);   // missing key
    CHECK_EQ(ht_update(t.get(), "S102", 5), DS_OK);
    ht_find(t.get(), "S102", &v);
    CHECK_EQ(v, 5);
    CHECK_EQ(ht_update(t.get(), "S999", 5), DS_ERR_NOT_FOUND);
    CHECK_EQ(ht_remove(t.get(), "S101"), DS_OK);
    CHECK_EQ(ht_remove(t.get(), "S101"), DS_ERR_NOT_FOUND);
    CHECK(!ht_contains(t.get(), "S101"));
    CHECK_EQ(ht_size(t.get()), 1u);
    CHECK_EQ(ht_insert(t.get(), "", 0), DS_ERR_INVALID);
    CHECK_EQ(ht_insert(t.get(), "0123456789ABCDEF", 0), DS_ERR_INVALID);  // 16 chars: too long
}

TEST(hash_table_collision_chaining) {
    HashTableHandle probe = adoptHandle<HashTableHandle>(ht_create(8));
    // find two keys that land in the same bucket of an 8-bucket table
    std::string a, b;
    char key[DS_KEY_LEN];
    std::vector<std::string> seen(8);
    for (int i = 0; i < 100 && b.empty(); ++i) {
        std::snprintf(key, sizeof key, "K%d", i);
        const std::size_t idx = ht_bucket_index(probe.get(), key);
        if (seen[idx].empty()) {
            seen[idx] = key;
        } else {
            a = seen[idx];
            b = key;
        }
    }
    CHECK(!b.empty());
    HashTableHandle t = adoptHandle<HashTableHandle>(ht_create(8));
    CHECK_EQ(ht_insert(t.get(), a.c_str(), 10), DS_OK);
    CHECK_EQ(ht_insert(t.get(), b.c_str(), 20), DS_OK);
    CHECK_EQ(ht_bucket_index(t.get(), a.c_str()), ht_bucket_index(t.get(), b.c_str()));
    CHECK_EQ(ht_colliding_buckets(t.get()), 1u);
    CHECK_EQ(ht_longest_chain(t.get()), 2u);
    int v = 0;
    CHECK(ht_find(t.get(), a.c_str(), &v) == DS_OK && v == 10);
    CHECK(ht_find(t.get(), b.c_str(), &v) == DS_OK && v == 20);
    CHECK_EQ(ht_remove(t.get(), a.c_str()), DS_OK);  // removing one keeps the other
    CHECK(ht_find(t.get(), b.c_str(), &v) == DS_OK && v == 20);
    CHECK(!ht_contains(t.get(), a.c_str()));
}

TEST(hash_table_resizes_and_keeps_all_keys) {
    HashTableHandle t = adoptHandle<HashTableHandle>(ht_create(4));
    char key[DS_KEY_LEN];
    for (int i = 0; i < 2000; ++i) {
        std::snprintf(key, sizeof key, "ID%05d", i);
        ht_insert(t.get(), key, i);
    }
    CHECK_EQ(ht_size(t.get()), 2000u);
    CHECK(ht_bucket_count(t.get()) > 4u);
    CHECK(ht_load_factor(t.get()) <= HT_MAX_LOAD_FACTOR);
    int ok = 0;
    for (int i = 0; i < 2000; ++i) {
        std::snprintf(key, sizeof key, "ID%05d", i);
        int v = -1;
        if (ht_find(t.get(), key, &v) == DS_OK && v == i) ++ok;
    }
    CHECK_EQ(ok, 2000);
    ht_clear(t.get());
    CHECK_EQ(ht_size(t.get()), 0u);
    CHECK(!ht_contains(t.get(), "ID00001"));
}

// ---------------------------------------------------------------------------
// AVL tree
// ---------------------------------------------------------------------------
TEST(avl_stays_balanced_on_sorted_input) {
    AVLTreeHandle t = adoptHandle<AVLTreeHandle>(avl_create());
    char id[DS_KEY_LEN];
    const int n = 1023;
    for (int i = 0; i < n; ++i) {  // sorted input: a plain BST would become a list
        std::snprintf(id, sizeof id, "S%04d", i);
        CHECK_EQ(avl_insert(t.get(), i, id), DS_OK);
    }
    CHECK_EQ(avl_size(t.get()), static_cast<std::size_t>(n));
    CHECK(avl_validate(t.get()));
    const double bound = 1.45 * std::log2(n + 2.0);
    CHECK(avl_height(t.get()) <= static_cast<int>(bound));
    CHECK(avl_height(t.get()) >= 10);  // at least log2(1024)
}

TEST(avl_ranking_order_and_ties) {
    AVLTreeHandle t = adoptHandle<AVLTreeHandle>(avl_create());
    avl_insert(t.get(), 850, "S3");
    avl_insert(t.get(), 920, "S1");
    avl_insert(t.get(), 850, "S2");  // tie with S3
    avl_insert(t.get(), 700, "S4");
    CHECK_EQ(avl_insert(t.get(), 850, "S2"), DS_ERR_DUPLICATE);
    std::vector<AVLEntry> out(4);
    CHECK_EQ(avl_reverse_inorder(t.get(), out.data(), out.size()), 4u);
    CHECK_EQ(std::string(out[0].id), std::string("S1"));
    CHECK_EQ(std::string(out[1].id), std::string("S2"));  // equal score: smaller ID first
    CHECK_EQ(std::string(out[2].id), std::string("S3"));
    CHECK_EQ(std::string(out[3].id), std::string("S4"));
    CHECK_EQ(avl_inorder(t.get(), out.data(), out.size()), 4u);
    CHECK_EQ(std::string(out[0].id), std::string("S4"));  // inorder = lowest first
    CHECK_EQ(avl_count_above(t.get(), 920), 0u);
    CHECK_EQ(avl_count_above(t.get(), 850), 1u);  // rank of S2/S3 = 2 (competition rank)
    CHECK_EQ(avl_count_above(t.get(), 700), 3u);
    CHECK_EQ(avl_collect_at_least(t.get(), 850, out.data(), out.size()), 3u);
    CHECK_EQ(avl_collect_at_least(t.get(), 1000, out.data(), out.size()), 0u);
}

TEST(avl_delete_cases_keep_invariants) {
    AVLTreeHandle t = adoptHandle<AVLTreeHandle>(avl_create());
    char id[DS_KEY_LEN];
    for (int i = 0; i < 200; ++i) {
        std::snprintf(id, sizeof id, "S%03d", i);
        avl_insert(t.get(), (i * 37) % 101, id);
    }
    CHECK(avl_validate(t.get()));
    int removed = 0;
    for (int i = 0; i < 200; i += 3) {  // removes leaves, one-child and two-child nodes
        std::snprintf(id, sizeof id, "S%03d", i);
        if (avl_remove(t.get(), (i * 37) % 101, id) == DS_OK) ++removed;
        if (!avl_validate(t.get())) {
            CHECK(false);
            break;
        }
    }
    CHECK_EQ(removed, 67);
    CHECK_EQ(avl_size(t.get()), 133u);
    CHECK(!avl_contains(t.get(), 0, "S000"));
    CHECK(avl_contains(t.get(), 37, "S001"));
    CHECK_EQ(avl_remove(t.get(), 37, "S000"), DS_ERR_NOT_FOUND);
    avl_clear(t.get());
    CHECK_EQ(avl_size(t.get()), 0u);
    CHECK_EQ(avl_height(t.get()), 0);
}

// ---------------------------------------------------------------------------
// Graph + DFS
// ---------------------------------------------------------------------------
TEST(graph_prerequisite_chain_dfs) {
    GraphHandle g = adoptHandle<GraphHandle>(graph_create(2));  // forces growth
    graph_add_vertex(g.get(), 0, "PF");
    graph_add_vertex(g.get(), 1, "DSA");
    graph_add_vertex(g.get(), 2, "ADV");
    graph_add_vertex(g.get(), 3, "MATH");
    CHECK_EQ(graph_add_edge(g.get(), 1, 0), DS_OK);  // DSA requires PF
    CHECK_EQ(graph_add_edge(g.get(), 2, 1), DS_OK);  // ADV requires DSA

    std::vector<int> missing(4);
    std::size_t count = 99;
    std::vector<unsigned char> passed(4, 0);
    graph_check_prereqs(g.get(), 2, passed.data(), passed.size(), missing.data(), missing.size(), &count);
    CHECK_EQ(count, 2u);
    CHECK(missing[0] == 0 && missing[1] == 1);  // foundational first: PF then DSA

    passed[1] = 1;  // passed DSA but not PF: transitive check still catches PF
    graph_check_prereqs(g.get(), 2, passed.data(), passed.size(), missing.data(), missing.size(), &count);
    CHECK_EQ(count, 1u);
    CHECK_EQ(missing[0], 0);

    passed[0] = 1;
    graph_check_prereqs(g.get(), 2, passed.data(), passed.size(), missing.data(), missing.size(), &count);
    CHECK_EQ(count, 0u);

    graph_check_prereqs(g.get(), 3, nullptr, 0, missing.data(), missing.size(), &count);
    CHECK_EQ(count, 0u);  // course without prerequisites
    CHECK(graph_is_reachable(g.get(), 2, 0));
    CHECK(!graph_is_reachable(g.get(), 0, 2));
}

TEST(graph_rejects_invalid_edges) {
    GraphHandle g = adoptHandle<GraphHandle>(graph_create(4));
    graph_add_vertex(g.get(), 0, "A");
    graph_add_vertex(g.get(), 1, "B");
    graph_add_vertex(g.get(), 2, "C");
    CHECK_EQ(graph_add_vertex(g.get(), 1, "B2"), DS_ERR_DUPLICATE);
    CHECK_EQ(graph_add_edge(g.get(), 1, 0), DS_OK);           // B requires A
    CHECK_EQ(graph_add_edge(g.get(), 2, 1), DS_OK);           // C requires B
    CHECK_EQ(graph_add_edge(g.get(), 0, 0), DS_ERR_SELF_LOOP);
    CHECK_EQ(graph_add_edge(g.get(), 1, 0), DS_ERR_DUPLICATE);
    CHECK_EQ(graph_add_edge(g.get(), 0, 2), DS_ERR_CYCLE);    // A requires C closes A<-B<-C
    CHECK_EQ(graph_add_edge(g.get(), 0, 1), DS_ERR_CYCLE);    // direct 2-cycle
    CHECK_EQ(graph_add_edge(g.get(), 0, 7), DS_ERR_NOT_FOUND);
    CHECK_EQ(graph_edge_count(g.get()), 2u);
    CHECK(!graph_has_cycle(g.get()));

    std::vector<int> order(3);
    CHECK_EQ(graph_topological_order(g.get(), order.data(), order.size()), 3u);
    CHECK(order[0] == 0 && order[1] == 1 && order[2] == 2);

    CHECK_EQ(graph_remove_vertex(g.get(), 1), DS_OK);  // drops A<-B and B<-C
    CHECK_EQ(graph_edge_count(g.get()), 0u);
    CHECK(!graph_has_edge(g.get(), 2, 1));
    CHECK_EQ(graph_vertex_count(g.get()), 2u);
}

// ---------------------------------------------------------------------------
// Queue
// ---------------------------------------------------------------------------
TEST(queue_fifo_order_and_removal) {
    QueueHandle q = adoptHandle<QueueHandle>(queue_create());
    char out[DS_KEY_LEN];
    CHECK(queue_is_empty(q.get()));
    CHECK_EQ(queue_dequeue(q.get(), out, sizeof out), DS_ERR_EMPTY);
    CHECK_EQ(queue_peek(q.get(), out, sizeof out), DS_ERR_EMPTY);
    for (const char* id : {"S1", "S2", "S3", "S4"}) queue_enqueue(q.get(), id);
    CHECK_EQ(queue_size(q.get()), 4u);
    CHECK_EQ(queue_position(q.get(), "S3"), 3u);
    CHECK_EQ(queue_position(q.get(), "S9"), 0u);
    CHECK_EQ(queue_peek(q.get(), out, sizeof out), DS_OK);
    CHECK_EQ(std::string(out), std::string("S1"));
    CHECK_EQ(queue_remove(q.get(), "S4"), DS_OK);  // remove rear
    CHECK_EQ(queue_enqueue(q.get(), "S5"), DS_OK);  // rear pointer must be fixed
    CHECK_EQ(queue_remove(q.get(), "S2"), DS_OK);  // remove middle
    std::string order;
    while (queue_dequeue(q.get(), out, sizeof out) == DS_OK) order += std::string(out) + " ";
    CHECK_EQ(order, std::string("S1 S3 S5 "));
    CHECK(queue_is_empty(q.get()));
    CHECK_EQ(queue_enqueue(q.get(), "S6"), DS_OK);  // reusable once empty
    CHECK_EQ(queue_size(q.get()), 1u);
}

// ---------------------------------------------------------------------------
// Stack
// ---------------------------------------------------------------------------
TEST(stack_lifo_order) {
    StackHandle s = adoptHandle<StackHandle>(stack_create());
    MarksChange c{};
    CHECK(stack_is_empty(s.get()));
    CHECK_EQ(stack_pop(s.get(), &c), DS_ERR_EMPTY);
    CHECK_EQ(stack_peek(s.get(), &c), DS_ERR_EMPTY);
    for (int i = 1; i <= 3; ++i) {
        c.new_centi = i * 1000;
        CHECK_EQ(stack_push(s.get(), &c), DS_OK);
    }
    CHECK_EQ(stack_size(s.get()), 3u);
    stack_peek(s.get(), &c);
    CHECK_EQ(c.new_centi, 3000);
    stack_pop(s.get(), &c);
    CHECK_EQ(c.new_centi, 3000);
    stack_pop(s.get(), &c);
    CHECK_EQ(c.new_centi, 2000);
    stack_clear(s.get());
    CHECK(stack_is_empty(s.get()));
}

// ---------------------------------------------------------------------------
// Searching and sorting
// ---------------------------------------------------------------------------
namespace {
SortRecord rec(const char* key, const char* name, int score) {
    SortRecord r{};
    std::strncpy(r.key, key, DS_KEY_LEN - 1);
    std::strncpy(r.name, name, DS_NAME_LEN - 1);
    r.score = score;
    return r;
}
}  // namespace

TEST(merge_sort_orders) {
    std::vector<SortRecord> v = {rec("S4", "delta", 700), rec("S2", "Bravo", -1), rec("S3", "charlie", 920),
                                 rec("S1", "alpha", 700)};
    CHECK_EQ(ss_merge_sort(v.data(), v.size(), SORT_BY_KEY), DS_OK);
    CHECK(std::string(v[0].key) == "S1" && std::string(v[3].key) == "S4");
    ss_merge_sort(v.data(), v.size(), SORT_BY_NAME);  // case-insensitive
    CHECK(std::string(v[0].name) == "alpha" && std::string(v[1].name) == "Bravo");
    ss_merge_sort(v.data(), v.size(), SORT_BY_SCORE_DESC);
    CHECK_EQ(std::string(v[0].key), std::string("S3"));
    CHECK_EQ(std::string(v[1].key), std::string("S1"));  // tie on 700 -> key order
    CHECK_EQ(std::string(v[2].key), std::string("S4"));
    CHECK_EQ(std::string(v[3].key), std::string("S2"));  // no score sorts last
    CHECK(ss_is_sorted(v.data(), v.size(), SORT_BY_SCORE_DESC));
    CHECK(!ss_is_sorted(v.data(), v.size(), SORT_BY_KEY));
    CHECK_EQ(ss_merge_sort(nullptr, 0, SORT_BY_KEY), DS_OK);
}

TEST(linear_binary_and_name_search) {
    std::vector<SortRecord> v;
    char key[DS_KEY_LEN];
    for (int i = 999; i >= 0; --i) {  // unsorted (descending) input
        std::snprintf(key, sizeof key, "K%04d", i);
        v.push_back(rec(key, i % 2 ? "Riya Example" : "Arjun Sample", i));
    }
    std::size_t comparisons = 0;
    CHECK_EQ(ss_linear_search_key(v.data(), v.size(), "K0000", &comparisons), 999L);
    CHECK_EQ(comparisons, 1000u);
    CHECK_EQ(ss_linear_search_key(v.data(), v.size(), "NOPE", &comparisons), -1L);
    ss_merge_sort(v.data(), v.size(), SORT_BY_KEY);
    const long idx = ss_binary_search_key(v.data(), v.size(), "K0500", &comparisons);
    CHECK(idx >= 0 && std::string(v[static_cast<std::size_t>(idx)].key) == "K0500");
    CHECK(comparisons <= 10u);  // floor(log2 1000) + 1
    CHECK_EQ(ss_binary_search_key(v.data(), v.size(), "K9999", &comparisons), -1L);
    CHECK_EQ(ss_binary_search_key(v.data(), 0, "K0001", &comparisons), -1L);
    std::vector<std::size_t> hits(1000);
    CHECK_EQ(ss_search_name(v.data(), v.size(), "riya", hits.data(), hits.size()), 500u);
    CHECK_EQ(ss_search_name(v.data(), v.size(), "zzz", hits.data(), hits.size()), 0u);
}

int main() {
    return testing::runAllTests("C data structures (called through extern \"C\")");
}
