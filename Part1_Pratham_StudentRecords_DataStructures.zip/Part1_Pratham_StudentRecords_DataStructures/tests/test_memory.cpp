// test_memory.cpp
// Leak check that works without Valgrind/ASan (e.g. MinGW on Windows).
//
// Linked with  -Wl,--wrap=malloc,--wrap=calloc,--wrap=realloc,--wrap=free
// so the GNU linker sends every malloc/calloc/realloc/free call made by the
// linked object files (all C data-structure modules included) through the
// counting functions below. Each scenario records the number of live heap
// blocks before it starts and checks the number is the same after all its
// objects have been destroyed. Requires GNU ld (Linux, MinGW); see `make memcheck`.
#include <cstddef>
#include <cstdio>
#include <string>

#include "AcademicManager.hpp"
#include "CHandles.hpp"
#include "DemoData.hpp"
#include "FileManager.hpp"
#include "test_framework.hpp"

extern "C" {
void* __real_malloc(std::size_t size);
void* __real_calloc(std::size_t count, std::size_t size);
void* __real_realloc(void* ptr, std::size_t size);
void __real_free(void* ptr);

static long g_live = 0;        // blocks currently allocated
static long g_allocations = 0; // total allocations seen

void* __wrap_malloc(std::size_t size) {
    void* p = __real_malloc(size);
    if (p != nullptr) { ++g_live; ++g_allocations; }
    return p;
}
void* __wrap_calloc(std::size_t count, std::size_t size) {
    void* p = __real_calloc(count, size);
    if (p != nullptr) { ++g_live; ++g_allocations; }
    return p;
}
void* __wrap_realloc(void* ptr, std::size_t size) {
    void* p = __real_realloc(ptr, size);
    if (ptr == nullptr && p != nullptr) { ++g_live; ++g_allocations; }  // acts like malloc
    return p;
}
void __wrap_free(void* ptr) {
    if (ptr != nullptr) --g_live;
    __real_free(ptr);
}
}

using namespace academic;

namespace {
std::string g_dir = "build/test_data";
}

TEST(c_structures_free_every_block) {
    const long before = g_live;
    const long allocsBefore = g_allocations;
    {
        HashTableHandle t = adoptHandle<HashTableHandle>(ht_create(4));
        AVLTreeHandle tree = adoptHandle<AVLTreeHandle>(avl_create());
        QueueHandle q = adoptHandle<QueueHandle>(queue_create());
        StackHandle s = adoptHandle<StackHandle>(stack_create());
        GraphHandle g = adoptHandle<GraphHandle>(graph_create(2));
        LinkedListHandle list = adoptHandle<LinkedListHandle>(ll_create());
        char key[DS_KEY_LEN];
        MarksChange change{};
        for (int i = 0; i < 500; ++i) {
            std::snprintf(key, sizeof key, "K%04d", i);
            ht_insert(t.get(), key, i);          // includes several rehashes
            avl_insert(tree.get(), i % 50, key);
            queue_enqueue(q.get(), key);
            stack_push(s.get(), &change);
            ll_push_back(list.get(), key, i);
            graph_add_vertex(g.get(), i, key);   // includes realloc growth
            if (i > 0) graph_add_edge(g.get(), i, i - 1);
        }
        for (int i = 0; i < 500; i += 2) {       // partial removal before destroy
            std::snprintf(key, sizeof key, "K%04d", i);
            ht_remove(t.get(), key);
            avl_remove(tree.get(), i % 50, key);
            queue_remove(q.get(), key);
            stack_pop(s.get(), nullptr);
            ll_remove(list.get(), key);
        }
        graph_remove_vertex(g.get(), 250);
        std::vector<int> out(600);
        graph_all_prereqs(g.get(), 499, out.data(), out.size());  // temporary DFS buffers
        CHECK(g_allocations - allocsBefore > 2000);                // the wrapper really sees them
    }
    CHECK_EQ(g_live, before);
}

TEST(full_workflow_has_no_leaks) {
    const long before = g_live;
    {
        AcademicManager m;
        CHECK(loadSampleData(m).ok);
        m.registerForCourse("UG26001", "CS201");
        m.registerForCourse("UG26002", "CS201");
        m.registerForCourse("PG26002", "CS201");   // waitlisted or passed
        m.registerForCourse("UG26003", "CS201");   // waitlisted
        m.recordMarks("UG26004", "CS101", 77);
        m.recordMarks("UG26004", "CS101", 81);
        m.undoLastMarksEntry();
        m.cancelRegistration("UG26001", "CS201");  // FIFO promotion path
        m.addCourse("TMP1", "Temporary Course", 2, 5);
        m.addPrerequisite("TMP1", "CS101");
        m.removePrerequisite("TMP1", "CS101");
        m.removeCourse("TMP1");
        m.addStudent(StudentCategory::UG, "TMP01", "Temporary Student", "B.Tech", 1);
        m.recordMarks("TMP01", "CS101", 50);
        m.deleteStudent("TMP01");
        (void)m.ranking();
        (void)m.sortedStudents(StudentSortKey::Name);
        (void)m.searchDemo("UG26002");
        (void)m.studyOrder();

        FileManager files(g_dir + "/memcheck");
        std::string error;
        CHECK(files.save(m.exportSnapshot(), error));
        Snapshot snap;
        CHECK(files.load(snap, error) == LoadStatus::Loaded);
        AcademicManager restored;
        CHECK(restored.importSnapshot(snap).ok);

        snap.enrollments.push_back({"CS101", "NOBODY"});
        AcademicManager rejected;
        CHECK(!rejected.importSnapshot(snap).ok);  // half-built state must be freed
        m.clear();
    }
    CHECK_EQ(g_live, before);
}

int main(int argc, char** argv) {
    if (argc > 1) g_dir = argv[1];
    return testing::runAllTests("Memory (malloc/free balance via linker --wrap)");
}
