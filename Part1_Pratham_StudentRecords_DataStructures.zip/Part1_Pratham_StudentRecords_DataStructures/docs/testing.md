# Testing

## 1. How to run

```bash
make test        # three suites: data structures, academic workflow, persistence
make memcheck    # malloc/free balance check (needs GNU ld: Linux or MinGW)
make demo        # scripted 20-step CLI scenario, then a second run that reloads the saved file
make sanitize    # ASan + UBSan build of the tests (GCC/Clang on Linux/macOS)
make valgrind    # Valgrind on the tests (Linux)
```

The tests use a small harness (`tests/test_framework.hpp`). A test is reported PASS only if every
`CHECK` inside it held. Failing checks print the expression, the actual values and the line number.

## 2. Executed results

Environment for the run recorded below: Windows 11, MinGW GCC 6.3.0, `-O2 -Wall -Wextra -Wpedantic`,
C compiled with `-std=c11`, C++ with `-std=c++17`. The build produced **no warnings**.

| Suite | Tests | Checks | Result |
|---|---|---|---|
| `test_data_structures` | 14 | 1175 | 14 passed, 0 failed |
| `test_academic_workflow` | 14 | 143 | 14 passed, 0 failed |
| `test_persistence` | 5 | 44 | 5 passed, 0 failed |
| `test_memory` (`make memcheck`) | 2 | 8 | 2 passed, 0 failed |

During development the suite found a real bug: removing a key a second time, after its bucket had been
freed, returned "invalid argument" instead of "not found". It was fixed in `ht_remove`.

### Test table

| Area | Test | What is checked (expected) | Observed |
|---|---|---|---|
| Linked list | `linked_list_insert_find_traverse` | front/back insert order A,B,C; find; missing key → NOT_FOUND; update value; empty and over-long keys rejected | PASS |
| Linked list | `linked_list_delete_head_middle_tail` | delete tail then append (tail pointer correct); delete head and middle; double delete → NOT_FOUND; clear and reuse | PASS |
| Hash table | `hash_table_insert_find_update_remove` | insert, duplicate ID rejected, missing key, update, remove, removing twice → NOT_FOUND, invalid keys | PASS (after the fix above) |
| Hash table | `hash_table_collision_chaining` | two keys in the same bucket both retrievable; collision statistics; removing one keeps the other | PASS |
| Hash table | `hash_table_resizes_and_keeps_all_keys` | 2000 keys from 4 buckets: table grows, load factor ≤ 0.75, every key found with its value | PASS |
| AVL | `avl_stays_balanced_on_sorted_input` | 1023 sorted inserts: all invariants valid, height ≤ 1.45·log₂(n+2) | PASS |
| AVL | `avl_ranking_order_and_ties` | reverse inorder S1,S2,S3,S4 with tie broken by ID; inorder reversed; duplicate rejected; competition rank; threshold query | PASS |
| AVL | `avl_delete_cases_keep_invariants` | 67 deletions (leaf, one child, two children) with the tree validated after each one; contains/not found | PASS |
| Graph | `graph_prerequisite_chain_dfs` | nothing passed → missing [PF, DSA] in that order; DSA passed but not PF → missing PF (transitive); all passed → eligible; course without prerequisites | PASS |
| Graph | `graph_rejects_invalid_edges` | self-loop, duplicate edge, 3-cycle, 2-cycle and unknown vertex rejected; topological order; vertex removal drops its edges | PASS |
| Queue | `queue_fifo_order_and_removal` | empty dequeue/peek → EMPTY; positions; remove rear then enqueue; remove middle; FIFO order S1 S3 S5 | PASS |
| Stack | `stack_lifo_order` | empty pop/peek → EMPTY; LIFO order; clear | PASS |
| Sorting | `merge_sort_orders` | by key, by case-insensitive name, by score with ties by key and "no score" last; `ss_is_sorted` | PASS |
| Searching | `linear_binary_and_name_search` | linear = 1000 comparisons for the last element; binary ≤ 10 comparisons for n = 1000; not found; name substring | PASS |
| Students | `student_add_lookup_duplicate_and_validation` | insert, hash lookup, ID normalisation, missing student, duplicate ID, invalid ID/name, UG ≤ 8 and PG ≤ 4 semesters | PASS |
| Students | `student_update_and_search` | partial update keeps blank fields; invalid semester leaves the record unchanged; name search; sort by name | PASS |
| Students | `student_delete_respects_enrolment_constraint` | delete refused while enrolled; allowed after cancelling; removed from hash table and ranking; ID reusable | PASS |
| Courses | `course_add_update_remove_rules` | duplicate/invalid course rejected; cycle, self, duplicate and unknown prerequisites rejected; removal blocked by a dependent; study order | PASS |
| Results | `ug_and_pg_grading_differ_through_base_pointer` | 45 marks: UG → C, 5 points, pass; PG → F, fail (through `const Student*`) | PASS |
| Results | `marks_validation_and_cgpa` | −1, 100.5, NaN, unknown student/course rejected without an undo record; credit-weighted CGPA; credits earned | PASS |
| Results | `ranking_updates_after_marks_change` | rank order; equal CGPA → equal rank; ranking changes after a marks update; threshold query; inorder | PASS |
| Results | `undo_restores_marks_and_ranking` | empty undo fails; undoing an update restores the marks and the rank; undoing an entry removes the result; stack emptied | PASS |
| Results + Registration | `marks_change_cannot_invalidate_an_enrolment` | pass→fail refused while enrolled in a dependent course; pass→pass allowed; blocked undo keeps the record; allowed after cancelling | PASS |
| Registration | `registration_prerequisites_use_passed_results` | new student rejected (missing PF101) with no partial change; failed result does not count; already enrolled; already passed; unknown student/course | PASS |
| Registration | `registration_transitive_prerequisites` | DSA passed but PF missing → ADV rejected, missing PF101; accepted after PF passed | PASS |
| Registration | `full_course_waitlist_and_fifo_promotion` | 2 seats: positions 1, 2, 3; duplicate waitlist entry rejected; cancellation skips an ineligible front student and promotes the next; never above capacity; leave waitlist; capacity below enrolment refused | PASS |
| Registration | `capacity_increase_promotes_waitlist` | raising capacity promotes the front student; credits locked once results exist | PASS |
| Integration | `snapshot_round_trip_in_memory` | export → import keeps students, enrolment counts, waitlist position, prerequisites, ranking; undo not persisted | PASS |
| Persistence | `save_and_reload_restores_everything` | save twice (overwrite), no `.tmp` left; a new manager reloads names, programs, semesters, exact marks (72.50), PG fail, capacity, roster, waitlist order, prerequisites, ranking; reloaded waitlist still promotes FIFO | PASS |
| Persistence | `missing_file_is_reported_as_missing` | missing file → `Missing` | PASS |
| Persistence | `corrupted_files_are_detected` | flipped byte → checksum error; truncated, bad magic and empty files → `Corrupt`; quarantine renames the file | PASS |
| Persistence | `invalid_records_are_rejected_without_changing_state` | unknown student, cycle, over-capacity enrolment, duplicate waitlist entry → import refused, existing state kept | PASS |
| Persistence | `serialize_deserialize_is_lossless` | byte-identical re-serialisation; CRC-32("123456789") = CBF43926 | PASS |
| Memory | `c_structures_free_every_block` | every C structure built, partly emptied, then destroyed: live heap blocks back to the starting count (and > 2000 allocations observed) | PASS |
| Memory | `full_workflow_has_no_leaks` | sample data, registrations, waitlist, undo, deletions, save/load, rejected import: live blocks back to the starting count | PASS |

## 3. End-to-end CLI demonstration (executed)

`make demo` pipes `examples/sample_workflow.txt` into the application with a fresh data folder, then
starts the application again with `examples/after_restart.txt`. When input is piped, the program echoes each
answer, so the transcript can be read top to bottom. Observed outcomes:

| Step | Action | Observed |
|---|---|---|
| 1–2 | Admin adds 3 UG + 1 PG students and 4 courses | `[OK] Added ...` for each |
| 3 | Prerequisites CS201←CS101, CS301←CS201, CS301←MA101; then CS101←CS301 and CS201←CS201 | first three OK; "would create a prerequisite cycle"; "cannot be its own prerequisite" |
| 4 | Study order | `CS101, MA101, CS201, CS301` |
| 5–6 | Staff enters marks | UG26101 88 → A+; PG26101 45 → **F (PG pass mark 50)**; ranking printed |
| 7–8 | PG26101 requests CS201 | `[REJECTED] ... Not yet passed: CS101.` |
| 9–10 | UG26101 and UG26102 register (capacity 2) | enrolled 1/2, then 2/2 |
| 11 | UG26103 registers | "CS201 is full ... joined the waiting list at position 1" |
| 12–13 | UG26102 cancels | "Waitlist: UG26103 promoted to enrolled." |
| — | UG26102 re-registers | waitlisted at position 1 (kept for the restart check) |
| — | Staff tries to set UG26101 CS101 = 30 | rejected: enrolled in CS201, which requires a pass in CS101 |
| 14–15 | UG26103 CS101 65 → 91 | CGPA 7.00 → 10.00, rank 1 |
| 16 | Undo | "restored CS101 to 65.00 ... CGPA now 7.00, rank 3" |
| 17 | Save | `[SAVED]` |
| 18–19 | Restart | "Loaded 4 students, 4 courses, 5 results, 2 enrolments, 1 waitlist entries"; UG26103 enrolled in CS201; UG26102 still waitlisted at position 1; roster and prerequisites intact |
| 20 | DSA menu: statistics, search comparison, traversals, adjacency lists, queues, stack top, sorting, benchmark | all executed (sample below) |

Robustness checks run by hand: non-numeric and out-of-range menu input re-prompts; end of input in the
middle of a prompt saves and exits cleanly; a garbage data file at startup produces
"not an academic records file (bad magic number)", is renamed to `.corrupt`, and the program starts empty.

## 4. Benchmark methodology and a sample run

DSA menu → 8 generates a synthetic data set with a fixed seed and uses separate C structures, never the live
data. Every batch is repeated until at least 50 ms have passed. The output reports the mean time per batch and
the clock resolution, and each row checks its own results (e.g. "20000/20000 correct").

On the development machine the measured `steady_clock` resolution was about **0.6 ms**, so single short
batches would have been meaningless. This is why every batch is repeated.

Sample run (20,000 records; Windows 11, MinGW GCC 6.3, -O2). **These are not reference numbers. Re-run the
benchmark on the demonstration machine and quote that output.**

| Operation | Complexity | ns/op (this run) |
|---|---|---|
| Hash table lookup by ID | O(1) average | ≈ 38 |
| Binary search by ID (sorted) | O(log n) | ≈ 213 |
| Linear search by ID (unsorted) | O(n) | ≈ 70,000 |
| AVL search | O(log n) | ≈ 133 (height 17; bound 20.6) |
| Merge sort by ID (incl. copy + check) | O(n log n) | ≈ 343 per element |
| DFS check, 300-course chain | O(V+E) | ≈ 1,800 per check |
| Queue enqueue+dequeue / stack push+pop | O(1) | ≈ 64 / ≈ 36 per operation |

Reading the numbers: for 20,000 records the hash lookup was about 1,800× faster than a linear scan, and
binary search was much faster than linear search but slower than hashing. This matches the theory. Absolute
values change with the CPU, compiler, flags and system load.

## 5. Memory checking

| Method | Status on the development machine |
|---|---|
| `make memcheck` (linker `--wrap` counts every malloc/calloc/realloc/free) | **executed, passed** |
| `make sanitize` (AddressSanitizer + UndefinedBehaviorSanitizer) | not run: MinGW GCC 6.3 has no ASan support |
| `make valgrind` | not run: Valgrind is not available on Windows |

On Linux, run `make sanitize` and `make valgrind`. Valgrind should report
"All heap blocks were freed -- no leaks are possible" for each test executable.

`memcheck` catches leaks (unbalanced allocations). Unlike ASan/Valgrind it does **not** detect use-after-free
or buffer overruns. Those are guarded against by design instead: opaque handles, bounds-checked
`ds_copy_key`, the bounds-checked `ByteReader`, and a single owner for every allocation.
