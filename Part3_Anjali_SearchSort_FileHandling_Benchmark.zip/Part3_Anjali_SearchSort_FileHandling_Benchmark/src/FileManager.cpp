// FileManager.cpp
#include "FileManager.hpp"

#include <cstdio>
#include <cstring>
#include <fstream>
#include <iterator>
#include <utility>

#ifdef _WIN32
#include <direct.h>
#else
#include <sys/stat.h>
#include <sys/types.h>
#endif

namespace academic {

namespace {

const char kMagic[8] = {'S', 'A', 'R', 'C', 'R', 'S', 'D', 'B'};
const std::size_t kHeaderSize = 8 + 4 + 4;
const std::size_t kMaxFileSize = 64u * 1024u * 1024u;
const std::size_t kMaxString = 255;

// ---------------------------------------------------------------------------
// Little-endian writer: integers are written byte by byte so the file format
// does not depend on the machine's endianness or struct padding.
// ---------------------------------------------------------------------------
class ByteWriter {
public:
    void u8(unsigned value) { bytes_.push_back(static_cast<unsigned char>(value & 0xFFu)); }
    void u16(unsigned value) {
        u8(value);
        u8(value >> 8);
    }
    void u32(unsigned long value) {
        for (int shift = 0; shift < 32; shift += 8) u8(static_cast<unsigned>((value >> shift) & 0xFFu));
    }
    void str(const std::string& s) {
        const std::size_t n = s.size() < kMaxString ? s.size() : kMaxString;
        u16(static_cast<unsigned>(n));
        bytes_.insert(bytes_.end(), s.begin(), s.begin() + static_cast<std::ptrdiff_t>(n));
    }
    void tag(const char* t) { bytes_.insert(bytes_.end(), t, t + 4); }
    std::vector<unsigned char>& bytes() { return bytes_; }

private:
    std::vector<unsigned char> bytes_;
};

// ---------------------------------------------------------------------------
// Bounds-checked reader: any read past the end sets ok() to false instead of
// touching memory outside the buffer.
// ---------------------------------------------------------------------------
class ByteReader {
public:
    ByteReader(const unsigned char* data, std::size_t size) : data_(data), size_(size) {}

    bool ok() const { return ok_; }
    std::size_t remaining() const { return size_ - pos_; }

    unsigned u8() {
        if (!need(1)) return 0;
        return data_[pos_++];
    }
    unsigned u16() {
        unsigned lo = u8();
        unsigned hi = u8();
        return lo | (hi << 8);
    }
    unsigned long u32() {
        unsigned long v = 0;
        for (int shift = 0; shift < 32; shift += 8) v |= static_cast<unsigned long>(u8()) << shift;
        return v;
    }
    std::string str() {
        const unsigned n = u16();
        if (n > kMaxString || !need(n)) {
            ok_ = false;
            return std::string();
        }
        std::string s(reinterpret_cast<const char*>(data_ + pos_), n);
        pos_ += n;
        return s;
    }
    bool expectTag(const char* t) {
        if (!need(4) || std::memcmp(data_ + pos_, t, 4) != 0) {
            ok_ = false;
            return false;
        }
        pos_ += 4;
        return true;
    }
    // Reads a record count and rejects counts that could not possibly fit in
    // the remaining bytes (protects against huge allocations from bad files).
    std::size_t count(std::size_t minRecordBytes) {
        const unsigned long n = u32();
        if (!ok_ || n > remaining() / minRecordBytes) {
            ok_ = false;
            return 0;
        }
        return static_cast<std::size_t>(n);
    }

private:
    bool need(std::size_t n) {
        if (!ok_ || n > size_ - pos_) {
            ok_ = false;
            return false;
        }
        return true;
    }

    const unsigned char* data_;
    std::size_t size_;
    std::size_t pos_ = 0;
    bool ok_ = true;
};

bool fileExists(const std::string& path) {
    std::ifstream in(path.c_str(), std::ios::binary);
    return in.good();
}

void makeOneDirectory(const std::string& dir) {
#ifdef _WIN32
    _mkdir(dir.c_str());
#else
    mkdir(dir.c_str(), 0755);
#endif
}

// Creates dir and any missing parents ("a/b/c" -> "a", "a/b", "a/b/c").
// An already-existing directory is not an error; a real failure shows up
// when the data file itself cannot be opened for writing.
void makeDirectory(const std::string& dir) {
    for (std::size_t i = 1; i < dir.size(); ++i) {
        if (dir[i] == '/' || dir[i] == '\\') {
            makeOneDirectory(dir.substr(0, i));
        }
    }
    makeOneDirectory(dir);
}

}  // namespace

FileManager::FileManager(std::string dataDirectory)
    : directory_(std::move(dataDirectory)), file_(directory_ + "/academic_records.dat") {}

unsigned long FileManager::crc32(const unsigned char* data, std::size_t length) {
    // Bitwise CRC-32 (IEEE 802.3, reflected polynomial 0xEDB88320).
    unsigned long crc = 0xFFFFFFFFUL;
    for (std::size_t i = 0; i < length; ++i) {
        crc ^= data[i];
        for (int bit = 0; bit < 8; ++bit) {
            crc = (crc & 1UL) ? (crc >> 1) ^ 0xEDB88320UL : crc >> 1;
        }
    }
    return (crc ^ 0xFFFFFFFFUL) & 0xFFFFFFFFUL;
}

std::vector<unsigned char> FileManager::serialize(const Snapshot& snap) {
    ByteWriter p;  // payload
    p.tag("STUD");
    p.u32(snap.students.size());
    for (const StudentRecord& s : snap.students) {
        p.str(s.id);
        p.str(s.name);
        p.str(s.program);
        p.u8(static_cast<unsigned>(s.category));
        p.u8(static_cast<unsigned>(s.semester));
    }
    p.tag("CRSE");
    p.u32(snap.courses.size());
    for (const CourseRecord& c : snap.courses) {
        p.str(c.code);
        p.str(c.title);
        p.u8(static_cast<unsigned>(c.credits));
        p.u16(static_cast<unsigned>(c.capacity));
    }
    p.tag("PREQ");
    p.u32(snap.prerequisites.size());
    for (const PrerequisiteRecord& e : snap.prerequisites) {
        p.str(e.courseCode);
        p.str(e.prereqCode);
    }
    p.tag("RSLT");
    p.u32(snap.results.size());
    for (const ResultRecord& r : snap.results) {
        p.str(r.studentId);
        p.str(r.courseCode);
        p.u16(static_cast<unsigned>(r.centiMarks));
        p.u8(static_cast<unsigned>(r.credits));
    }
    p.tag("ENRL");
    p.u32(snap.enrollments.size());
    for (const EnrollmentRecord& e : snap.enrollments) {
        p.str(e.courseCode);
        p.str(e.studentId);
    }
    p.tag("WAIT");
    p.u32(snap.waitlists.size());
    for (const EnrollmentRecord& e : snap.waitlists) {
        p.str(e.courseCode);
        p.str(e.studentId);
    }

    const std::vector<unsigned char>& payload = p.bytes();
    ByteWriter file;
    file.bytes().insert(file.bytes().end(), kMagic, kMagic + 8);
    file.u32(kFormatVersion);
    file.u32(payload.size());
    file.bytes().insert(file.bytes().end(), payload.begin(), payload.end());
    file.u32(crc32(payload.data(), payload.size()));
    return std::move(file.bytes());
}

bool FileManager::deserialize(const std::vector<unsigned char>& bytes, Snapshot& out, std::string& error) {
    if (bytes.size() < kHeaderSize + 4 || std::memcmp(bytes.data(), kMagic, 8) != 0) {
        error = "not an academic records file (bad magic number)";
        return false;
    }
    ByteReader header(bytes.data() + 8, 8);
    const unsigned long version = header.u32();
    const unsigned long length = header.u32();
    if (version != kFormatVersion) {
        error = "unsupported file format version " + std::to_string(version);
        return false;
    }
    if (length != bytes.size() - kHeaderSize - 4) {
        error = "file is truncated or has trailing bytes";
        return false;
    }
    const unsigned char* payload = bytes.data() + kHeaderSize;
    ByteReader crcReader(payload + length, 4);
    if (crcReader.u32() != crc32(payload, length)) {
        error = "checksum mismatch (file is corrupted)";
        return false;
    }

    Snapshot snap;
    ByteReader in(payload, length);
    // minimum bytes per record: each string costs at least its 2-byte length
    in.expectTag("STUD");
    snap.students.resize(in.count(8));
    for (StudentRecord& s : snap.students) {
        s.id = in.str();
        s.name = in.str();
        s.program = in.str();
        s.category = static_cast<int>(in.u8());
        s.semester = static_cast<int>(in.u8());
    }
    in.expectTag("CRSE");
    snap.courses.resize(in.count(7));
    for (CourseRecord& c : snap.courses) {
        c.code = in.str();
        c.title = in.str();
        c.credits = static_cast<int>(in.u8());
        c.capacity = static_cast<int>(in.u16());
    }
    in.expectTag("PREQ");
    snap.prerequisites.resize(in.count(4));
    for (PrerequisiteRecord& e : snap.prerequisites) {
        e.courseCode = in.str();
        e.prereqCode = in.str();
    }
    in.expectTag("RSLT");
    snap.results.resize(in.count(7));
    for (ResultRecord& r : snap.results) {
        r.studentId = in.str();
        r.courseCode = in.str();
        r.centiMarks = static_cast<int>(in.u16());
        r.credits = static_cast<int>(in.u8());
    }
    in.expectTag("ENRL");
    snap.enrollments.resize(in.count(4));
    for (EnrollmentRecord& e : snap.enrollments) {
        e.courseCode = in.str();
        e.studentId = in.str();
    }
    in.expectTag("WAIT");
    snap.waitlists.resize(in.count(4));
    for (EnrollmentRecord& e : snap.waitlists) {
        e.courseCode = in.str();
        e.studentId = in.str();
    }
    if (!in.ok() || in.remaining() != 0) {
        error = "malformed record data";
        return false;
    }
    out = std::move(snap);
    return true;
}

bool FileManager::save(const Snapshot& snapshot, std::string& error) const {
    makeDirectory(directory_);
    const std::vector<unsigned char> bytes = serialize(snapshot);
    const std::string tmp = file_ + ".tmp";
    const std::string bak = file_ + ".bak";
    {
        std::ofstream out(tmp.c_str(), std::ios::binary | std::ios::trunc);
        if (!out) {
            error = "cannot open " + tmp + " for writing";
            return false;
        }
        out.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        out.flush();
        if (!out) {
            error = "write to " + tmp + " failed";
            std::remove(tmp.c_str());
            return false;
        }
    }
    // Swap the new file in. std::rename cannot overwrite on every platform, so
    // keep the old file as .bak until the new one is in place.
    std::remove(bak.c_str());
    const bool hadOld = fileExists(file_);
    if (hadOld && std::rename(file_.c_str(), bak.c_str()) != 0) {
        error = "cannot replace " + file_;
        std::remove(tmp.c_str());
        return false;
    }
    if (std::rename(tmp.c_str(), file_.c_str()) != 0) {
        if (hadOld) std::rename(bak.c_str(), file_.c_str());  // restore previous data
        error = "cannot move " + tmp + " into place";
        return false;
    }
    std::remove(bak.c_str());
    return true;
}

LoadStatus FileManager::load(Snapshot& snapshot, std::string& error) const {
    std::ifstream in(file_.c_str(), std::ios::binary);
    if (!in) {
        return LoadStatus::Missing;
    }
    in.seekg(0, std::ios::end);
    const std::streamoff size = in.tellg();
    in.seekg(0, std::ios::beg);
    if (size < 0 || static_cast<unsigned long long>(size) > kMaxFileSize) {
        error = "file size is invalid";
        return LoadStatus::Corrupt;
    }
    std::vector<unsigned char> bytes(static_cast<std::size_t>(size));
    if (!bytes.empty() && !in.read(reinterpret_cast<char*>(bytes.data()), size)) {
        error = "could not read the file";
        return LoadStatus::Corrupt;
    }
    if (!deserialize(bytes, snapshot, error)) {
        return LoadStatus::Corrupt;
    }
    return LoadStatus::Loaded;
}

bool FileManager::quarantine(std::string& movedTo) const {
    movedTo = file_ + ".corrupt";
    std::remove(movedTo.c_str());
    return std::rename(file_.c_str(), movedTo.c_str()) == 0;
}

}  // namespace academic
