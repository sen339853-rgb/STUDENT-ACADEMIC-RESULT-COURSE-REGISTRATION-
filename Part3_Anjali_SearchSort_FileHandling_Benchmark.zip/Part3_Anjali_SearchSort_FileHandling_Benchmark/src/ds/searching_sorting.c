/*
 * searching_sorting.c
 * Top-down merge sort plus linear, binary and substring search.
 */
#include "ds/searching_sorting.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

static int compare_ci(const char *a, const char *b)
{
    while (*a != '\0' && *b != '\0') {
        int ca = tolower((unsigned char)*a);
        int cb = tolower((unsigned char)*b);
        if (ca != cb) {
            return ca - cb;
        }
        ++a;
        ++b;
    }
    return tolower((unsigned char)*a) - tolower((unsigned char)*b);
}

int ss_compare(const SortRecord *a, const SortRecord *b, int order)
{
    int c;
    switch (order) {
    case SORT_BY_NAME:
        c = compare_ci(a->name, b->name);
        return c != 0 ? c : strcmp(a->key, b->key);
    case SORT_BY_SCORE_DESC:
    case SORT_BY_SCORE_ASC:
        if (a->score != b->score) {
            /* records without a score (-1) always go last */
            if (a->score < 0) return 1;
            if (b->score < 0) return -1;
            if (order == SORT_BY_SCORE_DESC) {
                return a->score > b->score ? -1 : 1;
            }
            return a->score < b->score ? -1 : 1;
        }
        return strcmp(a->key, b->key);
    case SORT_BY_KEY:
    default:
        return strcmp(a->key, b->key);
    }
}

/* Merge the sorted halves [lo, mid) and [mid, hi) using tmp as scratch. */
static void merge(SortRecord *arr, SortRecord *tmp, size_t lo, size_t mid, size_t hi, int order)
{
    size_t i = lo;
    size_t j = mid;
    size_t k = lo;
    while (i < mid && j < hi) {
        /* "<= 0" takes from the left half on ties -> the sort is stable */
        if (ss_compare(&arr[i], &arr[j], order) <= 0) {
            tmp[k++] = arr[i++];
        } else {
            tmp[k++] = arr[j++];
        }
    }
    while (i < mid) {
        tmp[k++] = arr[i++];
    }
    while (j < hi) {
        tmp[k++] = arr[j++];
    }
    memcpy(arr + lo, tmp + lo, (hi - lo) * sizeof(SortRecord));
}

static void merge_sort_range(SortRecord *arr, SortRecord *tmp, size_t lo, size_t hi, int order)
{
    size_t mid;
    if (hi - lo < 2) {
        return; /* 0 or 1 element is already sorted */
    }
    mid = lo + (hi - lo) / 2;
    merge_sort_range(arr, tmp, lo, mid, order);
    merge_sort_range(arr, tmp, mid, hi, order);
    merge(arr, tmp, lo, mid, hi, order);
}

int ss_merge_sort(SortRecord *records, size_t n, int order)
{
    SortRecord *tmp;
    if (records == NULL && n > 0) {
        return DS_ERR_INVALID;
    }
    if (n < 2) {
        return DS_OK;
    }
    tmp = (SortRecord *)malloc(n * sizeof(SortRecord));
    if (tmp == NULL) {
        return DS_ERR_ALLOC;
    }
    merge_sort_range(records, tmp, 0, n, order);
    free(tmp);
    return DS_OK;
}

int ss_is_sorted(const SortRecord *records, size_t n, int order)
{
    size_t i;
    for (i = 1; i < n; ++i) {
        if (ss_compare(&records[i - 1], &records[i], order) > 0) {
            return 0;
        }
    }
    return 1;
}

long ss_linear_search_key(const SortRecord *records, size_t n, const char *key,
                          size_t *comparisons)
{
    size_t i;
    size_t count = 0;
    long found = -1;
    if (records != NULL && key != NULL) {
        for (i = 0; i < n; ++i) {
            count++;
            if (strcmp(records[i].key, key) == 0) {
                found = (long)i;
                break;
            }
        }
    }
    if (comparisons != NULL) {
        *comparisons = count;
    }
    return found;
}

long ss_binary_search_key(const SortRecord *records, size_t n, const char *key,
                          size_t *comparisons)
{
    size_t lo = 0;
    size_t hi = n; /* search window is [lo, hi) */
    size_t count = 0;
    long found = -1;
    if (records != NULL && key != NULL) {
        while (lo < hi) {
            size_t mid = lo + (hi - lo) / 2; /* avoids (lo + hi) overflow */
            int c = strcmp(records[mid].key, key);
            count++;
            if (c == 0) {
                found = (long)mid;
                break;
            }
            if (c < 0) {
                lo = mid + 1;   /* key is in the right half */
            } else {
                hi = mid;       /* key is in the left half  */
            }
        }
    }
    if (comparisons != NULL) {
        *comparisons = count;
    }
    return found;
}

static int contains_ci(const char *haystack, const char *needle)
{
    size_t hlen = strlen(haystack);
    size_t nlen = strlen(needle);
    size_t i;
    size_t j;
    if (nlen == 0) {
        return 1;
    }
    for (i = 0; i + nlen <= hlen; ++i) {
        for (j = 0; j < nlen; ++j) {
            if (tolower((unsigned char)haystack[i + j]) != tolower((unsigned char)needle[j])) {
                break;
            }
        }
        if (j == nlen) {
            return 1;
        }
    }
    return 0;
}

size_t ss_search_name(const SortRecord *records, size_t n, const char *fragment,
                      size_t *out_idx, size_t max)
{
    size_t i;
    size_t count = 0;
    if (records == NULL || fragment == NULL || out_idx == NULL) {
        return 0;
    }
    for (i = 0; i < n && count < max; ++i) {
        if (contains_ci(records[i].name, fragment)) {
            out_idx[count++] = i;
        }
    }
    return count;
}
