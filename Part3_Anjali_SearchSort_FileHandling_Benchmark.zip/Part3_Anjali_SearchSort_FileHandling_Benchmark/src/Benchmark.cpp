// Benchmark.cpp
// Uses separate, throw-away C structures so the live academic data is never
// touched by the benchmark.
//
// Some platforms' steady_clock only ticks every ~1 ms, which would make one
// short batch meaningless. So every measurement repeats its batch until at
// least kMinMeasureMs has elapsed and reports the average per batch; the
// measured clock resolution is printed alongside the results.
#include "Benchmark.hpp"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <iomanip>

#include "CHandles.hpp"
#include "ds/searching_sorting.h"

namespace academic {

namespace {

using Clock = std::chrono::steady_clock;
const double kMinMeasureMs = 50.0;

double msSince(Clock::time_point start) {
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

// Smallest observable non-zero step of the clock, in microseconds.
double clockResolutionUs() {
    double best = 1e9;
    for (int i = 0; i < 5; ++i) {
        const Clock::time_point a = Clock::now();
        Clock::time_point b = Clock::now();
        while (b == a) b = Clock::now();
        const double us = std::chrono::duration<double, std::micro>(b - a).count();
        if (us < best) best = us;
    }
    return best;
}

// Runs batch() until kMinMeasureMs has passed; returns mean ms per batch.
// batch() returns how many of its operations produced the correct answer;
// the value from the last repetition is stored in correct.
template <typename Batch>
double measure(Batch batch, std::size_t& correct, std::size_t& repetitions) {
    repetitions = 0;
    const Clock::time_point start = Clock::now();
    double elapsed = 0.0;
    do {
        correct = batch();
        ++repetitions;
        elapsed = msSince(start);
    } while (elapsed < kMinMeasureMs);
    return elapsed / static_cast<double>(repetitions);
}

// Small deterministic generator (LCG) so every run uses the same data set.
class Lcg {
public:
    explicit Lcg(unsigned long seed) : state_(seed) {}
    unsigned long next() {
        state_ = (state_ * 1103515245UL + 12345UL) & 0x7FFFFFFFUL;
        return state_;
    }

private:
    unsigned long state_;
};

std::vector<SortRecord> makeRecords(std::size_t n) {
    std::vector<SortRecord> records(n);
    std::vector<std::size_t> order(n);
    for (std::size_t i = 0; i < n; ++i) order[i] = i;
    Lcg rng(2026);
    for (std::size_t i = n; i > 1; --i) {  // Fisher-Yates shuffle: IDs arrive unsorted
        std::size_t j = rng.next() % i;
        std::size_t t = order[i - 1];
        order[i - 1] = order[j];
        order[j] = t;
    }
    for (std::size_t i = 0; i < n; ++i) {
        std::snprintf(records[i].key, DS_KEY_LEN, "BM%07lu", static_cast<unsigned long>(order[i]));
        for (int c = 0; c < 10; ++c) records[i].name[c] = static_cast<char>('a' + rng.next() % 26);
        records[i].name[10] = '\0';
        records[i].score = static_cast<int>(rng.next() % 1001);  // CGPA 0.00-10.00 as x100
    }
    return records;
}

BenchmarkRow row(const std::string& op, const std::string& complexity, std::size_t ops, double ms,
                 std::size_t reps, const std::string& check) {
    BenchmarkRow r;
    r.operation = op;
    r.complexity = complexity;
    r.operations = ops;
    r.totalMs = ms;
    r.nsPerOperation = ops == 0 ? 0.0 : ms * 1.0e6 / static_cast<double>(ops);
    r.repetitions = reps;
    r.check = check;
    return r;
}

std::string verdict(std::size_t ok, std::size_t total) {
    return std::to_string(ok) + "/" + std::to_string(total) + (ok == total ? " correct" : " WRONG");
}

}  // namespace

std::vector<BenchmarkRow> runBenchmarks(std::size_t n) {
    if (n < 100) n = 100;
    std::vector<BenchmarkRow> rows;
    const std::vector<SortRecord> records = makeRecords(n);
    const std::size_t linearQueries = n < 2000 ? n : 2000;  // O(n) each, so fewer
    std::size_t ok = 0;
    std::size_t reps = 0;
    double ms = 0.0;

    // --- Hash table ----------------------------------------------------------
    ms = measure([&]() {
        HashTableHandle t = adoptHandle<HashTableHandle>(ht_create(16));
        std::size_t inserted = 0;
        for (std::size_t i = 0; i < n; ++i) {
            if (ht_insert(t.get(), records[i].key, static_cast<int>(i)) == DS_OK) ++inserted;
        }
        return inserted;  // the table is freed when t goes out of scope
    }, ok, reps);
    rows.push_back(row("Hash table build (insert + resizes + free)", "O(1) amortised", n, ms, reps, verdict(ok, n)));

    HashTableHandle table = adoptHandle<HashTableHandle>(ht_create(16));
    for (std::size_t i = 0; i < n; ++i) ht_insert(table.get(), records[i].key, static_cast<int>(i));
    ms = measure([&]() {
        std::size_t found = 0;
        for (std::size_t q = 0; q < n; ++q) {
            int value = -1;
            const std::size_t i = (q * 7919) % n;
            if (ht_find(table.get(), records[i].key, &value) == DS_OK && value == static_cast<int>(i)) ++found;
        }
        return found;
    }, ok, reps);
    rows.push_back(row("Hash table lookup by ID", "O(1) average", n, ms, reps, verdict(ok, n)));

    // --- Linear search on the unsorted array ---------------------------------
    ms = measure([&]() {
        std::size_t found = 0;
        for (std::size_t q = 0; q < linearQueries; ++q) {
            const std::size_t i = (q * 7919) % n;
            if (ss_linear_search_key(records.data(), n, records[i].key, nullptr) == static_cast<long>(i)) ++found;
        }
        return found;
    }, ok, reps);
    rows.push_back(row("Linear search by ID (unsorted)", "O(n)", linearQueries, ms, reps, verdict(ok, linearQueries)));

    // --- Merge sort (each repetition sorts a fresh copy of the input) --------
    std::vector<SortRecord> work(n);
    ms = measure([&]() {
        work = records;
        ss_merge_sort(work.data(), n, SORT_BY_KEY);
        return static_cast<std::size_t>(ss_is_sorted(work.data(), n, SORT_BY_KEY));
    }, ok, reps);
    rows.push_back(row("Merge sort by ID (incl. copy + check)", "O(n log n)", n, ms, reps,
                       ok ? "sorted order verified" : "NOT SORTED"));
    ms = measure([&]() {
        work = records;
        ss_merge_sort(work.data(), n, SORT_BY_NAME);
        return static_cast<std::size_t>(ss_is_sorted(work.data(), n, SORT_BY_NAME));
    }, ok, reps);
    rows.push_back(row("Merge sort by name (incl. copy + check)", "O(n log n)", n, ms, reps,
                       ok ? "sorted order verified" : "NOT SORTED"));

    // --- Binary search on the sorted array -----------------------------------
    std::vector<SortRecord> byKey = records;
    ss_merge_sort(byKey.data(), n, SORT_BY_KEY);
    ms = measure([&]() {
        std::size_t found = 0;
        for (std::size_t q = 0; q < n; ++q) {
            const std::size_t i = (q * 7919) % n;
            const long idx = ss_binary_search_key(byKey.data(), n, records[i].key, nullptr);
            if (idx >= 0 && std::string(byKey[static_cast<std::size_t>(idx)].key) == records[i].key) ++found;
        }
        return found;
    }, ok, reps);
    rows.push_back(row("Binary search by ID (sorted)", "O(log n)", n, ms, reps, verdict(ok, n)));

    // --- AVL ranking tree ----------------------------------------------------
    ms = measure([&]() {
        AVLTreeHandle t = adoptHandle<AVLTreeHandle>(avl_create());
        std::size_t inserted = 0;
        for (std::size_t i = 0; i < n; ++i) {
            if (avl_insert(t.get(), records[i].score, records[i].key) == DS_OK) ++inserted;
        }
        return inserted;
    }, ok, reps);
    rows.push_back(row("AVL build (insert + free)", "O(log n) each", n, ms, reps, verdict(ok, n)));

    AVLTreeHandle tree = adoptHandle<AVLTreeHandle>(avl_create());
    for (std::size_t i = 0; i < n; ++i) avl_insert(tree.get(), records[i].score, records[i].key);
    ms = measure([&]() {
        std::size_t found = 0;
        for (std::size_t q = 0; q < n; ++q) {
            const std::size_t i = (q * 7919) % n;
            if (avl_contains(tree.get(), records[i].score, records[i].key)) ++found;
        }
        return found;
    }, ok, reps);
    char heightNote[128];
    std::snprintf(heightNote, sizeof heightNote, "%s; height %d, AVL bound 1.44*log2(n+2) = %.1f, valid=%s",
                  verdict(ok, n).c_str(), avl_height(tree.get()), 1.44 * std::log2(static_cast<double>(n) + 2.0),
                  avl_validate(tree.get()) ? "yes" : "NO");
    rows.push_back(row("AVL search", "O(log n)", n, ms, reps, heightNote));

    std::vector<AVLEntry> ranked(n);
    ms = measure([&]() {
        const std::size_t walked = avl_reverse_inorder(tree.get(), ranked.data(), n);
        std::size_t inOrder = walked > 0 ? 1 : 0;
        for (std::size_t i = 1; i < walked; ++i) {
            if (ranked[i - 1].score >= ranked[i].score) ++inOrder;
        }
        return inOrder;
    }, ok, reps);
    rows.push_back(row("AVL reverse inorder (full ranking)", "O(n)", n, ms, reps,
                       ok == n ? "descending CGPA verified" : "ORDER WRONG"));

    // --- Prerequisite graph: a long chain C0 <- C1 <- ... <- C(k-1) ---------
    const int chain = 300;
    GraphHandle graph = adoptHandle<GraphHandle>(graph_create(static_cast<std::size_t>(chain)));
    char label[DS_KEY_LEN];
    for (int v = 0; v < chain; ++v) {
        std::snprintf(label, sizeof label, "G%d", v);
        graph_add_vertex(graph.get(), v, label);
        if (v > 0) graph_add_edge(graph.get(), v, v - 1);  // each course requires the previous one
    }
    std::vector<unsigned char> passed(static_cast<std::size_t>(chain), 1);
    const std::size_t dfsRuns = 100;
    ms = measure([&]() {
        std::size_t eligible = 0;
        for (std::size_t r = 0; r < dfsRuns; ++r) {
            std::size_t missing = 1;
            graph_check_prereqs(graph.get(), chain - 1, passed.data(), passed.size(), nullptr, 0, &missing);
            if (missing == 0) ++eligible;
        }
        return eligible;
    }, ok, reps);
    rows.push_back(row("DFS prerequisite check (300-course chain)", "O(V + E)", dfsRuns, ms, reps, verdict(ok, dfsRuns)));

    // --- Queue and stack -----------------------------------------------------
    ms = measure([&]() {
        QueueHandle q = adoptHandle<QueueHandle>(queue_create());
        for (std::size_t i = 0; i < n; ++i) queue_enqueue(q.get(), records[i].key);
        std::size_t fifo = 0;
        char out[DS_KEY_LEN];
        for (std::size_t i = 0; i < n; ++i) {
            if (queue_dequeue(q.get(), out, sizeof out) == DS_OK && std::string(out) == records[i].key) ++fifo;
        }
        return fifo;
    }, ok, reps);
    rows.push_back(row("Queue enqueue + dequeue", "O(1) each", 2 * n, ms, reps, "FIFO order " + verdict(ok, n)));

    ms = measure([&]() {
        StackHandle s = adoptHandle<StackHandle>(stack_create());
        MarksChange change{};
        for (std::size_t i = 0; i < n; ++i) {
            change.new_centi = static_cast<int>(i);
            stack_push(s.get(), &change);
        }
        std::size_t lifo = 0;
        for (std::size_t i = n; i > 0; --i) {
            if (stack_pop(s.get(), &change) == DS_OK && change.new_centi == static_cast<int>(i - 1)) ++lifo;
        }
        return lifo;
    }, ok, reps);
    rows.push_back(row("Stack push + pop", "O(1) each", 2 * n, ms, reps, "LIFO order " + verdict(ok, n)));

    return rows;  // RAII handles free every benchmark structure here
}

void printBenchmarks(std::ostream& out, const std::vector<BenchmarkRow>& rows, std::size_t records) {
    out << "\nSynthetic data set: " << records << " records (fixed seed). Timer: std::chrono::steady_clock, "
        << "measured resolution " << std::fixed << std::setprecision(1) << clockResolutionUs() << " us.\n"
        << "Each batch is repeated until at least " << kMinMeasureMs
        << " ms have elapsed; 'Batch ms' is the mean per repetition.\n\n";
    out << std::left << std::setw(43) << "Operation" << std::setw(16) << "Complexity" << std::right << std::setw(7)
        << "Ops" << std::setw(6) << "Reps" << std::setw(11) << "Batch ms" << std::setw(11) << "ns/op" << "  Check\n";
    out << std::string(118, '-') << '\n';
    for (const BenchmarkRow& r : rows) {
        out << std::left << std::setw(43) << r.operation << std::setw(16) << r.complexity << std::right
            << std::setw(7) << r.operations << std::setw(6) << r.repetitions << std::setw(11) << std::setprecision(3)
            << r.totalMs << std::setw(11) << std::setprecision(1) << r.nsPerOperation << "  " << r.check << '\n';
    }
    out.unsetf(std::ios::floatfield);
    out << std::setprecision(6)
        << "\nThese are measurements on this machine only. Big-O describes how cost grows with n;\n"
        << "the timings show actual cost here and will differ on other hardware or build flags.\n";
}

}  // namespace academic
