// test_persistence.cpp
// Binary save/load through FileManager, including corrupted-file handling.
// Usage: test_persistence <scratch-directory>   (default: build/test_data)
#include <cstdio>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

#include "AcademicManager.hpp"
#include "FileManager.hpp"
#include "test_framework.hpp"

using namespace academic;

namespace {

std::string g_dir = "build/test_data";

void buildState(AcademicManager& m) {
    m.addCourse("PF101", "Programming Fundamentals", 4, 30);
    m.addCourse("DSA201", "Data Structures", 4, 1);
    m.addCourse("ADV301", "Advanced Algorithms", 3, 10);
    m.addPrerequisite("DSA201", "PF101");
    m.addPrerequisite("ADV301", "DSA201");
    m.addStudent(StudentCategory::UG, "UG001", "First Student", "B.Tech CSE", 3);
    m.addStudent(StudentCategory::UG, "UG002", "Second Student", "B.Tech CSE", 3);
    m.addStudent(StudentCategory::UG, "UG003", "Third Student", "B.Tech CSE", 3);
    m.addStudent(StudentCategory::PG, "PG001", "Fourth Student", "M.Tech CSE", 2);
    for (const char* id : {"UG001", "UG002", "UG003", "PG001"}) m.recordMarks(id, "PF101", 72.5);
    m.recordMarks("PG001", "DSA201", 49);                 // PG fail
    m.registerForCourse("UG001", "DSA201");              // takes the only seat
    m.registerForCourse("UG003", "DSA201");              // waitlist #1
    m.registerForCourse("UG002", "DSA201");              // waitlist #2
}

std::vector<unsigned char> readAll(const std::string& path) {
    std::ifstream in(path.c_str(), std::ios::binary);
    return std::vector<unsigned char>(std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>());
}

void writeAll(const std::string& path, const std::vector<unsigned char>& bytes) {
    std::ofstream out(path.c_str(), std::ios::binary | std::ios::trunc);
    out.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
}

bool exists(const std::string& path) {
    std::ifstream in(path.c_str());
    return in.good();
}

}  // namespace

TEST(save_and_reload_restores_everything) {
    FileManager files(g_dir + "/roundtrip");
    AcademicManager original;
    buildState(original);
    std::string error;
    CHECK(files.save(original.exportSnapshot(), error));
    CHECK(!exists(files.dataFile() + ".tmp"));       // temp file swapped into place
    CHECK(files.save(original.exportSnapshot(), error));  // overwriting an existing file works

    // "restart": a brand-new manager loads the file
    AcademicManager restarted;
    Snapshot snap;
    CHECK(files.load(snap, error) == LoadStatus::Loaded);
    CHECK(restarted.importSnapshot(snap).ok);

    const Student* s = restarted.findStudent("UG002");
    CHECK(s != nullptr && s->name() == "Second Student" && s->program() == "B.Tech CSE" && s->semester() == 3);
    CHECK(restarted.findStudent("PG001")->category() == StudentCategory::PG);
    CHECK_EQ(restarted.findStudent("UG001")->findResult("PF101")->centiMarks(), 7250);  // 72.50 exact
    CHECK(!restarted.findStudent("PG001")->hasPassed("DSA201"));
    const Course* c = restarted.findCourse("DSA201");
    CHECK(c != nullptr && c->capacity() == 1 && c->enrolledCount() == 1 && c->isEnrolled("UG001"));
    const auto wait = c->waitlistIds();
    CHECK(wait.size() == 2 && wait[0] == "UG003" && wait[1] == "UG002");  // FIFO order kept
    const auto chain = restarted.allPrerequisites("ADV301");
    CHECK(chain.size() == 2 && chain[0] == "PF101");
    CHECK_EQ(restarted.ranking().size(), original.ranking().size());
    CHECK_EQ(restarted.rankOf("UG003"), original.rankOf("UG003"));

    // the restored waitlist still behaves as a FIFO queue
    CHECK(restarted.cancelRegistration("UG001", "DSA201").ok);
    CHECK(c->isEnrolled("UG003"));
    CHECK_EQ(c->waitlistPosition("UG002"), 1u);
}

TEST(missing_file_is_reported_as_missing) {
    FileManager files(g_dir + "/does_not_exist");
    Snapshot snap;
    std::string error;
    CHECK(files.load(snap, error) == LoadStatus::Missing);
    CHECK(snap.students.empty());
}

TEST(corrupted_files_are_detected) {
    FileManager files(g_dir + "/corrupt");
    AcademicManager m;
    buildState(m);
    std::string error;
    CHECK(files.save(m.exportSnapshot(), error));
    const std::vector<unsigned char> good = readAll(files.dataFile());
    CHECK(good.size() > 40);
    Snapshot snap;

    std::vector<unsigned char> flipped = good;
    flipped[good.size() / 2] ^= 0x5A;                   // one corrupted payload byte
    writeAll(files.dataFile(), flipped);
    CHECK(files.load(snap, error) == LoadStatus::Corrupt);
    CHECK(error.find("checksum") != std::string::npos);

    std::vector<unsigned char> truncated(good.begin(), good.begin() + static_cast<std::ptrdiff_t>(good.size() - 10));
    writeAll(files.dataFile(), truncated);
    CHECK(files.load(snap, error) == LoadStatus::Corrupt);

    std::vector<unsigned char> badMagic = good;
    badMagic[0] = 'X';
    writeAll(files.dataFile(), badMagic);
    CHECK(files.load(snap, error) == LoadStatus::Corrupt);

    writeAll(files.dataFile(), std::vector<unsigned char>());  // empty file
    CHECK(files.load(snap, error) == LoadStatus::Corrupt);

    std::string moved;
    CHECK(files.quarantine(moved));
    CHECK(exists(moved) && !exists(files.dataFile()));
}

TEST(invalid_records_are_rejected_without_changing_state) {
    AcademicManager m;
    buildState(m);
    Snapshot bad = m.exportSnapshot();
    bad.enrollments.push_back({"ADV301", "GHOST01"});    // unknown student
    AcademicManager target;
    target.addStudent(StudentCategory::UG, "KEEP01", "Existing Data", "B.Tech", 1);
    CHECK(!target.importSnapshot(bad).ok);
    CHECK(target.findStudent("KEEP01") != nullptr);      // all-or-nothing: old state kept
    CHECK(target.findStudent("UG001") == nullptr);

    Snapshot cyclic = m.exportSnapshot();
    cyclic.prerequisites.push_back({"PF101", "ADV301"}); // would close a cycle
    CHECK(!target.importSnapshot(cyclic).ok);

    Snapshot overfull = m.exportSnapshot();
    overfull.enrollments.push_back({"DSA201", "UG002"});  // DSA201 has 1 seat
    CHECK(!target.importSnapshot(overfull).ok);

    Snapshot dupWait = m.exportSnapshot();
    dupWait.waitlists.push_back({"DSA201", "UG001"});     // already enrolled
    CHECK(!target.importSnapshot(dupWait).ok);
    CHECK(target.findStudent("KEEP01") != nullptr);
}

TEST(serialize_deserialize_is_lossless) {
    AcademicManager m;
    buildState(m);
    const Snapshot a = m.exportSnapshot();
    Snapshot b;
    std::string error;
    CHECK(FileManager::deserialize(FileManager::serialize(a), b, error));
    CHECK_EQ(a.students.size(), b.students.size());
    CHECK_EQ(a.results.size(), b.results.size());
    CHECK_EQ(a.enrollments.size(), b.enrollments.size());
    CHECK_EQ(a.waitlists.size(), b.waitlists.size());
    CHECK_EQ(a.prerequisites.size(), b.prerequisites.size());
    bool same = true;
    for (std::size_t i = 0; i < a.results.size() && i < b.results.size(); ++i) {
        same = same && a.results[i].studentId == b.results[i].studentId &&
               a.results[i].courseCode == b.results[i].courseCode && a.results[i].centiMarks == b.results[i].centiMarks;
    }
    CHECK(same);
    CHECK(FileManager::serialize(a) == FileManager::serialize(b));
    // CRC-32 check value of "123456789" is CBF43926 (standard test vector)
    const unsigned char digits[] = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
    CHECK_EQ(FileManager::crc32(digits, 9), 0xCBF43926UL);
}

int main(int argc, char** argv) {
    if (argc > 1) g_dir = argv[1];
    return testing::runAllTests("Persistence (binary .dat files)");
}
