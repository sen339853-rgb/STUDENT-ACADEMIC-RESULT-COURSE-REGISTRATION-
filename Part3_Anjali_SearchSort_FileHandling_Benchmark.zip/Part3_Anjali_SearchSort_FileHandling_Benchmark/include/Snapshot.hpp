// Snapshot.hpp
// Plain, pointer-free copy of the whole academic state.
//
// The AcademicManager exports a Snapshot for saving and rebuilds itself from
// one when loading. Only stable identifiers and plain values appear here -
// never memory addresses, C nodes or C++ objects - so the FileManager can
// serialise it field by field. List order is meaningful: enrolments are kept
// in roster order and waitlist entries in FIFO order (front first).
#ifndef SNAPSHOT_HPP
#define SNAPSHOT_HPP

#include <string>
#include <vector>

namespace academic {

struct StudentRecord {
    std::string id;
    std::string name;
    std::string program;
    int category = 0;   // 1 = UG, 2 = PG (StudentCategory)
    int semester = 0;
};

struct CourseRecord {
    std::string code;
    std::string title;
    int credits = 0;
    int capacity = 0;
};

struct PrerequisiteRecord {
    std::string courseCode;   // this course ...
    std::string prereqCode;   // ... requires this one
};

struct ResultRecord {
    std::string studentId;
    std::string courseCode;
    int centiMarks = 0;
    int credits = 0;
};

struct EnrollmentRecord {      // also used for waitlist entries
    std::string courseCode;
    std::string studentId;
};

struct Snapshot {
    std::vector<StudentRecord> students;
    std::vector<CourseRecord> courses;
    std::vector<PrerequisiteRecord> prerequisites;
    std::vector<ResultRecord> results;
    std::vector<EnrollmentRecord> enrollments;  // roster order per course
    std::vector<EnrollmentRecord> waitlists;    // FIFO order per course
};

}  // namespace academic

#endif  // SNAPSHOT_HPP
