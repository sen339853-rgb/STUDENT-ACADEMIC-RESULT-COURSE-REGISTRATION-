// Benchmark.hpp
// Measured (not estimated) timings of the C data structures on synthetic data.
//
// Methodology: each operation is run as a batch over a generated data set and
// timed with std::chrono::steady_clock. The batch is repeated until at least
// 50 ms have elapsed (so a coarse clock cannot distort it), and the mean batch
// time is divided by the operations per batch. Results depend on the machine,
// compiler flags and system load - run the benchmark on the demo machine and
// quote those numbers, not the ones from someone else's run.
#ifndef BENCHMARK_HPP
#define BENCHMARK_HPP

#include <cstddef>
#include <ostream>
#include <string>
#include <vector>

namespace academic {

struct BenchmarkRow {
    std::string operation;
    std::string complexity;   // theoretical, for comparison with the timing
    std::size_t operations = 0;   // per batch
    double totalMs = 0.0;         // mean time of one batch
    double nsPerOperation = 0.0;
    std::size_t repetitions = 0;  // how many batches were timed
    std::string check;        // correctness check performed during the run
};

std::vector<BenchmarkRow> runBenchmarks(std::size_t records);
void printBenchmarks(std::ostream& out, const std::vector<BenchmarkRow>& rows, std::size_t records);

}  // namespace academic

#endif  // BENCHMARK_HPP
