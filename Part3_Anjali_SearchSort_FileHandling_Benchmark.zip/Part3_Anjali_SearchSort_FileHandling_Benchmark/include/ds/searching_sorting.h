/*
 * searching_sorting.h
 * Merge sort, linear search and binary search over plain C records.
 *
 * The C++ layer copies the fields it wants to sort or search into an array
 * of SortRecord (a temporary "view"; the authoritative records stay in the
 * C++ objects), calls these functions, and prints the result.
 *
 *   merge sort       O(n log n) time in every case, O(n) auxiliary space,
 *                    stable (equal elements keep their relative order)
 *   linear search    O(n) time, O(1) space, works on unsorted data
 *   binary search    O(log n) time, O(1) space, array MUST be sorted by key
 */
#ifndef SEARCHING_SORTING_H
#define SEARCHING_SORTING_H

#include <stddef.h>
#include "ds/ds_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct SortRecord {
    char key[DS_KEY_LEN];   /* student ID or course code                  */
    char name[DS_NAME_LEN]; /* student name or course title               */
    int score;              /* CGPA x 100, or a count (e.g. enrolled seats);
                               -1 means "no score" and sorts last          */
} SortRecord;

typedef enum SortOrder {
    SORT_BY_KEY = 0,        /* ID / code, ascending                        */
    SORT_BY_NAME = 1,       /* name, case-insensitive, ascending           */
    SORT_BY_SCORE_DESC = 2, /* score high -> low, ties by key ascending    */
    SORT_BY_SCORE_ASC = 3   /* score low -> high, ties by key ascending    */
} SortOrder;

/* <0, 0, >0 like strcmp, according to order. */
int ss_compare(const SortRecord *a, const SortRecord *b, int order);

int ss_merge_sort(SortRecord *records, size_t n, int order);
int ss_is_sorted(const SortRecord *records, size_t n, int order);

/* Return the index of key, or -1. *comparisons (if not NULL) receives the
 * number of key comparisons performed, for the analytics demonstration. */
long ss_linear_search_key(const SortRecord *records, size_t n, const char *key,
                          size_t *comparisons);
long ss_binary_search_key(const SortRecord *records, size_t n, const char *key,
                          size_t *comparisons);

/* Case-insensitive substring search on name (linear scan).
 * Writes matching indices into out_idx; returns the number of matches. */
size_t ss_search_name(const SortRecord *records, size_t n, const char *fragment,
                      size_t *out_idx, size_t max);

#ifdef __cplusplus
}
#endif

#endif /* SEARCHING_SORTING_H */
