// FileManager.hpp
// Binary persistence of a Snapshot in one versioned, checksummed .dat file.
//
// File layout (all integers little-endian, strings = u16 length + bytes):
//   magic    8 bytes  "SARCRSDB"
//   version  u32      kFormatVersion
//   length   u32      number of payload bytes that follow
//   payload           sections in this fixed order, each "TAG" + u32 count:
//                       STUD  id, name, program, u8 category, u8 semester
//                       CRSE  code, title, u8 credits, u16 capacity
//                       PREQ  course code, prerequisite code
//                       RSLT  student id, course code, u16 centi-marks, u8 credits
//                       ENRL  course code, student id     (roster order)
//                       WAIT  course code, student id     (FIFO order)
//   crc32    u32      CRC-32 of the payload, detects corruption/truncation
//
// One file (instead of one per record type) means students, courses, results,
// enrolments and waitlists are always saved together and can never be out of
// step with each other. Saving writes "<file>.tmp" first and then swaps it in,
// so a crash mid-write leaves the previous file intact.
#ifndef FILE_MANAGER_HPP
#define FILE_MANAGER_HPP

#include <string>
#include <vector>

#include "Snapshot.hpp"

namespace academic {

enum class LoadStatus { Loaded, Missing, Corrupt };

class FileManager {
public:
    static constexpr unsigned kFormatVersion = 1;

    explicit FileManager(std::string dataDirectory);

    const std::string& dataDirectory() const { return directory_; }
    const std::string& dataFile() const { return file_; }

    // Returns false and sets error if the file could not be written.
    bool save(const Snapshot& snapshot, std::string& error) const;

    // Missing  -> no file yet (fresh start), snapshot untouched.
    // Corrupt  -> file exists but failed validation; error explains why.
    LoadStatus load(Snapshot& snapshot, std::string& error) const;

    // Renames a corrupt data file to "<file>.corrupt" so it is kept for
    // inspection and is not overwritten by the next save.
    bool quarantine(std::string& movedTo) const;

    // Pure (de)serialisation, exposed for unit tests.
    static std::vector<unsigned char> serialize(const Snapshot& snapshot);
    static bool deserialize(const std::vector<unsigned char>& bytes, Snapshot& snapshot, std::string& error);

    static unsigned long crc32(const unsigned char* data, std::size_t length);

private:
    std::string directory_;
    std::string file_;
};

}  // namespace academic

#endif  // FILE_MANAGER_HPP
