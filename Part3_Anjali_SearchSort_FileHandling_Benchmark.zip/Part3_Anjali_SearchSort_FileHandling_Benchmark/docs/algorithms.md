# Algorithms and Complexity

Notation: n = students, C = courses, V/E = graph vertices/edges, k = roster or waitlist length.
**Theoretical complexity** (how cost grows) is a separate thing from **measured time**, which depends on
the machine and is reported by DSA menu → 8 (see docs/testing.md).

## 1. Student / course search by ID: hash table (`hash_table.c`)

```
hash(key) = FNV-1a 32-bit:  h = 2166136261; for each byte b: h = (h XOR b) * 16777619
bucket    = hash(key) mod bucket_count
find(key): walk the linked list in that bucket comparing keys
insert   : reject duplicates; if (size+1)/buckets > 0.75 -> double buckets and rehash all keys
```

- Collisions: **separate chaining**. Every bucket is a `LinkedList`. Two keys in the same bucket
  simply share a list (tested in `hash_table_collision_chaining`).
- Average find/insert/remove is O(1 + α), where α is the load factor (kept ≤ 0.75).
  The worst case is O(n), if every key lands in one bucket. Hashing does **not** guarantee O(1) in the worst case.
- Rehashing costs O(n) but happens only when the table doubles, so insert is amortised O(1).

## 2. Search by name and the search comparison

- `ss_search_name`: case-insensitive substring scan. O(n·m) for n names and pattern length m.
- `searchDemo` (DSA → 2) runs on the live students:
  linear search on the unsorted array (O(n) comparisons), then merge sort by ID, then binary search
  (≤ ⌊log₂n⌋+1 comparisons), then the hash lookup. It prints the comparison counts.

## 3. Sorting: merge sort (`searching_sorting.c`)

```
merge_sort(a[lo..hi)):  if hi-lo < 2 return
                        mid = lo + (hi-lo)/2
                        merge_sort(a[lo..mid)); merge_sort(a[mid..hi))
                        merge the two halves into tmp (take the left element on ties -> stable)
                        copy tmp back
```

O(n log n) time in the best, average and worst case. O(n) auxiliary space (one buffer, allocated once).
Recursion depth is O(log n). Comparators: by key, by name (case-insensitive), by score descending or
ascending. "No score" (−1) always sorts last. Ties fall back to the key.

## 4. Ranking: AVL tree (`bst.c`)

- Key = (CGPA×100 rounded, student ID). Integers make equal CGPAs compare exactly.
- BST order: lower score to the left; for equal scores, the larger ID goes left.
  A **reverse inorder** walk (right, node, left) therefore gives the highest CGPA first,
  with ties in ascending ID order. A plain **inorder** walk gives the lowest first.
- After each insert or delete, `rebalance` fixes any node whose balance factor is ±2:

| Case | Condition | Fix |
|---|---|---|
| LL | bf(n) = +2, bf(left) ≥ 0 | rotate right at n |
| LR | bf(n) = +2, bf(left) < 0 | rotate left at left child, then right at n |
| RR | bf(n) = −2, bf(right) ≤ 0 | rotate left at n |
| RL | bf(n) = −2, bf(right) > 0 | rotate right at right child, then left at n |

- An AVL tree with n nodes has height < 1.44·log₂(n+2), so search, insert and delete are
  **O(log n) in the worst case**. A plain BST fed students in CGPA order would turn into a
  linked list with O(n) height. The test `avl_stays_balanced_on_sorted_input` inserts 1023 sorted keys.
- Each node also stores the size of its subtree. Competition rank =
  1 + (number of keys with a strictly higher score), found on one root-to-leaf path:
  `avl_count_above` is O(log n). Equal CGPA → equal rank (e.g. 1, 2, 2, 4).
- `avl_collect_at_least(min)` ("Top performers") walks in reverse inorder and stops descending
  left once a node's score is below `min`. That costs O(log n + output size).
- **Updating a ranking** after a marks change: remove (old score, id), change the result, insert
  (new score, id). That is two O(log n) operations instead of re-sorting everyone.

## 5. Prerequisite validation: graph + DFS (`graph.c`)

Edge `course → prereq` means "course requires prereq". Adjacency lists hold each course's direct prerequisites.

```
check_prereqs(course, passed[]):
    order = DFS_postorder(course)            // every reachable prerequisite, each visited once
    missing = [v in order, v != course, passed[v] == 0]
    eligible = missing is empty
```

- `passed[]` is built from the student's results using the **virtual** `evaluate()`, so the UG pass mark (40)
  and the PG pass mark (50) are applied correctly. Courses that are only registered, not passed, do not count.
- Transitive check: ADV301 → DSA201 → PF101. A student who passed DSA201 but not PF101 is still missing PF101.
- Post-order lists the most foundational course first, so the rejection message reads
  "Not yet passed: PF101, DSA201".
- Cost O(V+E), with an O(V) visited array.

**Keeping it a DAG.** `graph_add_edge(c, p)` rejects:
an unknown vertex, `c == p` (self-dependency), a duplicate edge, and any edge where `p` can already reach `c`
(found by DFS). That last edge would close the cycle c → p → … → c.
After loading a file, the whole graph is checked again with a white/grey/black DFS (`graph_has_cycle`).
Reaching a grey vertex means a back edge, which means a cycle.

**Study order** (`graph_topological_order`): since edges point at prerequisites, the DFS post-order over all
vertices is already a valid topological order.

## 6. Course registration (`RegistrationManager::requestRegistration`)

```
1  student = hash_lookup(studentId)          else StudentNotFound
2  course  = hash_lookup(courseCode)         else CourseNotFound
3  if student in roster   -> AlreadyEnrolled
   if student in waitlist -> AlreadyWaitlisted (shows position)
   if student passed it   -> AlreadyPassed
4  report = DFS check (section 5)            if missing -> MissingPrerequisites (lists them)
5  if enrolled < capacity -> roster.push_back(student)   -> Enrolled
   else                   -> waitlist.enqueue(student)   -> Waitlisted (position)
6  CLI saves the new state to disk
```

Every check happens before the single mutation in step 5, so a rejected request changes nothing.
`Course::enroll` refuses to go over capacity, so the seat count can never go negative.

## 7. Waiting list: FIFO policy (`RegistrationManager::fillVacancies`)

```
while course has a free seat and waitlist not empty:
    s = waitlist.dequeue()                    // front = earliest request
    if s no longer exists / already passed / no longer meets prerequisites:
        drop s with a recorded reason         // and continue with the next student
    else:
        roster.push_back(s)                   // promoted
```

This runs after a cancellation, after a capacity increase, and on "Process Waitlist".
A waitlisted student can become ineligible, for example when a prerequisite mark is corrected to a fail.
That student is then skipped and the next student in FIFO order gets the seat (tested in
`full_course_waitlist_and_fifo_promotion`). Leaving a waitlist voluntarily removes that one entry
(O(k)) and keeps everyone else in order.

## 8. Undo of marks entry (`AcademicManager::undoLastMarksEntry`)

```
recordMarks: validate -> push {student, course, action, previous marks, previous credits}
             -> remove old AVL key -> write result -> insert new AVL key
undo:        peek top -> validate -> restore (delete result if it was a new entry,
             else put back the previous marks) -> fix AVL key -> pop
```

- Push, pop and peek are O(1). The ranking fix costs O(log n).
- If the push fails (out of memory), the marks are not changed, so the stack can never fall
  behind the data.
- **Safe undo rule:** an undo that would turn a pass into a fail is refused while the student is enrolled in
  a course that requires that pass. The record stays on the stack and can be undone after the registration is cancelled.
- Undo history is per session (not saved). It is cleared when a student is deleted, because the history could
  refer to that student.

## 9. Save and reload (`FileManager`, `AcademicManager::exportSnapshot/importSnapshot`)

**Save:**
```
snapshot = plain records (IDs, names, numbers) in a fixed order; waitlists front -> rear
bytes    = "SARCRSDB" | version | payload length | sections STUD CRSE PREQ RSLT ENRL WAIT | CRC-32
write <file>.tmp -> move old file to .bak -> rename .tmp to <file> -> delete .bak
```
Integers are written byte by byte in little-endian order, so the file never depends on struct padding or
CPU byte order. No pointers, no raw C++ objects (which contain `std::string`s, vtable pointers and heap pointers) and no
C nodes are written.

**Load:**
```
missing file          -> start empty
bad magic / version / length / CRC / malformed section -> Corrupt: rename to .corrupt, start empty
otherwise build a NEW AcademicManager:
   students -> courses -> prerequisites (cycle check) -> results -> enrolments (capacity, duplicates)
   -> waitlists (in file order = FIFO order)
   any invalid record -> discard the new manager (RAII frees it); current state untouched
   all valid          -> *this = std::move(newManager)
```
The hash tables, AVL ranking, graph, linked lists and queues are all **rebuilt** from the records. Nothing is
restored from memory addresses. The record counts are checked against the remaining bytes before any memory is
allocated, so a damaged file cannot trigger a huge allocation.

## 10. Summary table

| Operation | Algorithm | Time | Extra space |
|---|---|---|---|
| Find student/course by ID | hash + chaining | O(1) average, O(n) worst | — |
| Search by name | linear substring scan | O(n·m) | O(matches) |
| Sort records | merge sort | O(n log n) | O(n) |
| Binary search (sorted) | halving | O(log n) | O(1) |
| Insert/remove/update rank | AVL | O(log n) worst | O(1) per node |
| Rank of a student | subtree sizes | O(log n) | — |
| Full ranking | reverse inorder | O(n) | O(n) output |
| Add prerequisite | DFS reachability | O(V+E) | O(V) |
| Eligibility check | DFS post-order | O(V+E) | O(V) |
| Register | hash + DFS + list/queue | O(1)+O(V+E)+O(k) | O(V) |
| Promote from waitlist | dequeue + DFS per candidate | O(V+E) per candidate | O(V) |
| Undo | stack + AVL | O(1) + O(log n) | O(1) per entry |
| Save / load | serialise / rebuild | O(total records · (log n + k)) | O(file size) |
